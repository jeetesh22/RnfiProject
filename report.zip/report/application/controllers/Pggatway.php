 <?php
		class Pggatway extends MY_Controller {
			public function __construct(){
			parent::__construct();
			$this->load->database();
			$this->load->model('Pggateway_model');
			date_default_timezone_set('Asia/Kolkata');
			//set_time_limit(0);
			ini_set('memory_limit', '200000M');
			
			$this->coloum = array('Transaction_ID','Order_ID','Merchant_Unique_Ref','Transaction_Date','Updated_Date',
			'Transaction_Type','Status','MID','Merchant_Name','Customer_ID',
			'Customer_Nickname','Payment_Mobile_Number','Payment_Email_Id','Amount','Commission',
			'GST','Merchant_Order_ID','Payout_ID','Channel','UTR_No',
			'Payout_Date','Settled_Date','Payment_Mode','Issuing_Bank','Reference_Transaction_ID',
			'POS_ID','Merchant_Ref_ID','External_Serial_No','Commission_Rate','Product_Code',
			'GMV_Tier','Transaction_Slab','Request_Type','Refund_Type','Refund_Actor',
			'Split_Flag','Split_MID','Split_Id','Link_Description','Payment_Reference_Number',
			'Is_PRN_Validated','PRN_Validate_Time','Card_Last_4_Digits','Bank_Transaction_ID','Promo_Code',
			'Promo_Response','Settled_Amount','PCF','PCF_GST','Response_code',
			'Customer_VPA','Card_BIN','Customer_Details','Link_Name','Link_Notes',
			'Response_message','Promo_discount_type','Promo_Amount','Original_txn_value_before_promo','Total_Bill_Amount',
			'Instant_Discount','MLV_Amount','Auth_Code','RRN','Prepaid_Card',
			'AdditionalComments','Charge_Target','Fee_Factor','Bank_Gateway','Card_Scheme',
			'ACQUIRING_SERVICE_FEE','ACQUIRING_SERVICE_TAX','PLATFORM_SERVICE_FEE','PLATFORM_SERVICE_TAX');
			
		 }
		 
		 public function add(){ 
			  if(!empty($this->session->userdata('logged_in'))){
				$this->middle = 'Admin/Pggatway/add'; 
				$this->layout();  
			 }else {
				 redirect(base_url());
		     }			
		 }
		 
		   
		   public function save(){
			  if(!empty($this->session->userdata('logged_in'))){
				$pgArray = array();
				$pgKeyArray = array();
				require_once APPPATH . "/third_party/PHPExcel.php";
				if(filecheck_method($_FILES)){
				if ($_FILES['file']['name']) {
					$path=$_FILES['file']['tmp_name'];
					$object = PHPExcel_IOFactory::load($path);
					foreach ($object->getworksheetIterator() as $worksheet) {
						$highestRow= $worksheet->getHighestRow();
						$highestColumn = $worksheet->getHighestColumn();
						for($row=2; $row<=$highestRow; $row++)
						{
							$headings  = $worksheet->rangeToArray('A1:'.$highestColumn.'1', NULL, TRUE, FALSE);
							$rowData = $worksheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                                            NULL,
                                            TRUE,
                                            FALSE);
							array_push($pgArray,$rowData[0]);
					 }
					}
					
					  foreach($pgArray as $i=>$pgdata){
						foreach($this->coloum as $j=>$coldata){
							$pgKeyArray[$i][$coldata] = $pgdata[$j];
					  }
					} 
					//echo "<pre>";print_r($pgKeyArray);die;
					$this->Pggateway_model->savePgData($pgKeyArray);
				}else{
					$this->middle = 'Admin/Pggatway/add'; 
				    $this->layout();  
				}
				}
				}
			   else {
				 redirect(base_url());
		     }
		   }
		   
		   public function index(){
			  if(!empty($this->session->userdata('logged_in'))){
				$search_str = $this->input->get("search_str");
				$to_date = $this->input->get("to_date");
				if($search_str!=""){
					$data["pggatwayReport"] = $this->Pggateway_model->getPggatewayData($search_str,$to_date);
				    ob_clean();
					header("Content-type: application/csv");
					header("Content-Disposition: attachment; filename=\"pggatway".".csv\"");
					header("Pragma: no-cache");
					header("Expires: 0");
					$handle = fopen('php://output', 'w');
					fputcsv($handle, $this->coloum);
					$i = 1;
					foreach ($data["pggatwayReport"] as $data) {
						$pgArray = array($data["Transaction_ID"],$data["Order_ID"],$data["Merchant_Unique_Ref"],$data["Transaction_Date"],
						$data["Updated_Date"],$data["Transaction_Type"],$data["Status"],$data["MID"],$data["Merchant_Name"],
						$data["Customer_ID"],$data["Customer_Nickname"],$data["Payment_Mobile_Number"],$data["Payment_Email_Id"],$data["Amount"],
						$data["Commission"],$data["GST"],$data["Merchant_Order_ID"],$data["Payout_ID"],$data["Channel"],
						$data["UTR_No"],$data["Payout_Date"],$data["Settled_Date"],$data["Payment_Mode"],$data["Issuing_Bank"],
						$data["Reference_Transaction_ID"],$data["POS_ID"],$data["Merchant_Ref_ID"],$data["External_Serial_No"],$data["Commission_Rate"],
						$data["Product_Code"],$data["GMV_Tier"],$data["Transaction_Slab"],$data["Request_Type"],$data["Refund_Type"],
						$data["Refund_Actor"],$data["Split_Flag"],$data["Split_MID"],$data["Split_Id"],$data["Link_Description"],
						$data["Payment_Reference_Number"],$data["Is_PRN_Validated"],$data["PRN_Validate_Time"],$data["Card_Last_4_Digits"],$data["Bank_Transaction_ID"],
						$data["Promo_Code"],$data["Promo_Response"],$data["Settled_Amount"],$data["PCF"],$data["PCF_GST"],
						$data["Response_code"],$data["Customer_VPA"],$data["Card_BIN"],$data["Customer_Details"],$data["Link_Name"],
						$data["Link_Notes"],$data["Response_message"],$data["Promo_discount_type"],$data["Promo_Amount"],$data["Original_txn_value_before_promo"],
						$data["Total_Bill_Amount"],$data["Instant_Discount"],$data["MLV_Amount"],$data["Auth_Code"],$data["RRN"],
						$data["Prepaid_Card"],$data["AdditionalComments"],$data["Charge_Target"],$data["Fee_Factor"],$data["Bank_Gateway"],
						$data["Card_Scheme"],$data["ACQUIRING_SERVICE_FEE"],$data["ACQUIRING_SERVICE_TAX"],$data["PLATFORM_SERVICE_FEE"],$data["PLATFORM_SERVICE_TAX"]);
						
						fputcsv($handle, $pgArray);
						$i++;
					}
						fclose($handle);
					exit;
				}else{
					$this->middle = 'Admin/Pggatway/index'; 
					$this->layout();     
				}
				}
			   else {
				 redirect(base_url());
		     }
		   }
		   
		    
		   
		   
		   
		
			
}