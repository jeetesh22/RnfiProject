 <?php
		class Tbo extends MY_Controller {
			public function __construct(){
			parent::__construct();
			$this->load->database();
			$this->load->model('Tbo_model');
			date_default_timezone_set('Asia/Kolkata');
			//set_time_limit(0);
			ini_set('memory_limit', '200000M');
			
			$this->coloum = array('DATE','BILL','INVOICENO','INVOICEDATE','TRAVEL_DATE_TIME',
			'BOOKING_MODE','PAX_NAME','LeadPAXPan','LeadPAXPassport','OtherPAXPAN','OtherPAXPassport',
			'CorporateGSTNumber','Staff_Name','Air_Line','TICKET_NO','SECTOR','FARE','TAX','Special_Ser_Chrgs','GROSS',
			'H_Charges','H_CHRG','PLBRate','PLBAmount','IncentiveRate','IncentiveAmount','Service_Charges','Cancellation_Amount','Cancellation_Service_Charges','TDS',
			'S_TAX','SGST_Rate','SGST_Amt','CGST_Rate','CGST_Amt','IGST_Rate','IGST_Amt','Total_GST','NET','Preferred_currency',
			'ROE','TotalAmount','Carrier','PaxType','Flight_Details','TicketStatus','PaymentId','TourCode','Endorsement','Remarks',
			'Agent_Booking_Remarks','CorporateCode','YQ_TAX','YR_TAX','K3_GST','TRA_Fee','ServiceTaxRAF','SwachhBharatCessAmount','KrishiKalyanCessAmount','isByAgentCreditCard',
			'AgentCreditCardAmount','TicketSaleAmount','OXITRXID','PNR','Credit_Shell_PNR','Credit_Shell_Amount','IsAmendment');
			
		 }
		 
		  public function add(){ 
			 if(!empty($this->session->userdata('logged_in'))){
				$this->middle = 'Admin/Tbo/add'; 
				$this->layout();  
			 }else {
				 redirect(base_url());
		     }			
		   }
		 
		   
		   public function save(){
			  if(!empty($this->session->userdata('logged_in'))){
				$pgArray = array();
				$aepsArray = array();
				require_once APPPATH . "/third_party/PHPExcel.php";
				if(filecheck_method($_FILES)){
				if ($_FILES['file']['name']) {
					$path=$_FILES['file']['tmp_name'];
					$object = PHPExcel_IOFactory::load($path);
					foreach ($object->getworksheetIterator() as $worksheet) {
						$highestRow= $worksheet->getHighestRow();
						$highestColumn = $worksheet->getHighestColumn();
						for($row=2; $row<=$highestRow; $row++)
						{
							$headings  = $worksheet->rangeToArray('A1:'.$highestColumn.'1', NULL, TRUE, FALSE);
							$rowData = $worksheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                                            NULL,
                                            TRUE,
                                            FALSE);
							array_push($aepsArray,$rowData[0]);
					    }
					  }
					   foreach($aepsArray as $i=>$data){
						foreach($this->coloum as $j=>$coldata){
							$KeyArray[$i][$coldata] = $data[$j];
					  }
					} 
				    //echo "<pre>";print_r($KeyArray);die;
					$this->Tbo_model->saveData($KeyArray);
				}else{
					$this->middle = 'Admin/Tbo/add'; 
				    $this->layout();  
				}
				}}
			   else {
				 redirect(base_url());
		     }
		   }
		   
		   public function index(){
			  if(!empty($this->session->userdata('logged_in'))){
				$search_str = $this->input->get("search_str");
				$to_date = $this->input->get("to_date");
				if($search_str!="" || $to_date!=""){
					$data["getReport"] = $this->Tbo_model->getData($search_str,$to_date);
				    ob_clean();
					header("Content-type: application/csv");
					header("Content-Disposition: attachment; filename=\"Tbo".".csv\"");
					header("Pragma: no-cache");
					header("Expires: 0");
					$handle = fopen('php://output', 'w');
					fputcsv($handle, $this->coloum);
					$i = 1;
					foreach ($data["getReport"] as $data) {
						$keyArray = array($data["DATE"],$data["BILL"],$data["INVOICENO"],$data["INVOICEDATE"],$data["TRAVEL_DATE_TIME"],$data["BOOKING_MODE"],$data["PAX_NAME"],
						$data["LeadPAXPan"],$data["LeadPAXPassport"],$data["OtherPAXPAN"],$data["OtherPAXPassport"],$data["CorporateGSTNumber"],$data["Staff_Name"],$data["Air_Line"],$data["TICKET_NO"],$data["SECTOR"],
						$data["FARE"],$data["TAX"],$data["Special_Ser_Chrgs"],$data["GROSS"],$data["H_Charges"],$data["H_CHRG"],$data["PLBRate"],$data["PLBAmount"],$data["IncentiveRate"],
						$data["IncentiveAmount"],$data["Service_Charges"],$data["Cancellation_Amount"],$data["Cancellation_Service_Charges"],$data["TDS"],$data["S_TAX"],$data["SGST_Rate"],$data["SGST_Amt"],$data["CGST_Rate"],
						$data["CGST_Amt"],$data["IGST_Rate"],$data["IGST_Amt"],$data["Total_GST"],$data["NET"],$data["Preferred_currency"],$data["ROE"],$data["TotalAmount"],$data["Carrier"],
						$data["PaxType"],$data["Flight_Details"],$data["TicketStatus"],$data["PaymentId"],$data["TourCode"],$data["Endorsement"],$data["Remarks"],$data["Agent_Booking_Remarks"],$data["CorporateCode"],
						$data["YQ_TAX"],$data["YR_TAX"],$data["K3_GST"],$data["TRA_Fee"],$data["ServiceTaxRAF"],$data["SwachhBharatCessAmount"],$data["KrishiKalyanCessAmount"],$data["isByAgentCreditCard"],$data["AgentCreditCardAmount"],
						$data["TicketSaleAmount"],$data["OXITRXID"],$data["PNR"],$data["Credit_Shell_PNR"],$data["Credit_Shell_Amount"],$data["IsAmendment"]);
						
						fputcsv($handle, $keyArray);
						$i++;
					}
						fclose($handle);
					exit;
				}else{
					$this->middle = 'Admin/Tbo/index'; 
					$this->layout();     
				}
				}
			   else {
				 redirect(base_url());
		     }
		   }
	}