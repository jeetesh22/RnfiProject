 <?php
		class Irctcbooking extends MY_Controller {
			public function __construct(){
			parent::__construct();
			$this->load->database();
			$this->load->model('Irctcbooking_model');
			date_default_timezone_set('Asia/Kolkata');
			//set_time_limit(0);
			ini_set('memory_limit', '200000M');
			
			$this->coloum = array('SlNo','TRANSACTION_ID','Rnfi','PNR_NO','CLIENT_TRANSACTION_ID',
			'BOOKING_AMOUNT','PG_NAME','CLASS','TRANSACTION_DATE',
			'USER_ID','PRINCIPAL_USER_ID','AMC_Charge');
			
			$this->coloumREFUND = array('SlNo','TRANSACTION_ID','PNR_NO','OPERATOR_ID','PG_NAME',
			'CLASS','REFUND_AMOUNT','WAITING_AUTO_CANCELLED','TRANSACTION_DATE',
			'ACTUAL_REFUND_DATE','TDR_CAN','USER_ID','PRINCIPAL_USER_ID','CANCELLATION_ID');
			
		 }
		 
		 public function addbooking(){ 
			 if(!empty($this->session->userdata('logged_in'))){
				$this->middle = 'Admin/Irctcbooking/addbooking'; 
				$this->layout();  
			 }else {
				 redirect(base_url());
		     }			
		  }
		 
		   
		   public function savebooking(){
			  if(!empty($this->session->userdata('logged_in'))){
				$pgArray = array();
				$aepsArray = array();
				require_once APPPATH . "/third_party/PHPExcel.php";
				if(filecheck_method($_FILES)){
				if ($_FILES['file']['name']) {
					$path=$_FILES['file']['tmp_name'];
					$object = PHPExcel_IOFactory::load($path);
					foreach ($object->getworksheetIterator() as $worksheet) {
						$highestRow= $worksheet->getHighestRow();
						$highestColumn = $worksheet->getHighestColumn();
						for($row=2; $row<=$highestRow; $row++)
						{
							$headings  = $worksheet->rangeToArray('A1:'.$highestColumn.'1', NULL, TRUE, FALSE);
							$rowData = $worksheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                                            NULL,
                                            TRUE,
                                            FALSE);
							array_push($aepsArray,$rowData[0]);
					    }
					  }
					   foreach($aepsArray as $i=>$data){
						foreach($this->coloum as $j=>$coldata){
							$KeyArray[$i][$coldata] = $data[$j];
					  }
					} 
				    //echo "<pre>";print_r($KeyArray);die;
					$this->Irctcbooking_model->saveData($KeyArray);
				}else{
					$this->middle = 'Admin/Irctcbooking/addbooking'; 
				    $this->layout();  
				}
				}
				}
			   else {
				 redirect(base_url());
		     }
		   }
		   
		   public function indexbooking(){
			  if(!empty($this->session->userdata('logged_in'))){
				$search_str = $this->input->get("search_str");
				$to_date = $this->input->get("to_date");
				if($search_str!=""){
					$data["getReport"] = $this->Irctcbooking_model->getData($search_str,$to_date);
				    ob_clean();
					header("Content-type: application/csv");
					header("Content-Disposition: attachment; filename=\"irctcbooking".".csv\"");
					header("Pragma: no-cache");
					header("Expires: 0");
					$handle = fopen('php://output', 'w');
					fputcsv($handle, $this->coloum);
					$i = 1;
					foreach ($data["getReport"] as $data) {
						$keyArray = array($data["SlNo"],$data["TRANSACTION_ID"],$data["Rnfi"],$data["PNR_NO"],
						$data["CLIENT_TRANSACTION_ID"],$data["BOOKING_AMOUNT"],$data["PG_NAME"],$data["CLASS"],
						$data["TRANSACTION_DATE"],$data["USER_ID"],$data["PRINCIPAL_USER_ID"],$data["AMC_Charge"]);
						
						fputcsv($handle, $keyArray);
						$i++;
					}
						fclose($handle);
					exit;
				}else{
					$this->middle = 'Admin/Irctcbooking/indexbooking'; 
					$this->layout();     
				}
				}
			   else {
				 redirect(base_url());
		     }
		   }
		   
		   
		   //Refund
		   
		    public function addrefund(){ 
			 if(!empty($this->session->userdata('logged_in'))){
				$this->middle = 'Admin/Irctcbooking/addrefund'; 
				$this->layout();  
			 }else {
				 redirect(base_url());
		     }			
		  }
		 
		   
		   public function saverefund(){
			  if(!empty($this->session->userdata('logged_in'))){
				$pgArray = array();
				$aepsArray = array();
				require_once APPPATH . "/third_party/PHPExcel.php";
				if(filecheck_method($_FILES)){
				if ($_FILES['file']['name']) {
					$path=$_FILES['file']['tmp_name'];
					$object = PHPExcel_IOFactory::load($path);
					foreach ($object->getworksheetIterator() as $worksheet) {
						$highestRow= $worksheet->getHighestRow();
						$highestColumn = $worksheet->getHighestColumn();
						for($row=2; $row<=$highestRow; $row++)
						{
							$headings  = $worksheet->rangeToArray('A1:'.$highestColumn.'1', NULL, TRUE, FALSE);
							$rowData = $worksheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                                            NULL,
                                            TRUE,
                                            FALSE);
							array_push($aepsArray,$rowData[0]);
					    }
					  }
					   foreach($aepsArray as $i=>$data){
						foreach($this->coloumREFUND as $j=>$coldata){
							$KeyArray[$i][$coldata] = $data[$j];
					  }
					} 
				    //echo "<pre>";print_r($KeyArray);die;
					$this->Irctcbooking_model->saverefundData($KeyArray);
				}else{
					$this->middle = 'Admin/Irctcbooking/addrefund'; 
				    $this->layout();  
				}
				}
				}
			   else {
				 redirect(base_url());
		     }
		   }
		   
		   public function indexrefund(){
			  if(!empty($this->session->userdata('logged_in'))){
				$search_str = $this->input->get("search_str");
				$to_date = $this->input->get("to_date");
				if($search_str!="" || $to_date!=""){
					$data["getReport"] = $this->Irctcbooking_model->getrefundData($search_str,$to_date);
				    ob_clean();
					header("Content-type: application/csv");
					header("Content-Disposition: attachment; filename=\"irctcrefund".".csv\"");
					header("Pragma: no-cache");
					header("Expires: 0");
					$handle = fopen('php://output', 'w');
					fputcsv($handle, $this->coloumREFUND);
					$i = 1;
					foreach ($data["getReport"] as $data) {
						$keyArray = array($data["SlNo"],$data["TRANSACTION_ID"],$data["PNR_NO"],$data["OPERATOR_ID"],$data["PG_NAME"],
						$data["CLASS"],$data["REFUND_AMOUNT"],$data["WAITING_AUTO_CANCELLED"],$data["TRANSACTION_DATE"],$data["ACTUAL_REFUND_DATE"],
						$data["TDR_CAN"],$data["USER_ID"],$data["PRINCIPAL_USER_ID"],$data["CANCELLATION_ID"]);
						
						fputcsv($handle, $keyArray);
						$i++;
					}
						fclose($handle);
					exit;
				}else{
					$this->middle = 'Admin/Irctcbooking/indexrefund'; 
					$this->layout();     
				}
				}
			   else {
				 redirect(base_url());
		     }
		   }
		    
	}