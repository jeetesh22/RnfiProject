 <?php
		class Pancard extends MY_Controller {
			public function __construct(){
			parent::__construct();
			$this->load->database();
			$this->load->model('Pancard_model');
			date_default_timezone_set('Asia/Kolkata');
			//set_time_limit(0);
			ini_set('memory_limit', '200000M');
			
			$this->coloum = array('Date','Transaction_Id','API_Type','Pancard_Amount','Trans_Status','Vleid','Tokens',
			'Tokens_no','Service','Service_provider','Panno','Location','Pancode','Panprice','Pancardprice');
			
		 }
		 
		  public function add(){ 
			 if(!empty($this->session->userdata('logged_in'))){
				$this->middle = 'Admin/Pancard/add'; 
				$this->layout();  
			 }else {
				 redirect(base_url());
		     }			
		   }
		 
		   
		   public function save(){
			  if(!empty($this->session->userdata('logged_in'))){
				$pgArray = array();
				$aepsArray = array();
				require_once APPPATH . "/third_party/PHPExcel.php";
				if(filecheck_method($_FILES)){
				if ($_FILES['file']['name']) {
					$path=$_FILES['file']['tmp_name'];
					$object = PHPExcel_IOFactory::load($path);
					foreach ($object->getworksheetIterator() as $worksheet) {
						$highestRow= $worksheet->getHighestRow();
						$highestColumn = $worksheet->getHighestColumn();
						for($row=2; $row<=$highestRow; $row++)
						{
							$headings  = $worksheet->rangeToArray('A1:'.$highestColumn.'1', NULL, TRUE, FALSE);
							$rowData = $worksheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                                            NULL,
                                            TRUE,
                                            FALSE);
							array_push($aepsArray,$rowData[0]);
					    }
					  }
					   foreach($aepsArray as $i=>$data){
						foreach($this->coloum as $j=>$coldata){
							$KeyArray[$i][$coldata] = $data[$j];
					  }
					} 
				    //echo "<pre>";print_r($KeyArray);die;
					$this->Pancard_model->saveData($KeyArray);
				}else{
					$this->middle = 'Admin/Pancard/add'; 
				    $this->layout();  
				}
				}
				}
			   else {
				 redirect(base_url());
		     }
		   }
		   
		   public function index(){
			  if(!empty($this->session->userdata('logged_in'))){
				$search_str = $this->input->get("search_str");
				$to_date = $this->input->get("to_date");
				if($search_str!="" || $to_date!=""){
					$data["getReport"] = $this->Pancard_model->getData($search_str,$to_date);
				    ob_clean();
					header("Content-type: application/csv");
					header("Content-Disposition: attachment; filename=\"Pancard".".csv\"");
					header("Pragma: no-cache");
					header("Expires: 0");
					$handle = fopen('php://output', 'w');
					fputcsv($handle, $this->coloum);
					$i = 1;
					foreach ($data["getReport"] as $data) {
						$keyArray = array($data["Date"],$data["Transaction_Id"],$data["API_Type"],$data["Pancard_Amount"],$data["Trans_Status"],$data["Vleid"],
						$data["Tokens"],$data["Tokens_no"],$data["Service"],$data["Service_provider"],$data["Panno"],$data["Location"],$data["Pancode"],
						$data["Panprice"],$data["Pancardprice"]);
						
						fputcsv($handle, $keyArray);
						$i++;
					}
						fclose($handle);
					exit;
				}else{
					$this->middle = 'Admin/Pancard/index'; 
					$this->layout();     
				}
				}
			   else {
				 redirect(base_url());
		     }
		   }
	}