    <?php
		class Aadharpay extends MY_Controller {
			public function __construct(){
			parent::__construct();
			$this->load->database();
			$this->load->model('Aadharpay_model');
			date_default_timezone_set('Asia/Kolkata');
			//set_time_limit(0);
			ini_set('memory_limit', '200000M');
			
			$this->coloum = array('aID','Branch_Name','Branch_Login_Id','Employee_Name','Customer_Aadhaar_Number','Customer_Phone_Number',
			'Customer_bank_Name','Remarks','Response_Remarks','Requested_Timestamp','Fingpay_Transaction_Id','Stan','Response_RRN','Latitude',
			'Logitude','Device_IMEI','Employee_Id','Response_Time','Response_Date','Aggregator_Name','Corporate_Name','aStatus','Terminal_Id',
			'Transaction_Identifier','Response_Timestamp','Web_Status','Response_Terminal_Id','Employee_Transaction_Id',
			'Transaction_Amount','Response_Account_Id','Beneficiary_Identification_Code','status','message');
			
		 }
		 
		  public function add(){ 
			 if(!empty($this->session->userdata('logged_in'))){
				$this->middle = 'Admin/Aadharpay/add'; 
				$this->layout();  
			 }else {
				 redirect(base_url());
		     }			
		   }
		 
		   
		   public function save(){
			  if(!empty($this->session->userdata('logged_in'))){
				$pgArray = array();
				$aepsArray = array();
				require_once APPPATH . "/third_party/PHPExcel.php";
				if(filecheck_method($_FILES)){
				if ($_FILES['file']['name']) {
					$path=$_FILES['file']['tmp_name'];
					$object = PHPExcel_IOFactory::load($path);
					foreach ($object->getworksheetIterator() as $worksheet) {
						$highestRow= $worksheet->getHighestRow();
						$highestColumn = $worksheet->getHighestColumn();
						for($row=2; $row<=$highestRow; $row++)
						{
							$headings  = $worksheet->rangeToArray('A1:'.$highestColumn.'1', NULL, TRUE, FALSE);
							$rowData = $worksheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                                            NULL,
                                            TRUE,
                                            FALSE);
							array_push($aepsArray,$rowData[0]);
					    }
					  }
					   foreach($aepsArray as $i=>$data){
						foreach($this->coloum as $j=>$coldata){
							$KeyArray[$i][$coldata] = $data[$j];
					  }
					} 
				    //echo "<pre>";print_r($KeyArray);die;
					$this->Aadharpay_model->saveData($KeyArray);
				}else{
					$this->middle = 'Admin/Aadharpay/add'; 
				    $this->layout();  
				}
				}
				}
			   else {
				 redirect(base_url());
		     }
		   }
		   
		   public function index(){
			  if(!empty($this->session->userdata('logged_in'))){
				$search_str = $this->input->get("search_str");
				$to_date = $this->input->get("to_date");
				if($search_str!="" || $to_date!=""){
					$data["getReport"] = $this->Aadharpay_model->getData($search_str,$to_date);
				    ob_clean();
					header("Content-type: application/csv");
					header("Content-Disposition: attachment; filename=\"Aadharpay".".csv\"");
					header("Pragma: no-cache");
					header("Expires: 0");
					$handle = fopen('php://output', 'w');
					fputcsv($handle, $this->coloum);
					$i = 1;
					foreach ($data["getReport"] as $data) {
						$keyArray = array($data["aID"],$data["Branch_Name"],$data["Branch_Login_Id"],$data["Employee_Name"],
						$data["Customer_Aadhaar_Number"],$data["Customer_Phone_Number"],$data["Customer_bank_Name"],$data["Remarks"],$data["Response_Remarks"],$data["Requested_Timestamp"],
						$data["Fingpay_Transaction_Id"],$data["Stan"],$data["Response_RRN"],$data["Latitude"],$data["Logitude"],
						$data["Device_IMEI"],$data["Employee_Id"],$data["Response_Time"],$data["Response_Date"],$data["Aggregator_Name"],$data["Corporate_Name"],$data["aStatus"],
						$data["Terminal_Id"],$data["Transaction_Identifier"],$data["Response_Timestamp"],$data["Web_Status"],$data["Response_Terminal_Id"],$data["Employee_Transaction_Id"],
						$data["Transaction_Amount"],$data["Response_Account_Id"],$data["Beneficiary_Identification_Code"],$data["status"],$data["message"]);
						
						fputcsv($handle, $keyArray);
						$i++;
					}
						fclose($handle);
					exit;
				}else{
					$this->middle = 'Admin/Aadharpay/index'; 
					$this->layout();     
				}
				}
			   else {
				 redirect(base_url());
		     }
		   }
	}