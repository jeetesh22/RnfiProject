<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="<?php echo base_url();?>user/dashboard">Home</a>
							</li>

							<li>
								<a href="#">Import</a>
							</li>
							<li class="active"Jri</li>
						</ul><!-- /.breadcrumb -->
					</div>

					<div class="page-content">
					<?php if($this->session->flashdata('message')) { ?>
					  <div class="alert alert-success alert-dismissible">
					  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					   <?php echo $this->session->flashdata('message') ?>; 
					  </div>
					 <?php } ?>
					 <div id="usermessage"></div>
					<div class="row">
                                        <div class="col-xs-12">
                                            <form style="border:1px solid #d5d5d5;padding:10px 0 25px 20px" action="<?php echo base_url(); ?>jri/save" method="post" enctype='multipart/form-data'>
                                                <div class="row">
                                                    <div class="col-md-11">
													
													<div class="form-group">
														<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Jri csv/xlsx file <span class="star">*</span></label>
														<input type="file" name="file" placeholder="Add xlxs and csv file" class="form-control">
													</div>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-11">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                              <input type="submit" style="background: rgb(67, 142, 185) none repeat scroll 0% 0%; color: rgb(255, 255, 255); border-radius: 3px; padding: 3px 32px; font-size: 15px; font-family: open sans; font-weight: normal; border: medium none; margin-top: 15px;float:right; position: relative" value="Submit">  
                                                              <span style="position:absolute;right:25px;top:20px"><i class="fa fa-arrow-circle-right" aria-hidden="true" style="color:white"></i></span>  
                                                              <a href="<?php echo base_url(); ?>jri/index" style="background: rgb(67, 142, 185) none repeat scroll 0% 0%; color: rgb(255, 255, 255); border-radius: 3px; padding: 3px 32px; font-size: 15px; font-family: open sans; font-weight: normal; border: medium none; margin: 15px;float:right;text-decoration:none;">Reset <i class="fa fa-times-circle" aria-hidden="true"></i></a>  
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                            <br>
                                        </div>
                                    </div>
						
					</div><!-- /.page-content -->
				</div>
			</div>