<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="<?php echo base_url();?>user/dashboard">Home</a>
							</li>

							<li>
								<a href="#">Aeps RBL</a>
							</li>
							<li class="active">Record</li>
						</ul><!-- /.breadcrumb -->
					</div>

					<div class="page-content">
					<?php if($this->session->flashdata('message')) { ?>
					  <div class="alert alert-success alert-dismissible">
					  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					   <?php echo $this->session->flashdata('message') ?>; 
					  </div>
					 <?php } ?>
					 <div id="usermessage"></div>
					<div class="row">
                                        <div class="col-xs-12">
                                            <form style="border:1px solid #d5d5d5;padding:10px 0 25px 20px" action="<?php echo base_url(); ?>aeps/indexrbl" method="get">
                                                <div class="row">
                                                    <div class="col-md-11">
                                                        <div class="row">
                                                            <div class="col-sm-6">
                                                                <label class="control-label no-padding-right" for="form-field-1"> Search Aeps RBL&nbsp;&nbsp;&nbsp; </label>
                                                                <input type="search" name="search_str" class="form-control" value="" class="form-control input-sm" placeholder="Search Aeps(Seq_No)" aria-controls="dynamic-table" autocomplete="off">
                                                            </div>
															 <div class="col-sm-6">
                                                                <label class="control-label no-padding-right" for="form-field-1">Date&nbsp;&nbsp;&nbsp; </label>
                                                                <input class="col-xs-10 col-sm-5 date-picker form-control" name="to_date" placeholder="Date"  id="startdate" type="text" value="<?php
                                                                    if ($this->input->get('from_date')) {
                                                                        echo date('d-m-Y', strtotime($this->input->get('from_date')));
                                                                    }
                                                                    ?>" data-date-format="yyyy-mm-dd" autocomplete="off"/>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-11">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                              <input type="submit" style="background: rgb(67, 142, 185) none repeat scroll 0% 0%; color: rgb(255, 255, 255); border-radius: 3px; padding: 3px 32px; font-size: 15px; font-family: open sans; font-weight: normal; border: medium none; margin-top: 15px;float:right; position: relative" value="Search">  
                                                              <span style="position:absolute;right:25px;top:20px"><i class="fa fa-arrow-circle-right" aria-hidden="true" style="color:white"></i></span>  
                                                              <a href="<?php echo base_url(); ?>aeps/indexrbl" style="background: rgb(67, 142, 185) none repeat scroll 0% 0%; color: rgb(255, 255, 255); border-radius: 3px; padding: 3px 32px; font-size: 15px; font-family: open sans; font-weight: normal; border: medium none; margin: 15px;float:right;text-decoration:none;">Reset <i class="fa fa-times-circle" aria-hidden="true"></i></a>  
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                            <br>
                                        </div>
                                    </div>
						
					</div><!-- /.page-content -->
				</div>
			</div>