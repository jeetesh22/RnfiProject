	<div class="main-content">
			<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>
							<li>
								<a href="#">User</a>
							</li>
							<li class="active"><?php $loggedInArr = $this->session->userdata('logged_in');
							  $is_admin = $loggedInArr['is_admin'];
							  $uid = $loggedInArr['uid'];
							  if($is_admin==0 && $uid!=""){
								  echo $loggedInArr['username']."( <b>".$loggedInArr['emailid']."</b> )";
							  } ?>
							</li>
						</ul>
					</div>

					<div class="page-content">
						<div class="row">
							<div class="col-xs-12">
							  <div class="row">
								<div class="col-xs-12">
									<table id="simple-table" class="table  table-bordered table-hover">
										<thead>
											<tr>
												<th>S.No</th>
												<th>BankName</th>
												<th>Corporate Id</th>
												<th>UserName</th>
												<th>Mobile No</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
										<?php $allBanks = $this->Bank_model->getAllBank();
											if(!empty($bankDetails)){?>
										<?php foreach($bankDetails as $j=>$bankDetail){
											  foreach($bankDetail["details"] as $j=>$bank){ 
											  
											   $bankName ="";
											  foreach($allBanks as $k=> $allbank){
												  if(md5($allbank["id"]) == $bank['bank_id'] ){
													  $bankName = $allbank["name"];
												  }
												}
											  ?>
											<tr>
												<td><?php echo $j+1;?></a></td>
												<td><?php echo $bankName;?></td>
												<td><?php echo $bank['corporate_id'];?></td>
												<td><?php echo $bank['username'];?></td>
												<td><?php echo ($bank['mobile_no']);?></td>
												<td>
													<div class="hidden-sm hidden-xs btn-group">
													<a href="#"><button class="btn btn-xs btn-warning" data-toggle="modal" data-target="#myModal" title="Show Password" onclick="showBankDPassword('<?php echo $bank['id'];?>')">
															<i class="ace-icon fa fa-key bigger-120"></i>
														</button></a>
													</div>
												</td>
											</tr> 
												<?php }} ?>
										  <?php }else{?>
										  <tr><td colspan="8" align="center">No Data Found</td></tr>
										  <?php } ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
			     </div>
			</div>	
	</div>
	<div class="modal fade show_password" id="myModal" role="dialog"></div>