	<div class="main-content">
			<div class="main-content-inner">
				<div class="breadcrumbs ace-save-state" id="breadcrumbs">
					<ul class="breadcrumb">
						<li>
							<i class="ace-icon fa fa-home home-icon"></i>
							<a href="<?php echo base_url();?>user/dashboard">Home</a>
						</li>

						<li>
							<a href="#">User</a>
						</li>
						<li class="active">Dashboard</li>
					</ul><!-- /.breadcrumb -->
				</div>

				<div class="page-content">
			 </div>
			</div>
	</div>