		<div class="main-content">
			<div class="main-content-inner">
				<div class="breadcrumbs ace-save-state" id="breadcrumbs">
					<ul class="breadcrumb">
						<li>
							<i class="ace-icon fa fa-home home-icon"></i>
							<a href="<?php echo base_url();?>user/dashboard">Home</a>
						</li>
						<li class="active">Dashboard</li>
					</ul>
				</div>

				<div class="page-content">
				 <?php if($this->session->flashdata('message')) { ?>
					  <div class="alert alert-success alert-dismissible">
					  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					  <?php echo $this->session->flashdata('message') ?>; 
					  </div>
				<?php } ?>
						<div class="row">
								<div class="col-xs-12">
									<!-- PAGE CONTENT BEGINS -->
									<div class="row">
										<div class="col-xs-12">
											<table id="simple-table" class="table  table-bordered table-hover">
											<thead>
												<tr>
													<th width="10%">S.No</th>
													<th width="15%">Module name</th>
													<th width="75%">Action</th>
												</tr>
											</thead>
											<tbody>
											<?php if(!empty($allModules)){?>
											<?php foreach($allModules as $i=>$module){?>
												<tr>
													<td><?php echo $i+1;?></a></td>
													<td><?php echo $module['module_name'];?></td>
													<td>
													<?php foreach($module["innerpage"] as $i=>$innerpage){?>
													<a href="<?php echo base_url($innerpage["Inner_page_url"]); ?>"><?php echo $innerpage["Inner_page"];?></a> <b>,</b>
													<?php	} ?>
													</td>
												</tr>
											<?php }   ?>
										    <?php }else{?>
										      <tr><td colspan="8" align="center">No Data Found</td></tr>
										    <?php } ?>
											</tbody>
										</table>
									</div><!-- /.span -->
									
								</div><!-- /.row -->
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div>
				</div>
				
			</div>
		</div>