										 
					<ul class="nav nav-list" style="top: 0px;">
					<li class="active">
						<a href="<?php echo base_url('user/dashboard');?>">
							<i class="menu-icon fa fa-tachometer"></i>
							<span class="menu-text">User Dashboard </span>
						</a>
						<b class="arrow"></b>
					</li>
					
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-list"></i>
							<span class="menu-text">Agents</span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>

						<ul class="submenu nav-hide" style="display: none;">
							<li class="">
								<a href="<?php echo base_url('agent/index'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									List Agent
								</a>
								<b class="arrow"></b>
							</li>
							
							<li class="">
								<a href="<?php echo base_url('agent/todaycallback'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									Today Callback
								</a>
								<b class="arrow"></b>
							</li>
							
							<li class="">
								<a href="<?php echo base_url('agent/userlockagent'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									Lock Agent
								</a>
								<b class="arrow"></b>
							</li>
							
						</ul>
					</li>
					
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-list"></i>
							<span class="menu-text">Report</span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>

						<ul class="submenu nav-hide" style="display: none;">
							<li class="">
								<a href="<?php echo base_url('report/agent_campaign'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									Campaign Report
								</a>
								<b class="arrow"></b>
							</li>
							
						</ul>
					</li>
				</ul>