	    <ul class="nav nav-list" style="top: 0px;">
			<li class="active">
				<a href="<?php echo base_url();?>user/dashboard">
					<i class="menu-icon fa fa-tachometer"></i>
					<span class="menu-text"> Dashboard </span>
				</a>
				<b class="arrow"></b>
			</li>

					<?php $CI =& get_instance();
							$CI->load->model('Innerpage_module');
							$result = $CI->Innerpage_module->getInnerModule();
					foreach($result as $i=>$page){?>		
					<li class="">
						<a href="#" class="dropdown-toggle">
							<?php echo $page["module_icon"];?>
							<span class="menu-text"><?php echo $page["module_name"];?> </span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>
						
						<ul class="submenu nav-hide" style="display: none;">
						<?php foreach($page["innerpage"] as $i=>$innerpage){?>	
							<li class="">
								<a href="<?php echo base_url($innerpage["Inner_page_url"]); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									<?php echo $innerpage["Inner_page"];?>
								</a>
								<b class="arrow"></b>
							</li>
							<?php } ?>
						</ul>
						
					</li>
					<?php } ?>
					
		</ul>