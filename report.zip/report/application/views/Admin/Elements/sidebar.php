<div id="sidebar" class="sidebar responsive ace-save-state" data-sidebar="true" data-sidebar-scroll="true" data-sidebar-hover="true">
				<script type="text/javascript">
					try{ace.settings.loadState('sidebar')}catch(e){}
				</script>
				<?php $loggedInArr = $this->session->userdata('logged_in');
					  $is_admin = $loggedInArr['is_admin'];
					  $uid = $loggedInArr['uid'];
					  if($is_admin==0 && $uid!=""){ ?>
				      <?php $this->load->view('Admin/Elements/user_sidebar');?>
				<?php }else{?>
					 <?php $this->load->view('Admin/Elements/admin_sidebar');?>
				<?php } ?>

				

				<div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
					<i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
				</div>
			</div>