<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	$CI =& get_instance();
	if ( ! function_exists('filecheck_method'))
	{
		function filecheck_method($var = '')
		{		
				$CI =& get_instance();
				$allowed_mime_types = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
				if(isset($_FILES['file']['name']) && $_FILES['file']['name'] != ""){
					$mime = get_mime_by_extension($_FILES['file']['name']); 
					$fileAr = explode('.', $_FILES['file']['name']);
					$ext = end($fileAr); 
					if(($ext == 'csv' || $ext == 'xlsx')){ 
						return true;
					}else{ 
						$CI->session->set_flashdata('message', 'Please select only CSV and XlSX file to upload.');
						redirect(base_url('user/dashboard'));
					}
				}else{ 
					$CI->session->set_flashdata('message', 'Please select a CSV and XlSX file to upload.');
					redirect(base_url('user/dashboard'));
				}
		}   
	}