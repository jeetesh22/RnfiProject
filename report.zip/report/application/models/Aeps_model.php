<?php
  class Aeps_model extends CI_Model
   {
	   public function __construct(){
			parent::__construct();
			$this->load->database();
			date_default_timezone_set('Asia/Kolkata');
		 }
   
	 public function saveData($KeyArray){
            $result =  $this->db->insert_batch('aeps',$KeyArray);
			if($result){
			  $this->session->set_flashdata("message","Aeps is successfully save!");
			  redirect(base_url('aeps/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('aeps/add'));
			}	
	 }
	 
	 public function getData($search_str,$to_date){
		    $this->db->select('*');
			$this->db->from('aeps');
			if($to_date!="")
			{
				$this->db->where("created_at LIKE","%".date("Y-m-d",strtotime($to_date))."%");
			}
			
			if($search_str!=false)
			{
				$this->db->where("aId LIKE","%".$search_str."%");
			}
			$query = $this->db->get();
			return  $query->result_array();
	 }
	 
	 //AEPS CMS
	  public function savecmsData($KeyArray){
            $result =  $this->db->insert_batch('aepscms',$KeyArray);
			if($result){
			  $this->session->set_flashdata("message","Aeps Cms is successfully save!");
			  redirect(base_url('aeps/indexcms'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('aeps/addcms'));
			}	
	 }
	 
	 public function getcmsData($search_str,$to_date){
		    $this->db->select('*');
			$this->db->from('aepscms');
			if($to_date!="")
			{
				$this->db->where("created_at LIKE","%".date("Y-m-d",strtotime($to_date))."%");
			}
			
			if($search_str!=false)
			{
				$this->db->where("aId LIKE","%".$search_str."%");
			}
			$query = $this->db->get();
			return  $query->result_array();
	 }
	 
	  //AEPS RBL
	  public function saverblData($KeyArray){
            $result =  $this->db->insert_batch('aepsrbl',$KeyArray);
			if($result){
			  $this->session->set_flashdata("message","Aeps RBL is successfully save!");
			  redirect(base_url('aeps/indexrbl'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('aeps/addrbl'));
			}	
	 }
	 
	 public function getrblData($search_str,$to_date){
		    $this->db->select('*');
			$this->db->from('aepsrbl');
			if($to_date!="")
			{
				$this->db->where("created_at LIKE","%".date("Y-m-d",strtotime($to_date))."%");
			}
			
			if($search_str!=false)
			{
				$this->db->where("Seq_No LIKE","%".$search_str."%");
			}
			$query = $this->db->get();
			return  $query->result_array();
	 }

		
	
  }