<?php
  class Irctcbooking_model extends CI_Model
   {
	   public function __construct(){
			parent::__construct();
			$this->load->database();
			date_default_timezone_set('Asia/Kolkata');
		 }
   
	 public function saveData($KeyArray){
            $result =  $this->db->insert_batch('irctcbooking',$KeyArray);
			if($result){
			  $this->session->set_flashdata("message","Irctcbooking is successfully save!");
			  redirect(base_url('irctcbooking/indexbooking'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('irctcbooking/addbooking'));
			}	
	 }
	 
	 public function getData($search_str,$to_date){
		    $this->db->select('*');
			$this->db->from('irctcbooking');
			if($to_date!="")
			{
				$this->db->where("created_at LIKE","%".date("Y-m-d",strtotime($to_date))."%");
			}
			
			if($search_str!=false)
			{
				$this->db->where("TRANSACTION_ID LIKE","%".$search_str."%");
			}
			$query = $this->db->get();
			return  $query->result_array();
	 }
	 
	 //Refund
	  public function saverefundData($KeyArray){
            $result =  $this->db->insert_batch('irctc_cancelrefundreport',$KeyArray);
			if($result){
			  $this->session->set_flashdata("message","Irctrefund is successfully save!");
			  redirect(base_url('irctcbooking/indexrefund'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('irctcbooking/addrefund'));
			}	
	 }
	 
	 public function getrefundData($search_str,$to_date){
		    $this->db->select('*');
			$this->db->from('irctc_cancelrefundreport');
			if($to_date!="")
			{
				$this->db->where("created_at LIKE","%".date("Y-m-d",strtotime($to_date))."%");
			}
			
			if($search_str!=false)
			{
				$this->db->where("TRANSACTION_ID LIKE","%".$search_str."%");
			}
			$query = $this->db->get();
			return  $query->result_array();
	 }
	 

		
	
  }