<?php
  class Pggateway_model extends CI_Model
   {
	   public function __construct(){
			parent::__construct();
			$this->load->database();
			date_default_timezone_set('Asia/Kolkata');
		 }
   
	 public function savePgData($pgKeyArray){
            $result =  $this->db->insert_batch('pggatway',$pgKeyArray);
			if($result){
			  $this->session->set_flashdata("message","Pggateway is successfully save!");
			  redirect(base_url('pggatway/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('pggatway/add'));
			}	
	 }
	 
	 public function getPggatewayData($search_str,$to_date){
		    $this->db->select('*');
			$this->db->from('pggatway');
			if($to_date!="")
			{
				$this->db->where("created_at LIKE","%".date("Y-m-d",strtotime($to_date))."%");
			}
			
			if($search_str!=false)
			{
				$this->db->where("Order_ID LIKE","%".$search_str."%");
			}
			$query = $this->db->get();
			return  $query->result_array();
	 }

		
	
  }