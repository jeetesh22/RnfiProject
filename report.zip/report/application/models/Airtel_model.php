<?php
  class Airtel_model extends CI_Model
   {
	   public function __construct(){
			parent::__construct();
			$this->load->database();
			date_default_timezone_set('Asia/Kolkata');
		 }
   //Airtelswiggy
	 public function saveData($KeyArray){
            $result =  $this->db->insert_batch('airtelswiggy',$KeyArray);
			if($result){
			  $this->session->set_flashdata("message","Airtelswiggy is successfully save!");
			  redirect(base_url('airtel/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('airtel/add'));
			}	
	 }
	 
	 public function getData($search_str,$to_date){
		    $this->db->select('*');
			$this->db->from('airtelswiggy');
			if($to_date!="")
			{
				$this->db->where("created_at LIKE","%".date("Y-m-d",strtotime($to_date))."%");
			}
			
			if($search_str!=false)
			{
				$this->db->where("APB_TXN_id LIKE","%".$search_str."%");
			}
			$query = $this->db->get();
			return  $query->result_array();
	 }	
	//Airtel
	
	public function saveAirtelData($KeyArray){
            $result =  $this->db->insert_batch('airtel',$KeyArray);
			if($result){
			  $this->session->set_flashdata("message","Airtels is successfully save!");
			  redirect(base_url('airtel/indexairtel'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('airtel/addairtel'));
			}	
	 }
	 
	 public function getAirtelData($search_str,$to_date){
		    $this->db->select('*');
			$this->db->from('airtel');
			if($to_date!="")
			{
				$this->db->where("created_at LIKE","%".date("Y-m-d",strtotime($to_date))."%");
			}
			
			if($search_str!=false)
			{
				$this->db->where("Transaction_Number LIKE","%".$search_str."%");
			}
			$query = $this->db->get();
			return  $query->result_array();
	 }	
  }