<?php
  class Mobikwikwallet_model extends CI_Model
   {
	   public function __construct(){
			parent::__construct();
			$this->load->database();
			date_default_timezone_set('Asia/Kolkata');
		 }
   
	 public function saveData($KeyArray){
            $result =  $this->db->insert_batch('mobikwikwallet',$KeyArray);
			if($result){
			  $this->session->set_flashdata("message","Mobikwikwallet is successfully save!");
			  redirect(base_url('mobikwikwallet/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('mobikwikwallet/add'));
			}	
	 }
	 
	 public function getData($search_str,$to_date){
		    $this->db->select('*');
			$this->db->from('mobikwikwallet');
			if($to_date!="")
			{
				$this->db->where("created_at LIKE","%".date("Y-m-d",strtotime($to_date))."%");
			}
			
			if($search_str!=false)
			{
				$this->db->where("OrderID LIKE","%".$search_str."%");
			}
			$query = $this->db->get();
			return  $query->result_array();
	 }	
	
  }