<?php
  class Aadharpay_model extends CI_Model
   {
	   public function __construct(){
			parent::__construct();
			$this->load->database();
			date_default_timezone_set('Asia/Kolkata');
		 }
   
	 public function saveData($KeyArray){
            $result =  $this->db->insert_batch('aadharpay',$KeyArray);
			if($result){
			  $this->session->set_flashdata("message","Aadharpay is successfully save!");
			  redirect(base_url('aadharpay/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('aadharpay/add'));
			}	
	 }
	 
	 public function getData($search_str,$to_date){
		    $this->db->select('*');
			$this->db->from('aadharpay');
			if($to_date!="")
			{
				$this->db->where("created_at LIKE","%".date("Y-m-d",strtotime($to_date))."%");
			}
			
			if($search_str!=false)
			{
				$this->db->where("Employee_Name LIKE","%".$search_str."%");
			}
			$query = $this->db->get();
			return  $query->result_array();
	 }	
	
  }