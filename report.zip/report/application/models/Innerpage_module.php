<?php
  class Innerpage_module extends CI_Model
   {
	   public function __construct(){
			parent::__construct();
			$this->load->database();
			date_default_timezone_set('Asia/Kolkata');
			$this->loggedInArr = $this->session->userdata('logged_in');
		 }
   
	 public function getInnerModule(){
			$this->db->select('id,module_name,module_icon');
			$this->db->from('modulemaster');
			$query = $this->db->get();
			$pageArr = array();
			if ( $query->num_rows() > 0 )
			{
			 foreach($query->result_array() as $i=>$page){
				 $data["id"] = $page["id"];
				 $data["module_name"] = $page["module_name"];
				 $data["module_icon"] = $page["module_icon"];
				 $data["innerpage"] = $this->getInnerpage($page["id"]);
				 array_push($pageArr,$data);
			 }
			}
			return $pageArr;	
		}
		
	 public function getInnerpage($id){
		    $this->db->select('id,Inner_page,Inner_page_url');
			$this->db->from('moduleinnerpage');
			$this->db->where('Module',$id);
			$query = $this->db->get();
			$innerpageArr =array();
			if($query->num_rows() > 0 )
			{
			 $result = $query->result_array();
			 return $result;		
			}
		 	
	 }
		

		
	
  }