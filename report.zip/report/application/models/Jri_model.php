<?php
  class Jri_model extends CI_Model
   {
	   public function __construct(){
			parent::__construct();
			$this->load->database();
			date_default_timezone_set('Asia/Kolkata');
		 }
   
	 public function saveData($KeyArray){
            $result =  $this->db->insert_batch('jri',$KeyArray);
			if($result){
			  $this->session->set_flashdata("message","Jri is successfully save!");
			  redirect(base_url('jri/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('jri/add'));
			}	
	 }
	 
	 public function getData($search_str,$to_date){
		    $this->db->select('*');
			$this->db->from('jri');
			if($to_date!="")
			{
				$this->db->where("created_at LIKE","%".date("Y-m-d",strtotime($to_date))."%");
			}
			
			if($search_str!=false)
			{
				$this->db->where("Order_No LIKE","%".$search_str."%");
			}
			$query = $this->db->get();
			return  $query->result_array();
	 }	
	
  }