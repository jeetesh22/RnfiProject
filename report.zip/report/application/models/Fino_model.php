<?php
  class Fino_model extends CI_Model
   {
	   public function __construct(){
			parent::__construct();
			$this->load->database();
			date_default_timezone_set('Asia/Kolkata');
		 }
   //Fino
	 public function saveData($KeyArray){
            $result =  $this->db->insert_batch('fino',$KeyArray);
			if($result){
			  $this->session->set_flashdata("message","Fino is successfully save!");
			  redirect(base_url('fino/indexfino'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('fino/addfino'));
			}	
	 }
	 
	 public function getData($search_str,$to_date){
		    $this->db->select('*');
			$this->db->from('fino');
			if($to_date!="")
			{
				$this->db->where("created_at LIKE","%".date("Y-m-d",strtotime($to_date))."%");
			}
			
			if($search_str!=false)
			{
				$this->db->where("Client_Txn_Id LIKE","%".$search_str."%");
			}
			$query = $this->db->get();
			return  $query->result_array();
	 }	
	//FinoMatm
	 public function savematmData($KeyArray){
            $result =  $this->db->insert_batch('finomatm',$KeyArray);
			if($result){
			  $this->session->set_flashdata("message","FinoMatm is successfully save!");
			  redirect(base_url('fino/indexmatm'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('fino/addmatm'));
			}	
	 }
	 
	 public function getmatmData($search_str,$to_date){
		    $this->db->select('*');
			$this->db->from('finomatm');
			if($to_date!="")
			{
				$this->db->where("created_at LIKE","%".date("Y-m-d",strtotime($to_date))."%");
			}
			
			if($search_str!=false)
			{
				$this->db->where("Client_Txn_Id LIKE","%".$search_str."%");
			}
			$query = $this->db->get();
			return  $query->result_array();
	 }	
  }