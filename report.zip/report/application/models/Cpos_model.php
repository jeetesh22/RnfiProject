<?php
  class Cpos_model extends CI_Model
   {
	   public function __construct(){
			parent::__construct();
			$this->load->database();
			date_default_timezone_set('Asia/Kolkata');
		 }
   
	 public function saveData($KeyArray){
            $result =  $this->db->insert_batch('cpos_mpos',$KeyArray);
			if($result){
			  $this->session->set_flashdata("message","CposMpos is successfully save!");
			  redirect(base_url('cpos/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('cpos/add'));
			}	
	 }
	 
	 public function getData($search_str,$to_date){
		    $this->db->select('*');
			$this->db->from('cpos_mpos');
			if($to_date!="")
			{
				$this->db->where("created_at LIKE","%".date("Y-m-d",strtotime($to_date))."%");
			}
			
			if($search_str!=false)
			{
				$this->db->where("Merchant_Id LIKE","%".$search_str."%");
			}
			$query = $this->db->get();
			return  $query->result_array();
	 }	
	
  }