-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 23, 2020 at 11:38 AM
-- Server version: 5.7.31
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crmrnfib_iciciagent`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(150) NOT NULL,
  `password` text NOT NULL,
  `mobile_no` varchar(30) NOT NULL,
  `created` datetime NOT NULL,
  `modify` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `username`, `password`, `mobile_no`, `created`, `modify`) VALUES
(1, 'admin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '9999110680', '2020-06-29 04:12:08', '2020-07-22 15:15:13'),
(2, 'r.suresh@rnfiservices.com', 'e10adc3949ba59abbe56e057f20f883e', '9384098861', '2020-06-29 04:12:08', '2020-07-22 15:43:50');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_otp`
--

CREATE TABLE `tbl_admin_otp` (
  `id` int(11) NOT NULL,
  `adminid` int(11) NOT NULL,
  `otp` int(11) NOT NULL,
  `api_response` text NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT '1' COMMENT '1->Active,0->NOt Active',
  `is_admin` int(11) NOT NULL DEFAULT '1' COMMENT '1->Admin,0->User',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin_otp`
--

INSERT INTO `tbl_admin_otp` (`id`, `adminid`, `otp`, `api_response`, `is_active`, `is_admin`, `created_at`, `modify_at`) VALUES
(1, 1, 791295, '\"status=success | mobile=919999110680 | invalidMobile= | transactionId=6872310816961414511 | errorCode=200 | reason=success\"', 0, 1, '2020-07-22 15:35:57', '2020-07-22 15:36:05'),
(2, 11, 357800, '\"status=success | mobile=919999110680 | invalidMobile= | transactionId=5219986721437994158 | errorCode=200 | reason=success\"', 0, 0, '2020-07-22 15:38:56', '2020-07-22 15:39:08'),
(3, 2, 803840, '\"status=success | mobile=919384098861 | invalidMobile= | transactionId=6309345810717689361 | errorCode=200 | reason=success\"', 0, 1, '2020-07-23 04:54:10', '2020-07-23 04:54:26'),
(4, 2, 144963, '\"status=success | mobile=919384098861 | invalidMobile= | transactionId=5370889718377170828 | errorCode=200 | reason=success\"', 0, 1, '2020-07-23 04:57:06', '2020-07-23 04:57:26'),
(5, 11, 992820, '\"status=success | mobile=919999110680 | invalidMobile= | transactionId=7614035115228286333 | errorCode=200 | reason=success\"', 0, 0, '2020-07-23 05:17:38', '2020-07-23 05:17:55'),
(6, 11, 854013, '\"status=success | mobile=919999110680 | invalidMobile= | transactionId=1027076612019078112 | errorCode=200 | reason=success\"', 0, 0, '2020-07-23 05:25:56', '2020-07-23 05:28:41'),
(7, 1, 776551, '\"status=success | mobile=919999110680 | invalidMobile= | transactionId=2769870778514820936 | errorCode=200 | reason=success\"', 0, 1, '2020-07-23 05:33:33', '2020-07-23 05:33:56'),
(8, 11, 895788, '\"status=success | mobile=919999110680 | invalidMobile= | transactionId=8959350144446779105 | errorCode=200 | reason=success\"', 0, 0, '2020-07-23 05:35:35', '2020-07-23 05:35:52');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_agbusiness`
--

CREATE TABLE `tbl_agbusiness` (
  `id` int(11) NOT NULL,
  `agent_id` int(11) NOT NULL,
  `agent_code` varchar(20) NOT NULL,
  `mobile_no` varchar(20) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `firmname` varchar(100) NOT NULL,
  `vstscode` varchar(30) NOT NULL,
  `addeddate` datetime NOT NULL,
  `userdetails` text NOT NULL,
  `business` text NOT NULL,
  `created_at` datetime NOT NULL,
  `modify_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_agbusiness`
--

INSERT INTO `tbl_agbusiness` (`id`, `agent_id`, `agent_code`, `mobile_no`, `email_id`, `name`, `firmname`, `vstscode`, `addeddate`, `userdetails`, `business`, `created_at`, `modify_at`) VALUES
(3, 2, 'R004002', '9811790927', 'DHARM@RNFISERVICES.IN', 'DHARMENDRA KUMAR SINGH', 'NITESH ENTERPRISES', 'RS002342', '2018-01-11 17:54:22', '{\"id\":\"20177677\",\"name\":\"DHARMENDRA KUMAR SINGH\",\"firmname\":\"NITESH ENTERPRISES\",\"phone\":\"9811790927\",\"email\":\"DHARM@RNFISERVICES.IN\",\"addeddate\":\"2018-01-11 17:54:22\",\"DmtCommType\":\"CNP\",\"AepsCommType\":\"CNP\",\"vstscode\":\"RS002342\",\"aeps\":\"Active\",\"matm\":\"Active\",\"bill\":\"Active\",\"isicicibc\":\"InActive\",\"isrelipaybc\":\"Active\",\"railway\":\"Active\",\"aadhaarpay\":\"Active\",\"CashDrop\":\"Active\",\"cms\":\"Active\"}', '{\"2019-07\":{\"Bill Payment\":\"1.00\"},\"2020-05\":{\"DMT\":\"100.00\",\"PAYTM Wallet\":\"602.00\"},\"2020-06\":{\"MATM\\/AEPS\\/CPOS\":\"400.00\",\"DMT\":\"10.00\",\"PG DMT\":\"200.00\",\"PAYTM Wallet\":\"100.00\"},\"2020-07\":{\"Bill Payment\":\"10.00\",\"AEPS\\/POS DMT\":\"800.00\",\"DropCash\":\"1.00\",\"DMT\":\"15.00\",\"PG\":\"2100.00\",\"PG DMT\":\"2100.00\"}}', '2020-07-23 10:56:01', '2020-07-23 05:26:01'),
(4, 1, 'R003032', '9811790927', 'RANVEER@RNFISERVICES.COM', 'JASDEEP ANAND', 'RAJAN ENTERPRISES', 'S503015', '2017-12-11 20:49:14', '{\"id\":\"20176696\",\"name\":\"JASDEEP ANAND\",\"firmname\":\"RAJAN ENTERPRISES\",\"phone\":\"9811790927\",\"email\":\"RANVEER@RNFISERVICES.COM\",\"addeddate\":\"2017-12-11 20:49:14\",\"DmtCommType\":\"CNP\",\"AepsCommType\":\"CNP\",\"vstscode\":\"S503015\",\"aeps\":\"Active\",\"matm\":\"Active\",\"bill\":\"Active\",\"isicicibc\":\"InActive\",\"isrelipaybc\":\"Active\",\"railway\":\"Active\",\"aadhaarpay\":\"Active\",\"CashDrop\":\"Active\",\"cms\":\"Active\"}', '{\"2020-02\":{\"PG DMT\":\"100.00\"},\"2020-04\":{\"Recharge\":\"75.00\",\"MATM\\/AEPS\\/CPOS\":\"1878.00\",\"DMT\":\"2545.00\",\"Mini Statement\":\"0.00\"},\"2020-05\":{\"Recharge\":\"10.00\",\"MATM\\/AEPS\\/CPOS\":\"1400.00\",\"DropCash\":\"1772.00\",\"DMT\":\"11751.00\",\"PG\":\"8200.00\",\"Mini Statement\":\"0.00\",\"PAYTM Wallet\":\"4421.00\"},\"2020-06\":{\"Recharge\":\"360.00\",\"FLIGHT\":\"4423.00\",\"MATM\\/AEPS\\/CPOS\":\"1600.00\",\"MPOS \\/ AP\":\"405.00\",\"DropCash\":\"9.00\",\"DMT\":\"2916.00\",\"PG\":\"400.00\",\"MATM Activation Deposit\":\"800.00\",\"CASH IN\":\"11141.00\",\"PG DMT\":\"100.00\",\"Mini Statement\":\"0.00\",\"PAYTM Wallet\":\"2705.00\",\"ITR\":\"1180.00\"},\"2020-07\":{\"MATM\\/AEPS\\/CPOS\":\"800.00\",\"DropCash\":\"1871.00\",\"DMT\":\"1705.00\",\"PG\":\"100.00\",\"MATM Activation Deposit\":\"30998.75\",\"CASH IN\":\"2903.00\",\"CMS Activation Charges\":\"944.00\",\"PG DMT\":\"100.00\",\"Mini Statement\":\"0.00\",\"PAYTM Wallet\":\"803.00\",\"ITR\":\"48429.97\",\"Fingpot Processing Fee\":\"8.00\",\"Fingpot Monthly Installment\":\"2.00\"}}', '2020-07-23 11:22:01', '2020-07-23 05:52:01'),
(5, 7, 'R003045', '7532891679', 'PAWANCHAUHAN170791@GMAIL.COM', 'PAWAN PAWAN', 'SHIV SHANKAR TELECOM', 'S511539', '2017-12-12 23:40:27', '{\"id\":\"20176713\",\"name\":\"PAWAN PAWAN\",\"firmname\":\"SHIV SHANKAR TELECOM\",\"phone\":\"7532891679\",\"email\":\"PAWANCHAUHAN170791@GMAIL.COM\",\"addeddate\":\"2017-12-12 23:40:27\",\"DmtCommType\":\"CNP\",\"AepsCommType\":\"CNP\",\"vstscode\":\"S511539\",\"aeps\":\"InActive\",\"matm\":\"InActive\",\"bill\":\"InActive\",\"isicicibc\":\"InActive\",\"isrelipaybc\":\"InActive\",\"railway\":\"InActive\",\"aadhaarpay\":\"InActive\",\"CashDrop\":\"InActive\",\"cms\":\"InActive\"}', '{\"2020-01\":{\"DMT\":\"4500.00\"}}', '2020-07-23 11:28:06', '2020-07-23 05:58:06'),
(6, 18, 'R003045', '7532891679', 'PAWANCHAUHAN170791@GMAIL.COM', 'PAWAN PAWAN', 'SHIV SHANKAR TELECOM', 'S511539', '2017-12-12 23:40:27', '{\"id\":\"20176713\",\"name\":\"PAWAN PAWAN\",\"firmname\":\"SHIV SHANKAR TELECOM\",\"phone\":\"7532891679\",\"email\":\"PAWANCHAUHAN170791@GMAIL.COM\",\"addeddate\":\"2017-12-12 23:40:27\",\"DmtCommType\":\"CNP\",\"AepsCommType\":\"CNP\",\"vstscode\":\"S511539\",\"aeps\":\"InActive\",\"matm\":\"InActive\",\"bill\":\"InActive\",\"isicicibc\":\"InActive\",\"isrelipaybc\":\"InActive\",\"railway\":\"InActive\",\"aadhaarpay\":\"InActive\",\"CashDrop\":\"InActive\",\"cms\":\"InActive\"}', '{\"2020-01\":{\"DMT\":\"4500.00\"}}', '2020-07-23 11:29:36', '2020-07-23 05:59:36');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_agent`
--

CREATE TABLE `tbl_agent` (
  `id` int(11) NOT NULL,
  `campaign_id` int(11) NOT NULL,
  `rcode` varchar(20) NOT NULL,
  `lockby` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `modify_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('lock','unlock') NOT NULL DEFAULT 'unlock'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_agent`
--

INSERT INTO `tbl_agent` (`id`, `campaign_id`, `rcode`, `lockby`, `created_at`, `modify_at`, `status`) VALUES
(1, 5, 'R003032', 1, '2020-07-22 21:07:54', '2020-07-22 15:37:54', 'unlock'),
(2, 5, 'R004002', 1, '2020-07-22 21:07:54', '2020-07-22 15:37:54', 'unlock'),
(3, 6, 'R003032', 1, '2020-07-22 21:08:15', '2020-07-22 15:38:15', 'unlock'),
(4, 6, 'R004002', 1, '2020-07-22 21:08:15', '2020-07-22 15:38:15', 'unlock'),
(5, 5, 'R-Code', 2, '2020-07-23 10:31:55', '2020-07-23 05:01:55', 'unlock'),
(6, 5, 'R003040', 2, '2020-07-23 10:31:55', '2020-07-23 05:01:55', 'unlock'),
(7, 5, 'R003045', 2, '2020-07-23 10:31:55', '2020-07-23 05:01:55', 'unlock'),
(8, 5, 'R003057', 2, '2020-07-23 10:31:55', '2020-07-23 05:01:55', 'unlock'),
(9, 5, 'R003059', 2, '2020-07-23 10:31:55', '2020-07-23 05:01:55', 'unlock'),
(10, 5, 'R003060', 2, '2020-07-23 10:31:55', '2020-07-23 05:01:55', 'unlock'),
(11, 5, 'R003062', 2, '2020-07-23 10:31:55', '2020-07-23 05:01:55', 'unlock'),
(12, 5, 'R003064', 2, '2020-07-23 10:31:55', '2020-07-23 05:01:55', 'unlock'),
(13, 5, 'R003065', 2, '2020-07-23 10:31:55', '2020-07-23 05:01:55', 'unlock'),
(14, 5, 'R003070', 2, '2020-07-23 10:31:55', '2020-07-23 05:01:55', 'unlock'),
(15, 5, 'R003077', 11, '2020-07-23 10:31:55', '2020-07-23 05:29:52', 'lock'),
(16, 5, 'R-Code', 2, '2020-07-23 10:46:09', '2020-07-23 05:16:09', 'unlock'),
(17, 5, 'R003040', 2, '2020-07-23 10:46:09', '2020-07-23 05:16:09', 'unlock'),
(18, 5, 'R003045', 2, '2020-07-23 10:46:09', '2020-07-23 05:16:09', 'unlock'),
(19, 5, 'R003057', 2, '2020-07-23 10:46:09', '2020-07-23 05:16:09', 'unlock'),
(20, 5, 'R003059', 2, '2020-07-23 10:46:09', '2020-07-23 05:16:09', 'unlock'),
(21, 5, 'R003060', 2, '2020-07-23 10:46:09', '2020-07-23 05:16:09', 'unlock'),
(22, 5, 'R003062', 2, '2020-07-23 10:46:09', '2020-07-23 05:16:09', 'unlock'),
(23, 5, 'R003064', 2, '2020-07-23 10:46:09', '2020-07-23 05:16:09', 'unlock'),
(24, 5, 'R003065', 11, '2020-07-23 10:46:09', '2020-07-23 06:04:01', 'lock'),
(25, 5, 'R003070', 11, '2020-07-23 10:46:09', '2020-07-23 05:22:56', 'lock'),
(26, 5, 'R003077', 11, '2020-07-23 10:46:09', '2020-07-23 05:18:28', 'lock');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_campaign`
--

CREATE TABLE `tbl_campaign` (
  `id` int(11) NOT NULL,
  `assign_user` varchar(30) NOT NULL,
  `name` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `modify_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('A','D') NOT NULL DEFAULT 'A'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_campaign`
--

INSERT INTO `tbl_campaign` (`id`, `assign_user`, `name`, `created_at`, `modify_at`, `status`) VALUES
(5, '11,13', 'Non Active Agents', '2020-07-22 21:06:23', '2020-07-23 05:29:11', 'D'),
(6, '11', 'Mini Statement', '2020-07-22 21:06:37', '2020-07-23 06:05:29', 'D');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_remark`
--

CREATE TABLE `tbl_remark` (
  `id` int(11) NOT NULL,
  `agent_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `remark` text NOT NULL,
  `discussion` text NOT NULL,
  `next_callback_date` date NOT NULL,
  `created_at` datetime NOT NULL,
  `modify_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `business_id` int(11) NOT NULL,
  `campaign_id` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0->close,1->callback'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_remark_options`
--

CREATE TABLE `tbl_remark_options` (
  `id` int(11) NOT NULL,
  `remark` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `modify_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('A','D') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_remark_options`
--

INSERT INTO `tbl_remark_options` (`id`, `remark`, `created_at`, `modify_at`, `status`) VALUES
(5, 'Not Interested', '2020-07-23 10:43:21', '2020-07-23 05:13:21', 'A'),
(6, 'Support Issue', '2020-07-23 10:43:39', '2020-07-23 05:13:39', 'A'),
(7, 'No Answer', '2020-07-23 10:44:00', '2020-07-23 05:14:00', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `username` varchar(150) NOT NULL,
  `mobileno` varchar(20) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `password` text NOT NULL,
  `status` enum('A','D') NOT NULL DEFAULT 'A' COMMENT 'A->active,D->Deactive',
  `created` datetime NOT NULL,
  `modify` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `username`, `mobileno`, `emailid`, `password`, `status`, `created`, `modify`) VALUES
(11, 'Deepankar', '9999110680', 'deepankar@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'A', '2020-07-19 15:00:00', '2020-07-22 15:16:44'),
(13, 'asad', '7702991245', 'md.asad@rnfi.in', '', 'A', '2020-07-23 10:29:54', '2020-07-23 04:59:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin_otp`
--
ALTER TABLE `tbl_admin_otp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_agbusiness`
--
ALTER TABLE `tbl_agbusiness`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_agent`
--
ALTER TABLE `tbl_agent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_campaign`
--
ALTER TABLE `tbl_campaign`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_remark`
--
ALTER TABLE `tbl_remark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_remark_options`
--
ALTER TABLE `tbl_remark_options`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_admin_otp`
--
ALTER TABLE `tbl_admin_otp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_agbusiness`
--
ALTER TABLE `tbl_agbusiness`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_agent`
--
ALTER TABLE `tbl_agent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tbl_campaign`
--
ALTER TABLE `tbl_campaign`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_remark`
--
ALTER TABLE `tbl_remark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_remark_options`
--
ALTER TABLE `tbl_remark_options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
