<?php
  class Campaign_model extends CI_Model
   {
	   public function __construct(){
			parent::__construct();
			$this->load->database();
			date_default_timezone_set('Asia/Kolkata');
			$this->loggedInArr = $this->session->userdata('logged_in');
		 }
   
	
		public function saveCampaign($saveCamArr){
			$this->db->set($saveCamArr);
            $result = $this->db->insert('campaign');
			if($result){
			  $this->session->set_flashdata("message","Campaign is successfully save!");
			  redirect(base_url('campaign/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('campaign/add'));
			}
		}
		
		
		public function getAllCamps(){
			$query = $this->db->select('id,name')->where('status',"A")->get('campaign')->result_array();
			return $query;
		}
		
		public function getCampAgents($id){
			$query = $this->db->select('id,name,assign_user')->where('id',$id)->get('campaign')->row_array();
			return $query;
		}
	
		public function getvalue_agent_master($limit,$start,$search_str){
			$this->db->select('*');
			$this->db->from('campaign');
			$this->db->order_by("id", "desc");
			if($search_str!=false)
			{
				$this->db->where("name LIKE", "%".$search_str."%");
			}
			$this->db->limit($limit,$start);
			$query = $this->db->get();
			//echo $this->db->last_query(); die;
			return  $query->result_array();
        }   
     
		public function count_getvalue_agent_master($search_str){
			$this->db->select('*');
			$this->db->from('campaign');
			$this->db->order_by("id", "desc");
			if($search_str!=false)
			{
				$this->db->where("name LIKE", "%".$search_str."%");
			}         
			$query = $this->db->get();
			return  $query->num_rows();  		
        } 
		
		public function removeCampaign($id){
			$this->db->where('id', $id);
            $result = $this->db->delete('campaign');
			if($result){
			  $this->session->set_flashdata("message","Campaign is successfully remove!");
			  redirect(base_url('campaign/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('campaign/index'));
			}
		}
		
		
		public function deactiveCamp($id){
			$data = array('status'=>'D','modify_at'=>date('Y-m-d H:i:s'));
			$this->db->where('id', $id);
            $result = $this->db->update('campaign', $data);
			if($result){
			  $this->session->set_flashdata("message","Campaign is successfully deactive!");
			  redirect(base_url('campaign/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('campaign/index'));
			}
		}
		
		public function activeCamp($id){
			$data = array('status'=>'A','modify_at'=>date('Y-m-d H:i:s'));
			$this->db->where('id', $id);
            $result = $this->db->update('campaign', $data);
			if($result){
			  $this->session->set_flashdata("message","Campaign is successfully active!");
			  redirect(base_url('campaign/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('campaign/index'));
			}
		}
		
		public function updateCampData($updatecampArr,$camp_id){ 
			$this->db->where('id', $camp_id);
            $result = $this->db->update('campaign', $updatecampArr);
			if($result){
			  $this->session->set_flashdata("message","Campaign is successfully update!");
			  redirect(base_url('campaign/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('campaign/edit/'.$camp_id));
			}
		}
		
		public function saveassignUser($saveCamArr,$camp_id){
			$this->db->where('id', $camp_id);
            $result = $this->db->update('campaign', $saveCamArr);
			if($result){
			  $this->session->set_flashdata("message","User is successfully assign!");
			  redirect(base_url('campaign/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('campaign/edit/'.$camp_id));
			}
		}
		
		public function searchAssignUserInCamp($uid){
			$this->db->select('assign_user')->from('campaign');
			$this->db->group_start();
			$this->db->where("find_in_set($uid, assign_user)");
			$this->db->group_end();
			$result = $this->db->get()->result_array();
			return $result;
		}
		
		
	
  }