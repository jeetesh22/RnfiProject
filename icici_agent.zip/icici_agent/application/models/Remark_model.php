<?php
  class Remark_model extends CI_Model
   {
	   public function __construct(){
			parent::__construct();
			$this->load->database();
			date_default_timezone_set('Asia/Kolkata');
			$this->loggedInArr = $this->session->userdata('logged_in');
		 }
		 
		 public function saveRemarks($saveRemarks){
			$this->db->set($saveRemarks);
            $result = $this->db->insert('remark_options');
			if($result){
			  $this->session->set_flashdata("message","Remark Options is successfully save!");
			  redirect(base_url('remark/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('remark/add'));
			}
		}
		
		public function getvalue_remark_master($limit,$start,$search_str){
			$this->db->select('a.id,a.remark');
			$this->db->from('remark_options a');
			$this->db->order_by("a.id", "desc");
			if($search_str!=false)
			{
				$this->db->where("a.remark LIKE", "%".$search_str."%");
			}
			$this->db->limit($limit,$start);
			$query = $this->db->get();
			//echo $this->db->last_query(); die;
			return  $query->result_array();
        }   
     
		public function count_getvalue_remark_master($search_str){
			$this->db->select('a.id,a.remark');
			$this->db->from('remark_options a');
			$this->db->order_by("a.id", "desc");
			if($search_str!=false)
			{
				$this->db->where("a.remark LIKE", "%".$search_str."%");
			}
			$query = $this->db->get();
			return  $query->num_rows();  		
        }
   
	    public function removeRemarks($id){
			$this->db->where('id', $id);
            $result = $this->db->delete('remark_options');
			if($result){
			  $this->session->set_flashdata("message","Remarks is successfully remove!");
			  redirect(base_url('remark/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('remark/index'));
			}
		}
		
		public function getSingleRemark($id){
			$query = $this->db->select('id,remark')->where('id',$id)->get('remark_options')->row_array();
			return $query;
		}
		
		public function updateRemarks($updateRemarks,$remark_id){
			$this->db->where('id', $remark_id);
            $result = $this->db->update('remark_options', $updateRemarks);
			if($result){
			  $this->session->set_flashdata("message","Remark option is successfully update!");
			  redirect(base_url('remark/index'));
			}else{
			  $this->session->listremarks("message","Something db occuress!");
			  redirect(base_url('remark/index/'.encrypt_method($remark_id)));
			}
		}

		public function getAllRemarks(){
			$query = $this->db->select('id,remark')->get('remark_options')->result_array();
			return $query;
		}	
	
		public function unLockAgent($id){
			$data = array('status'=>'unlock','modify_at'=>date('Y-m-d H:i:s'));
			$this->db->where('id', $id);
            $result = $this->db->update('agent', $data);
			if($result){
			  $this->session->set_flashdata("message","Agent is successfully unlock!");
			  redirect(base_url('agent/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('agent/index'));
			}
		}
		
		public function LockAgent($id){
			$data = array('status'=>'lock','modify_at'=>date('Y-m-d H:i:s'));
			$this->db->where('id', $id);
            $result = $this->db->update('agent', $data);
			if($result){
			  $this->session->set_flashdata("message","Agent is successfully lock!");
			  redirect(base_url('agent/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('agent/index'));
			}
		}
	
	
  }