<?php
  class Report_model extends CI_Model
   {
	   public function __construct(){
			parent::__construct();
			$this->load->database();
			date_default_timezone_set('Asia/Kolkata');
			$this->loggedInArr = $this->session->userdata('logged_in');
		 }
   
	 public function exportToCampCsv($search_str){
			  $this->db->select("d.id as roId,b.name as campName,a.id as agentid,a.rcode as rcode,a.lockby as lockby,
						c.next_callback_date,c.discussion,,d.remark as remark,a.status as agstatus,e.username,e.mobileno");
			  $this->db->from('agent a'); 
			  $this->db->join('campaign b', 'b.id = a.campaign_id');
			  $this->db->join('remark c', 'c.agent_id = a.id');
			  $this->db->join('remark_options d', 'd.id = c.remark');
			  $this->db->join('users e', 'e.id = a.lockby');
			  if($this->loggedInArr["uid"]!="" && $this->loggedInArr["is_admin"]==0){
				  $this->db->where('a.lockby',$this->loggedInArr["uid"]);
			  }
			  $this->db->where('b.id',$search_str);
			  $query = $this->db->get();
			  $result = $query->result_array();
			 // echo "<pre>";print_r($result);die;
			  return $result;
			 
			  /* $this->db->select("a.name as campName,b.rcode as rcode,b.lockby as lockby,
			  c.next_callback_date,c.discussion,,d.remark as remark,b.status as agstatus,e.username,e.mobileno");
			  $this->db->from('campaign a');
			  $this->db->join('agent b', 'b.campaign_id = a.id');
			  $this->db->join('remark c', 'c.campaign_id = a.id'); 
			  $this->db->join('remark_options d', 'd.id = c.remark');
			  if($this->loggedInArr["uid"]!="" && $this->loggedInArr["is_admin"]==0){
				  $this->db->where('b.lockby',$this->loggedInArr["uid"]);
			  }
			  $this->db->join('users e', 'e.id = b.lockby');
			  $this->db->where('a.id',$search_str);
			  $query = $this->db->get();
			  $result = $query->result_array();
			  //echo "<pre>";print_r($result);die;
			  return $result; */
		}
		
		public function exportToCsv($search_str){ 
			   $this->db->select("d.id as roId,b.name as campName,a.id as agentid,a.rcode as rcode,a.lockby as lockby,
						c.next_callback_date,c.discussion,,d.remark as remark,a.status as agstatus,e.username,e.mobileno");
			  $this->db->from('agent a'); 
			  $this->db->join('campaign b', 'b.id = a.campaign_id');
			  $this->db->join('remark c', 'c.agent_id = a.id');
			  $this->db->join('remark_options d', 'd.id = c.remark');
			  $this->db->join('users e', 'e.id = a.lockby');
			  $this->db->where('a.rcode',$search_str);
			  $query = $this->db->get();
			  $result = $query->result_array();
			 // echo "<pre>";print_r($result);die;
			  return $result;
			  
			   /* $this->db->select("b.name as campName,a.rcode as rcode,a.lockby as lockby,
						c.next_callback_date,c.discussion,,d.remark as remark,a.status as agstatus,e.username,e.mobileno");
			  $this->db->from('agent a'); 
			  $this->db->join('campaign b', 'b.id = a.campaign_id');
			  $this->db->join('remark c', 'c.agent_id = a.id');
			  $this->db->join('remark_options d', 'd.id = c.remark');
			  $this->db->join('users e', 'e.id = a.lockby');
			  $this->db->where('a.rcode',$search_str);
			  $query = $this->db->get();
			  $result = $query->result_array();
			  //echo "<pre>";print_r($result);die;
			  return $result; */
		}
		
		public function exportToRemarkCsv($search_str){
			 $this->db->select("d.id as roId,b.name as campName,a.rcode as rcode,a.lockby as lockby,
						c.next_callback_date,c.discussion,,d.remark as remark,a.status as agstatus,e.username,e.mobileno");
			  $this->db->from('agent a'); 
			  $this->db->join('campaign b', 'b.id = a.campaign_id');
			  $this->db->join('remark c', 'c.agent_id = a.id');
			  $this->db->join('remark_options d', 'd.id = c.remark');
			  $this->db->join('users e', 'e.id = a.lockby');
			  $this->db->where('d.id',$search_str);
			  $query = $this->db->get();
			  $result = $query->result_array();
			 // echo "<pre>";print_r($result);die;
			  return $result;
			
		}
		
		public function exportToDaywiseCsv($search_str){ 
			 $this->db->select("d.id as roId,b.name as campName,a.rcode as rcode,a.lockby as lockby,
						c.next_callback_date,c.discussion,,d.remark as remark,a.status as agstatus,e.username,e.mobileno");
			  $this->db->from('agent a'); 
			  $this->db->join('campaign b', 'b.id = a.campaign_id');
			  $this->db->join('remark c', 'c.agent_id = a.id');
			  $this->db->join('remark_options d', 'd.id = c.remark');
			  $this->db->join('users e', 'e.id = a.lockby');
			  $this->db->where("c.modify_at",date("Y-m-d",strtotime($search_str)));
			  $query = $this->db->get();
			  //echo $this->db->last_query();die;
			  $result = $query->result_array();
			  //echo "<pre>";print_r($result);die;
			  return $result;
			
		}
		
		public function getBsDetails($agentid,$rcode){
			  $this->db->select("userdetails");
			  $this->db->from('agbusiness'); 
			  $this->db->where("agent_id",$agentid);
			  $this->db->where("agent_code",$rcode);
			  $query = $this->db->get();
			  if($query->num_rows() > 0){
				$bsDetails = $query->row_array();
				$userData = json_decode($bsDetails["userdetails"]);
				return $userData;
			  }
		}
		

		
	
  }