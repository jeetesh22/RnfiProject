<?php
  class Agent_model extends CI_Model
   {
	   public function __construct(){
			parent::__construct();
			$this->load->database();
			date_default_timezone_set('Asia/Kolkata');
			$this->loggedInArr = $this->session->userdata('logged_in');
		 }
   
	public function saveRcodeCsv(){
		$campaign = $this->input->post("campaign");
		$loggedInArr = $this->session->userdata('logged_in');
		$count=0;
		$fileType = $this->file_check($_FILES);
		if($fileType == 1){ 
        $fp = fopen($_FILES['rcode_csv']['tmp_name'],'r') or die("can't open file");
        while($csv_line = fgetcsv($fp,4096))
        {
            $count++;
            for($i = 0, $j = count($csv_line); $i < $j; $i++)
            {
                $insert_csv = array();
                $insert_csv['rocde'] = $csv_line[0];
            }
            $i++;
            $data = array(
			    'campaign_id'=>$campaign,
                'rcode' => $insert_csv['rocde'],
                'lockby' =>$loggedInArr["id"],
				'created_at'=>date('Y-m-d H:i:s')
               );
            $data['crane_features']=$this->db->insert('agent', $data);
        }
        fclose($fp) or die("can't close file");
        $data['success']="success";
        return $data;
      }else{ 
		
	 }
	}
	
	public function file_check($str){ 
        $allowed_mime_types = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
        if(isset($_FILES['rcode_csv']['name']) && $_FILES['rcode_csv']['name'] != ""){
            $mime = get_mime_by_extension($_FILES['rcode_csv']['name']);
            $fileAr = explode('.', $_FILES['rcode_csv']['name']);
            $ext = end($fileAr);
            if(($ext == 'csv') && in_array($mime, $allowed_mime_types)){ 
                return true;
            }else{ 
                $this->session->set_flashdata('message', 'Please select only CSV file to upload.');
                redirect(base_url('user/dashboard'));
            }
        }else{
            $this->session->set_flashdata('message', 'Please select a CSV file to upload.');
            redirect(base_url('user/dashboard'));
        }
      }
	
		public function getAllAgents(){
			$query = $this->db->select('id,rcode,status')->where('lockby',$this->loggedInArr["id"])->where('status',"lock")->get('agent')->result_array();
			return $query;
		}
		
		public function getSingleAgents($id){
			$query = $this->db->select('id,rcode,campaign_id')->where('id',$id)->get('agent')->row_array();
			return $query;
		}
		
		public function getSingleAgentCamp($id){
		  $this->db->select("a.id as id,a.rcode,a.campaign_id,b.name as name");
		  $this->db->from('agent a');
		  $this->db->join('campaign b', 'a.campaign_id = b.id');
		  $this->db->where("a.id",$id);
		  $query = $this->db->get();
		  return $query->row_array();
		}
		
		public function getSingleAgentRemark($id){ 
		  $this->db->select("a.id as id,a.remark,a.discussion,b.name as campName,c.remark as remarkName");
		  $this->db->from('remark a');
		  $this->db->join('campaign b', 'b.id = a.campaign_id ');
		  $this->db->join('remark_options c', 'c.id = a.remark');
		  $this->db->where("a.agent_id",$id);
		  $this->db->where("a.userid",$this->loggedInArr["id"]);
		  $query = $this->db->get();
		  return $query->result_array();
		}
	
		public function getvalue_agent_master($limit,$start,$search_str,$search_camp){
			$uid = $this->loggedInArr["id"];
			$this->db->select('a.*,b.name as campname,b.assign_user');
			$this->db->from('agent a');
			$this->db->join('campaign b', 'b.id = a.campaign_id');
			
			if($this->loggedInArr["is_admin"]==0 && $this->loggedInArr["uid"]!=""){
				$this->db->group_start();
				$this->db->where("find_in_set($uid, b.assign_user)");
				$this->db->group_end();
				
				$this->db->where("a.status",'unlock');
			}
			$this->db->where("b.status",'A');
			$this->db->order_by("a.id", "desc");
			if($search_str!=false)
			{ 
				$this->db->where("a.rcode LIKE", "%".$search_str."%");
			}
			
			if($search_camp!=false)
			{
				$this->db->where("a.campaign_id LIKE", "%".$search_camp."%");
			}
			
			$this->db->limit($limit,$start);
			$query = $this->db->get();
		    //echo $this->db->last_query(); die;
			return  $query->result_array();
        }   
     
		public function count_getvalue_agent_master($search_str,$search_camp){
			$uid = $this->loggedInArr["id"];
			$this->db->select('a.*,b.name as campname');
			$this->db->from('agent a');
			$this->db->join('campaign b', 'b.id = a.campaign_id');
			
			if($this->loggedInArr["is_admin"]==0 && $this->loggedInArr["uid"]!=""){
				$this->db->group_start();
				$this->db->where("find_in_set($uid, b.assign_user)");
				$this->db->group_end();
				
				$this->db->where("a.status",'unlock');
			}
			$this->db->where("b.status",'A');
			$this->db->order_by("a.id", "desc");
			if($search_str!=false)
			{ 
				$this->db->where("a.rcode LIKE", "%".$search_str."%");
			}
			
			if($search_camp!=false)
			{
				$this->db->where("a.campaign_id LIKE", "%".$search_camp."%");
			}     
			$query = $this->db->get();
			return  $query->num_rows();  		
        } 
		
		public function unLockAgent($id){ 
		    if($this->loggedInArr["is_admin"]==0 && $this->loggedInArr["uid"]!=""){
				$data = array('status'=>'unlock','modify_at'=>date('Y-m-d H:i:s'),'lockby'=>$this->loggedInArr["uid"]);
			}else{
				$data = array('status'=>'unlock','modify_at'=>date('Y-m-d H:i:s'));
			}
			$this->db->where('id', $id);
            $result = $this->db->update('agent', $data);
			if($result){
			  $this->session->set_flashdata("message","Agent is successfully unlock!");
			  redirect(base_url('agent/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('agent/index'));
			}
		}
		
		public function LockAgent($id){
			 if($this->loggedInArr["is_admin"]==0 && $this->loggedInArr["uid"]!=""){
				$data = array('status'=>'lock','modify_at'=>date('Y-m-d H:i:s'),'lockby'=>$this->loggedInArr["uid"]);
			}else{
				$data = array('status'=>'lock','modify_at'=>date('Y-m-d H:i:s'));
			}
			
			$this->db->where('id', $id);
            $result = $this->db->update('agent', $data);
			if($result){
			 return $result;
			}else{
			 return "";
			}
		}
		
		public function updateAgent($id,$rcode,$campaign){ 
			$data = array('rcode'=>$rcode,'campaign_id'=>$campaign,'modify_at'=>date('Y-m-d H:i:s'));
			$this->db->where('id', $id);
            $result = $this->db->update('agent', $data);
			if($result){
			  $this->session->set_flashdata("message","Agent is successfully update!");
			  redirect(base_url('agent/agentlist'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('agent/edit/'.$id));
			}
		}
		
		public function removeAgent($id){ 
			$this->db->where('id', $id);
            $result = $this->db->delete('agent');
			if($result){
			  $this->session->set_flashdata("message","Agent is successfully remove!");
			  redirect(base_url('agent/agentlist'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('agent/agentlist'));
			}
		}
		
		public function saveBusinessAgent($saveAgentArr,$recall){
			$this->db->set($saveAgentArr);
            $result = $this->db->insert('remark');
			if($result){
			  $this->session->set_flashdata("message","Remark is successfully save!");
			  if($recall==1){
				   redirect(base_url('agent/index'));
			  }else{
				  redirect(base_url('agent/userlockagent'));
			  }
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  if($recall=1){
				   redirect(base_url('agent/add'));
			  }else{
				  redirect(base_url('agent/userlockagent'));
			  }
			}
		}
		
		public function getvalue_agentbusiness_master($limit,$start,$search_str){
			$this->db->select('a.*,b.rcode as rcode,c.remark as remark');
			$this->db->from('remark a');
			$this->db->join('agent b', 'b.id = a.agent_id');
			$this->db->join('remark_options c', 'c.id = a.remark');
			$this->db->where('userid',$this->loggedInArr["id"]);
			$this->db->order_by("a.id", "desc");
			if($search_str!=false)
			{
				$this->db->where("b.rcode LIKE", "%".$search_str."%");
				$this->db->or_where("c.remark LIKE", "%".$search_str."%");
			}         
			$this->db->limit($limit,$start);
			$query = $this->db->get();
			//echo $this->db->last_query(); die;
			return  $query->result_array();
        }   
     
		public function count_getvalue_agentbusiness_master($search_str){
		    $this->db->select('a.*,b.rcode as rcode,c.remark as remark');
			$this->db->from('remark a');
			$this->db->join('agent b', 'b.id = a.agent_id');
			$this->db->join('remark_options c', 'c.id = a.remark');
			$this->db->where('userid',$this->loggedInArr["id"]);
			$this->db->order_by("a.id", "desc");
			if($search_str!=false)
			{
				$this->db->where("b.rcode LIKE", "%".$search_str."%");
				$this->db->or_where("c.remark LIKE", "%".$search_str."%");
			}         
			$query = $this->db->get();
			return  $query->num_rows();  		
        }

	   public function removeBusinessAgent($id){
		   $this->db->where('id', $id);
            $result = $this->db->delete('remark');
			if($result){
			  $this->session->set_flashdata("message","Agent Business is successfully remove!");
			  redirect(base_url('agent/indexbusiness'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('agent/indexbusiness'));
			}
	   }

		public function getvalue_agenttoday_master($limit,$start,$search_str,$search_camp){
			$uid = $this->loggedInArr["id"];
			$this->db->select('a.*,b.id as agId,b.rcode as rcode,b.status as agstatus,c.remark as remark,d.name as campname,e.userdetails,e.business');
			$this->db->from('remark a');
			$this->db->join('agent b', 'b.id = a.agent_id');
			$this->db->join('remark_options c', 'c.id = a.remark');
			$this->db->join('campaign d', 'd.id = b.campaign_id');
			$this->db->join('agbusiness e', 'e.id = a.campaign_id');
			
			$this->db->where('a.userid',$this->loggedInArr["id"]);
			$this->db->where('DATE(a.next_callback_date)',date('Y-m-d'));
			$this->db->group_start();
			$this->db->where("find_in_set($uid, d.assign_user)");
			$this->db->group_end();
			
			$this->db->order_by("a.id", "desc");
			if($search_str!=false)
			{
				$this->db->where("b.rcode LIKE", "%".$search_str."%");
				$this->db->or_where("c.remark LIKE", "%".$search_str."%");
			}
			
			if($search_camp!=false)
			{
				$this->db->where("b.campaign_id LIKE", "%".$search_camp."%");
			}	
			
			$this->db->limit($limit,$start);
			$query = $this->db->get();
			//echo $this->db->last_query(); die;
			return  $query->result_array();
        }   
     
		public function count_getvalue_agenttoday_master($search_str,$search_camp){
			$uid = $this->loggedInArr["id"];
		    $this->db->select('a.*,b.id as agId,b.rcode as rcode,b.status as agstatus,c.remark as remark,d.name as campname,e.userdetails,e.business');
			$this->db->from('remark a');
			$this->db->join('agent b', 'b.id = a.agent_id');
			$this->db->join('remark_options c', 'c.id = a.remark');
			$this->db->join('campaign d', 'd.id = b.campaign_id');
			$this->db->join('agbusiness e', 'e.id = a.campaign_id');
			
			$this->db->where('a.userid',$this->loggedInArr["id"]);
			$this->db->where('DATE(a.next_callback_date)',date('Y-m-d'));
			
			$this->db->group_start();
			$this->db->where("find_in_set($uid, d.assign_user)");
			$this->db->group_end();
			
			$this->db->order_by("a.id", "desc");
			if($search_str!=false)
			{
				$this->db->where("b.rcode LIKE", "%".$search_str."%");
				$this->db->or_where("c.remark LIKE", "%".$search_str."%");
			}
				
			if($search_camp!=false)
			{
				$this->db->where("b.campaign_id LIKE", "%".$search_camp."%");
			}	
			
			$query = $this->db->get();
			return  $query->num_rows();  		
        }
		
		public function getAgentBusiness($agent_id,$loginUser){
			$query = $this->db->select('id,agent_id')->where('agent_id',$agent_id)->where('userid',$loginUser)->get('remark')->row_array();
			return $query;
		}
		
		public function updateBusinessAgent($saveAgentArr,$id){
			$this->db->where('id', $id);
            $result = $this->db->update('remark', $saveAgentArr);
			if($result){
			  $this->session->set_flashdata("message","Remark is successfully update!");
			  redirect(base_url('agent/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('agent/add'));
			}
		}
		
		public function getSingleBS($id){
			$uid = $this->loggedInArr["id"];
			$this->db->select('a.*,b.rcode as rcode,b.status as agstatus,c.remark as remark,d.name as campname,a.discussion as rmdiscussion');
			$this->db->from('remark a');
			$this->db->join('agent b', 'b.id = a.agent_id');
			$this->db->join('remark_options c', 'c.id = a.remark');
			$this->db->join('campaign d', 'd.id = a.campaign_id');
			$this->db->where('a.agent_id',$id);
			//$this->db->where('a.userid',$uid);
			$query = $this->db->get();
			return  $query->result_array();
		}
		
		public function saveAgentBsRecord($saveAgBsArr){
			$this->db->set($saveAgBsArr);
            $result = $this->db->insert('agbusiness');
			if($result){
			 return $this->db->insert_id();
			}
		}
		
		public function getSingleAgentBs($id,$agent_code){ 
		  $agRcode = $agent_code["rcode"];
		  $this->db->select("id as id,agent_code,vstscode,name,userdetails,business");
		  $this->db->from('agbusiness');
		  $this->db->where("agent_id",$id);
		  $this->db->where("agent_code",$agRcode);
		  $query = $this->db->get();
		  return $query->row_array();
		}
		
		public function getSingleAgentBsRecord($id){
		  $this->db->select("id as id,agent_code,vstscode,name,userdetails,business");
		  $this->db->from('agbusiness');
		  $this->db->where("id",$id);
		  $query = $this->db->get();
		  return $query->row_array();
		}
		
		public function getvalue_agentlock_master($limit,$start,$search_str,$search_camp){
			$uid = $this->loggedInArr["id"];
			$this->db->select('a.*,b.name as campname,b.assign_user');
			$this->db->from('agent a');
			$this->db->join('campaign b', 'b.id = a.campaign_id');
			
			if($this->loggedInArr["is_admin"]==0 && $this->loggedInArr["uid"]!=""){
				$this->db->group_start();
				$this->db->where("find_in_set($uid, b.assign_user)");
				$this->db->group_end();
				
				$this->db->where("a.status",'lock');
			}
			$this->db->where("b.status",'A');
			$this->db->order_by("a.id", "desc");
			if($search_str!=false)
			{ 
				$this->db->where("a.rcode LIKE", "%".$search_str."%");
			}
			
			if($search_camp!=false)
			{
				$this->db->where("a.campaign_id LIKE", "%".$search_camp."%");
			}
			
			$this->db->limit($limit,$start);
			$query = $this->db->get();
		    //echo $this->db->last_query(); die;
			return  $query->result_array();
        }   
     
		public function count_getvalue_agentlock_master($search_str,$search_camp){
			$uid = $this->loggedInArr["id"];
			$this->db->select('a.*,b.name as campname');
			$this->db->from('agent a');
			$this->db->join('campaign b', 'b.id = a.campaign_id');
			
			if($this->loggedInArr["is_admin"]==0 && $this->loggedInArr["uid"]!=""){
				$this->db->group_start();
				$this->db->where("find_in_set($uid, b.assign_user)");
				$this->db->group_end();
				
				$this->db->where("a.status",'lock');
			}
			$this->db->where("b.status",'A');
			$this->db->order_by("a.id", "desc");
			if($search_str!=false)
			{ 
				$this->db->where("a.rcode LIKE", "%".$search_str."%");
			}
			
			if($search_camp!=false)
			{
				$this->db->where("a.campaign_id LIKE", "%".$search_camp."%");
			}     
			$query = $this->db->get();
			return  $query->num_rows();  		
        }

	   public function getAgentRemark($id,$campaign_id){
		    $uid = $this->loggedInArr["id"];
			$this->db->select('a.agent_id,a.campaign_id,b.remark as remark,b.id as rId,a.discussion');
			$this->db->from('remark a');
			$this->db->join('remark_options b', 'b.id = a.remark');
			$this->db->where("a.agent_id",$id);
			$this->db->where("a.campaign_id",$campaign_id);
			$this->db->where("b.status",'A');
			$this->db->where("a.userid",$uid);
			$query = $this->db->get();
		    //echo $this->db->last_query(); die;
			return  $query->row_array();
	   }
	   
	   public function getAgentBsMobileno($agent_id,$rcode){
			$this->db->select('a.mobile_no');
			$this->db->from('agbusiness a');
			$this->db->where("a.agent_code",$rcode);
			$this->db->where("a.agent_id",$agent_id);
			$query = $this->db->get();
		    //echo $this->db->last_query(); die;
			return  $query->row_array();
	  }	

		
	
  }