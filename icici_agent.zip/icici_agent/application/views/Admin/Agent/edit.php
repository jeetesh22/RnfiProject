	<div class="main-content">
		<div class="main-content-inner">
			<div class="breadcrumbs ace-save-state" id="breadcrumbs">
				<ul class="breadcrumb">
					<li>
						<i class="ace-icon fa fa-home home-icon"></i>
						<a href="<?php echo base_url();?>user/dashboard">Home</a>
					</li>

					<li>
						<a href="#">Agent</a>
					</li>
					<li class="active">Edit Agent</li>
				</ul><!-- /.breadcrumb -->
			</div>

			<div class="page-content">
				<div class="row">
					<div class="col-xs-12">
					<?php if(validation_errors()){?>
					  <div class="alert alert-danger alert-dismissible">
					  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					   <?php echo validation_errors(); ?>.
					  </div>
					<?php } ?>
						<form class="form-horizontal" action="<?php echo base_url();?>agent/update" method="post" enctype="multipart/form-data" id="">
							<input type="hidden" name="agent_id" value="<?php echo encrypt_method($agent["id"]);?>">
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Select Campaign <span class="star">*</span></label>
								  <div class="col-sm-9">
									<select name="campaign" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Choose a Campaign..." style="display: none;">
										<option value="">  </option>
										<?php foreach($AllCamps as $i=>$camp){
											 $selected = '';
											if($camp["id"] == $agent["campaign_id"] )
											{ 
												$selected = 'selected="selected"';
											}?>
										<option value="<?php echo $camp['id'];?>" <?php echo $selected;?>><?php echo $camp['name'];?></option>
										<?php } ?>
									</select>
								</div>
							</div>
													
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Agent</label>
								<div class="col-sm-9">
									<input type="text" name="rcode" id="rcode" placeholder="rcode" class="col-xs-10 col-sm-8" value="<?php echo $agent["rcode"];?>">
								</div>
							</div>
							
							<div class="clearfix form-actions">
								<div class="col-md-offset-3 col-md-9">
									<button class="btn btn-info" type="submit">
										<i class="ace-icon fa fa-check bigger-110"></i>
										Submit
									</button>
									&nbsp; &nbsp; &nbsp;
									<button class="btn btn-danger" type="reset" onClick="window.location.href = '<?php echo base_url(); ?>agent/agentlist';return false;">
										<i class="ace-icon fa fa-remove bigger-110"></i>
										Cancel
									</button>
								</div>
							  </div>
							</form>
						</div><!-- /.page-content -->
					</div>
				</div>	
			</div>	
		</div>	