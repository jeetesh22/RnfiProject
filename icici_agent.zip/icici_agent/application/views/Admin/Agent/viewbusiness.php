<div class="main-content">
				<div class="main-content-inner">
				<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="<?php echo base_url();?>user/dashboard">Home</a>
							</li>

							<li>
								<a href="#">Agent</a>
							</li>
							<li class="active">Business</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<button class="btn btn-danger" type="reset" onClick="window.location.href = '<?php echo base_url(); ?>agent/userlockagent';return false;">
										Back
									</button>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>
					
					<div class="page-content">
					<?php if($this->session->flashdata('message')) { ?>
					  <div class="alert alert-success alert-dismissible">
					  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					   <?php echo $this->session->flashdata('message') ?>; 
					  </div>
					 <?php } ?>
					 <div id="usermessage"></div>
							<hr>
							<div class="row">
								<div class="col-xs-12">
									<div class="row">
										<div class="col-xs-12">
											<table id="simple-table" class="table  table-bordered table-hover">
											<thead>
												<tr>
													<th>S.No</th>
													<th>Remark</th>
													<th>Callback Date</th>
													<th>Date</th>
													<th>Discussion</th>
												</tr>
											</thead>
											<tbody>
											<?php if(!empty($agentCampRkBs)){?>
											<?php foreach($agentCampRkBs as $i=>$agent){?>
												<tr>
													<td><?php echo $i+1;?></a></td>
													<td></td>
													<!--<td><?php //echo $agent['remark'];?></td>-->
													<td><?php if($agent['next_callback_date']!="0000-00-00") { echo $agent['next_callback_date']." (Callback)"; }?></td>
													<td><?php echo $agent['created_at'];?></td>
													<td><?php echo $agent['rmdiscussion'];?></td>
												</tr>
											<?php }   ?>
										    <?php }else{?>
										      <tr><td colspan="8" align="center">No Data Found</td></tr>
										    <?php } ?>
											</tbody>
										</table>
									</div>
								</div>
								<?php if(validation_errors()){?>
					  <div class="alert alert-danger alert-dismissible">
					  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					   <?php echo validation_errors(); ?>.
					  </div>
					<?php } ?> 
						<form class="form-horizontal" action="<?php echo base_url();?>agent/savelockbusiness" method="post" enctype="multipart/form-data" id="">
							<input type="hidden" name="agent_id" value="<?php echo encrypt_method($agent_id);?>">
							<input type="hidden" name="campaign_id" value="<?php echo encrypt_method($agent["campaign_id"]);?>">
							<input type="hidden" name="business_id" value="<?php echo encrypt_method($lastResult);?>">
							
							
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Agent</label>
								<div class="col-sm-9">
									<input type="text" name="agent" id="rcode" placeholder="rcode" class="col-xs-10 col-sm-8" value="<?php echo $agent["rcode"];?>" readonly="true">
								</div>
							</div>
							
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Business Details(User)</label>
								<div class="col-sm-9">
									<table id="simple-table" class="table  table-bordered table-hover">
								<tbody>
								  <?php $userData = json_decode($bsDetails["userdetails"]);
										foreach($userData as $key=>$user){
											if($key != 'id'){	
											?>
									
										<th><?php echo $key;?></th>
										<td class="hidden-480">
										<?php echo $user;?>
										</td>
									</tr>
											<?php } 
											} ?>
								  </tbody>
						        </table>
							  </div>
							</div>
							
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Business Details(Monthly)</label>
								<div class="col-sm-9">
									<table id="simple-table" class="table  table-bordered table-hover">
								<tbody>
								 <?php $bsData = json_decode($bsDetails["business"]);
									 foreach($bsData as $bskey=>$bsval){?>
									<tr>
										<th><?php echo $bskey;?></th>
										<td class="hidden-480">
										<?php foreach($bsval as $inkey=>$invalue){
										  echo $inkey  .' : '. $invalue."<br>";?>
										<?php } ?>
										</td>
									</tr>
									 <?php } ?>
								  </tbody>
						        </table>
							  </div>
							</div>
							
							

							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Select Remark <span class="star">*</span></label>
								  <div class="col-sm-9">
									<select name="remark" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Choose a remark..." style="display: none;">
										<option value="">  </option>
										<?php foreach($remarks as $i=>$rem){?>
										<option value="<?php echo $rem['id'];?>"><?php echo $rem['remark'];?></option>
										<?php } ?>
									</select>
								</div>
							</div>
							
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Your Discussion with Agent</label>
								<div class="col-sm-9">
								<textarea name="description" placeholder="Add Description" class="form-control" id="form-field-8" required></textarea>
							</div>
							
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Call Status <span class="star">*</span></label>
								  <div class="col-sm-9">
									<div class="radio">
										<label>
											<input name="status" type="radio" class="callback_radio ace" value="0" checked>
											<span class="lbl">Close</span>
											</label>
										<label>
										<input name="status" type="radio" id="callback_radio" class="callback_radio ace" value="1">
										<span class="lbl">Callback</span>
										</label>
										</div>
								</div>
							</div>					
							
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Next Call Back Date</label>
								<div class="col-sm-3">
									<input class="col-xs-5 col-sm-4 date-picker form-control" name="callback_date" placeholder="To Date"  id="enddate" type="text" value="" data-date-format="yyyy-mm-dd" autocomplete="off"/>
								</div>
							</div>
							
							
							<div class="clearfix form-actions">
								<div class="col-md-offset-3 col-md-9">
									<button class="btn btn-info" type="submit">
										<i class="ace-icon fa fa-check bigger-110"></i>
										Submit
									</button>
									&nbsp; &nbsp; &nbsp;
									<button class="btn btn-danger" type="reset" onClick="window.location.href = '<?php echo base_url(); ?>agent/userlockagent';return false;">
										<i class="ace-icon fa fa-remove bigger-110"></i>
										Cancel
									</button>
								</div>
							  </div>
							</form>
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div>