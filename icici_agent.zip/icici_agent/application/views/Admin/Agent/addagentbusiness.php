	<div class="main-content">
		<div class="main-content-inner">
			<div class="breadcrumbs ace-save-state" id="breadcrumbs">
				<ul class="breadcrumb">
					<li>
						<i class="ace-icon fa fa-home home-icon"></i>
						<a href="<?php echo base_url();?>user/dashboard">Home</a>
					</li>

					<li>
						<a href="#">Agent</a>
					</li>
					<li class="active">Add Business Agent</li>
				</ul><!-- /.breadcrumb -->
			</div>

			<div class="page-content">
				<div class="row">
					<div class="col-xs-12">
					<?php if(validation_errors()){?>
					  <div class="alert alert-danger alert-dismissible">
					  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					   <?php echo validation_errors(); ?>.
					  </div>
					<?php } ?>
						<form class="form-horizontal" action="<?php echo base_url();?>agent/saveagentbusiness" method="post" enctype="multipart/form-data" id="">
							<input type="hidden" name="agent_id" value="<?php echo encrypt_method($agent["id"]);?>">
							<input type="hidden" name="campaign_id" value="<?php echo encrypt_method($agent["campaign_id"]);?>">
							<input type="hidden" name="business_id" value="<?php echo encrypt_method($lastResult);?>">
							
							
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Agent</label>
								<div class="col-sm-9">
									<input type="text" name="agent" id="rcode" placeholder="rcode" class="col-xs-10 col-sm-8" value="<?php echo $agent["rcode"];?>" readonly="true">
								</div>
							</div>
							
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Campaign</label>
								<div class="col-sm-9">
									<input type="text" name="campaign" id="campaign" placeholder="campaign" class="col-xs-10 col-sm-8" value="<?php echo $agent["name"];?>" readonly="true">
								</div>
							</div>
							
							
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Business Details(User)</label>
								<div class="col-sm-9">
									<table id="simple-table" class="table  table-bordered table-hover">
								<tbody>
								  <?php $userData = json_decode($bsDetails["userdetails"]);
										foreach($userData as $key=>$user){
											if($key != 'id'){	
											?>
									<tr>
										<th><?php echo $key;?></th>
										<td class="hidden-480">
										<?php echo $user;?>
										</td>
									</tr>
											<?php } 
											} ?>
								  </tbody>
						        </table>
							  </div>
							</div>
							
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Business Details(Monthly)</label>
								<div class="col-sm-9">
									<table id="simple-table" class="table  table-bordered table-hover">
								<tbody>
								 <?php $bsData = json_decode($bsDetails["business"]);
									 foreach($bsData as $bskey=>$bsval){?>
									<tr>
										<th><?php echo $bskey;?></th>
										<td class="hidden-480">
										<?php foreach($bsval as $inkey=>$invalue){
										  echo $inkey  .' : '. $invalue."<br>";?>
										<?php } ?>
										</td>
									</tr>
									 <?php } ?>
								  </tbody>
						        </table>
							  </div>
							</div>
							
							

							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Select Remark <span class="star">*</span></label>
								  <div class="col-sm-9">
									<select name="remark" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Choose a remark..." style="display: none;">
										<option value="">  </option>
										<?php foreach($remarks as $i=>$rem){?>
										<option value="<?php echo $rem['id'];?>"><?php echo $rem['remark'];?></option>
										<?php } ?>
									</select>
								</div>
							</div>
							
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Your Discussion with Agent</label>
								<div class="col-sm-9">
								<textarea name="description" placeholder="Add Description" class="form-control" id="form-field-8" required></textarea>
							</div>
							
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Call Status <span class="star">*</span></label>
								  <div class="col-sm-9">
									<div class="radio">
										<label>
											<input name="status" type="radio" class="callback_radio ace" value="0" checked>
											<span class="lbl">Close</span>
											</label>
										<label>
										<input name="status" type="radio" id="callback_radio" class="callback_radio ace" value="1">
										<span class="lbl">Callback</span>
										</label>
										</div>
								</div>
							</div>					
							
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Next Call Back Date</label>
								<div class="col-sm-3">
									<input class="col-xs-5 col-sm-4 date-picker form-control" name="callback_date" placeholder="To Date"  id="enddate" type="text" value="" data-date-format="yyyy-mm-dd" autocomplete="off"/>
								</div>
							</div>
							
							
							<div class="clearfix form-actions">
								<div class="col-md-offset-3 col-md-9">
									<button class="btn btn-info" type="submit">
										<i class="ace-icon fa fa-check bigger-110"></i>
										Submit
									</button>
									&nbsp; &nbsp; &nbsp;
									<button class="btn btn-danger" type="reset" onClick="window.location.href = '<?php echo base_url(); ?>agent/index';return false;">
										<i class="ace-icon fa fa-remove bigger-110"></i>
										Cancel
									</button>
								</div>
							  </div>
							</form>
						</div><!-- /.page-content -->
					</div>
				</div>	
			</div>	
		</div>
	  </div>			