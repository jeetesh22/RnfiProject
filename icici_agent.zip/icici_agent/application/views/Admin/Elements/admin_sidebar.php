	    <ul class="nav nav-list" style="top: 0px;">
			<li class="active">
				<a href="<?php echo base_url();?>user/dashboard">
					<i class="menu-icon fa fa-tachometer"></i>
					<span class="menu-text"> Dashboard </span>
				</a>
				<b class="arrow"></b>
			</li>

					
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-list"></i>
							<span class="menu-text"> User Module </span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>

						<ul class="submenu nav-hide" style="display: none;">
							<li class="">
								<a href="<?php echo base_url('user/adduser'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									Add User
								</a>
								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="<?php echo base_url('user/listuser'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									List User
								</a>
								<b class="arrow"></b>
							</li>
						</ul>
					</li>
					
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-list"></i>
							<span class="menu-text">Campaign</span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>
						<ul class="submenu nav-hide" style="display: none;">
							<li class="">
								<a href="<?php echo base_url('campaign/add'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									Add Campaign
								</a>
								<b class="arrow"></b>
							</li>
							<li class="">
								<a href="<?php echo base_url('campaign/index'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									List Campaign
								</a>
								<b class="arrow"></b>
							</li>
						</ul>
					</li>
					
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-list"></i>
							<span class="menu-text">Upload Data</span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>
						<ul class="submenu nav-hide" style="display: none;">
							<li class="">
								<a href="<?php echo base_url('agent/addagent'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									Add Data
								</a>
								<b class="arrow"></b>
							</li>
							<li class="">
								<a href="<?php echo base_url('agent/agentlist'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									List Data
								</a>
								<b class="arrow"></b>
							</li>
						</ul>
					</li>
					
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-list"></i>
							<span class="menu-text">Remarks</span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>
						<ul class="submenu nav-hide" style="display: none;">
							<li class="">
								<a href="<?php echo base_url('remark/add'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									Add Remark
								</a>
								<b class="arrow"></b>
							</li>
							<li class="">
								<a href="<?php echo base_url('remark/index'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									List Remark
								</a>
								<b class="arrow"></b>
							</li>
						</ul>
					</li>
					
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-list"></i>
							<span class="menu-text">Report</span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>
						<ul class="submenu nav-hide" style="display: none;">
							<li class="">
								<a href="<?php echo base_url('report/campaign'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									Campaign Report
								</a>
								<b class="arrow"></b>
							</li>
							
							<li class="">
								<a href="<?php echo base_url('report/agent'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									Agent Report
								</a>
								<b class="arrow"></b>
							</li>
							
							<li class="">
								<a href="<?php echo base_url('report/remark'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									Remarks Report
								</a>
								<b class="arrow"></b>
							</li>
							
							<li class="">
								<a href="<?php echo base_url('report/callingreport'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									Daywise Calling Report
								</a>
								<b class="arrow"></b>
							</li>
						</ul>
					</li>
		</ul>