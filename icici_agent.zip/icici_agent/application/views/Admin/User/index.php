<!DOCTYPE html>
<html class="no-js">
<head>
<!-- my script and syles goes here -->
</head>
<body>
 <?php if($header) echo $header ;?>
 <?php if($left) echo $left ;?>
 <?php if($middle) echo $middle ;?>
 <?php if($footer) echo $footer ;?>
</body>
</html>