<?php
    class Verification{
		private $CI;

        function __construct(){
			$this->CI =& get_instance();
            $this->CI->load->database(); 
            date_default_timezone_set('Asia/Kolkata');
            $this->date_time    =   date("Y-m-d H:i:s");
            $this->date         =   date("Y-m-d");
			$this->password = 'A#$44DDTT&&**(^FFghj2200';
			$this->method = 'aes-256-cbc';
			$this->key = substr(hash('sha256', $this->password, true), 0, 32);
			$this->iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);
			$this->Otp = rand(100000,999999);
			//$this->Otp = '445566';
		}

        public function getotp(){
           return  rand(100000,999999);
        }
		
		function sendOtp($mobile_no,$isAdmin,$id){
			return '445566'; die;
			$otp = $this->Otp;
            $msg = "Do not share your login otp for portal security.$otp OTP to accessing your Account.Please report unauthorised access to customer care. Powered by RNFI";			
			$message        =   urlencode($msg);
			$number         =   trim($mobile_no);
			$sender         =   "RNFIBC";
			//$url	=	"https://alerts.cbis.in/SMSApi/send?userid=rnfiotp&password=PeterKivani@!1&sendMethod=quick&mobile=".$number."&senderid=".$sender."&msg=".$message."&msgType=text&duplicatecheck=true&format=json";
			$url	=	"https://alerts.cbis.in/SMSApi/send?userid=rnfiotp&password=PeterKivani@!1&sendMethod=quick&mobile=".$number."&msg=".$message."&senderid=".$sender."&msgType=text&duplicatecheck=true&format=json";
			$ch = curl_init($url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
			$buffer = curl_exec($ch);
			curl_close($ch);
			
			$saveSmsArr = array(
					'otp'=>$otp,
					'is_active'=>'1',
					'adminid'=>$id,
					'is_admin'=>$isAdmin,
					'api_response'=>json_encode($buffer),
					'created_at'=>date('Y-m-d H:i:s'));
			
			 $this->CI->db->set($saveSmsArr);
             $result = $this->CI->db->insert('admin_otp');
			 return $otp;
		}
		
		function encrypted_string($plaintext){
			return $encrypted = base64_encode(openssl_encrypt($plaintext, $this->method, $this->key, OPENSSL_RAW_DATA, $this->iv));
		}
		
		function decrypted_string($plaintext){
			return $decrypted = openssl_decrypt(base64_decode($plaintext), $this->method, $this->key, OPENSSL_RAW_DATA, $this->iv);
		}
		
		function getbusiness($rcode){ 
			  $agRcode = $rcode["rcode"];
			  $curl = curl_init();
				curl_setopt_array($curl, array(
				  CURLOPT_URL => "https://partner.rnfi.in/api/formapi/getbusiness",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 0,
				  CURLOPT_FOLLOWLOCATION => true,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  CURLOPT_POSTFIELDS => array('rcode' => $agRcode
				)));
				$response = curl_exec($curl);
				curl_close($curl);
				//echo "<pre>"; print_r($response);
				return $response;
		    }

    }        
?>


