<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->database();
        $this->load->model('User_model');
		$this->load->library("Verification");
    }
	
	public function login(){
		$this->load->view('Admin/login');
	}
	
	public function checkLogin(){
		if($this->input->post())
    	{ 
	        $this->form_validation->set_rules('loginusername','User Name','required');
	        $this->form_validation->set_rules('loginpassword','Password','required'); 
	        if($this->form_validation->run())
	        {
				$username = $this->input->post('loginusername');
				$password = md5($this->input->post('loginpassword')); 
				$result = $this->User_model->CheckAdminDetail($username, $password); 
	            if (!empty($result)) { 
	                $sess_array = array();
	                    $sess_array = array(
	                        'id' => $result->id,
	                        'username' => $result->username,
	                        'password' => $result->password,
							'is_admin' => 1,
							'uid' =>''
	                    );
	                    $this->session->set_userdata('logged_in', $sess_array);
	                    redirect('/Login/index');
	            }
	            else
	            {   
					$userResult = $this->User_model->CheckUserDetail($username, $password);
					 if (!empty($userResult)) { 
					    $sess_array = array();
	                    $sess_array = array(
	                        'id' => $userResult->id,
	                        'username' => $userResult->username,
							'emailid' => $userResult->emailid,
	                        'password' => $userResult->password,
							'is_admin' => 0,
							'uid' =>$userResult->id
	                    );
	                    $this->session->set_userdata('logged_in', $sess_array);
	                    redirect('/Login/index');
					 }else{ 
						$this->session->set_flashdata("invalid_credential","Please Enter Valid Credentials");
						redirect(base_url().'admin');
					 }
	            }
	        }
	        else
	        {
	        	$this->load->view('Login/login');
	        }
    	  }
		 else
		 {
		  $this->load->view('Login/login');
		 }
	   }
	
    public function index(){
        if (!empty($this->session->userdata('logged_in'))){ 
            $loggedInArr = $this->session->userdata('logged_in');
            $username = $loggedInArr['username'];
            $password = $loggedInArr['password'];
			$is_admin = $loggedInArr['is_admin']; 
			$uid = $loggedInArr['uid'];
			if($is_admin==0 && $uid!=""){ 
				$result = $this->User_model->CheckUserDetail($username, $password);
				$activeUser = $this->User_model->CheckUserActiveaccount($username, $password,$uid);
				if(!empty($activeUser)){
				  $this->session->set_flashdata("invalid_credential","Account is not active! please contact admin of icici panel");
				  redirect(base_url().'admin');
				}else{ 
				 $userResult = $this->User_model->CheckUserDetail($loggedInArr['emailid'], $password);
				 $adminOtp =  $this->verification->sendOtp($userResult->mobileno,$isAdmin=0,$userResult->id);
				 if($userResult && $adminOtp){
					$aOtp_array = array(
					'id' => $userResult->id,
					'username' => $userResult->username,
					'emailid' => $userResult->emailid,
					'is_admin' => 0,
					'uid' =>$userResult->id,
					'admin_otp' =>$adminOtp,
					'mobile_no'=>$userResult->mobileno
	                 );
					}
					$this->session->set_userdata('logged_adminotp_in', $aOtp_array);
					redirect('/login/adminotp'); 
				}
			}else{
              $result = $this->User_model->CheckAdminDetail($username, $password);
			  $adminOtp =  $this->verification->sendOtp($result->mobile_no,$isAdmin=1,$result->id);
			  if($result &&  $adminOtp){
				$aOtp_array = array(
					'id' => $result->id,
					'username' => $result->username,
					'password' => $result->password,
					'is_admin' => 1,
					'admin_otp' =>$adminOtp,
					'mobile_no'=>$result->mobile_no
				);
	            $this->session->set_userdata('logged_adminotp_in', $aOtp_array);
           	    redirect('/login/adminotp'); 
			 }
			}
           } else {
             redirect(base_url());
         }
       }
	   
	 public function logout() 
		{
			$this->session->sess_destroy();
			redirect('/login/login');
		} 

	 public function adminotp(){
		$this->load->view('Admin/adminotp');
	 }

	 public function checkadmin_otp(){
		  if (!empty($this->session->userdata('logged_in'))){
			  $loggedInArr = $this->session->userdata('logged_adminotp_in');
			   if($this->input->post("loginusername")== $loggedInArr["admin_otp"]){
				  $validOtp = $this->User_model->checkValidOTP($loggedInArr["admin_otp"],$loggedInArr["id"]);
				  if($validOtp){
					 $this->User_model->changeIsActiveStatus();
				     redirect('/user/dashboard');   
				  }else{
					 $this->session->set_flashdata("invalid_credential","Otp is wrong! please fill right otp");
				     redirect(base_url('login/adminotp'));   
				 }
			   }else{
				  $this->session->set_flashdata("invalid_credential","Otp is wrong! please fill right otp");
				  redirect(base_url('login/adminotp'));  
			 }
		    } else {
			 redirect(base_url());
		   }
	 }	

}