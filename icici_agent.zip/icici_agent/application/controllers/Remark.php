	<?php
		class Remark extends MY_Controller {
			public function __construct(){
			parent::__construct();
			$this->load->database();
			$this->load->model('Remark_model');
			date_default_timezone_set('Asia/Kolkata');
			$this->loggedInArr = $this->session->userdata('logged_in');
		 }
		 
		   
		   public function add(){
			  if(!empty($this->session->userdata('logged_in'))){
			   //$data["allAgent"] = $this->Agent_model->getAllAgents();
			  // print_r($data["allAgent"]);die;
			   $this->middle = 'Admin/Remark/add'; 
			   $this->layout();    
			  } else {
			    redirect(base_url());
		    }
		   }
		   
		   public function save(){  
			if(!empty($this->session->userdata('logged_in'))){
				 $this->form_validation->set_rules('editor_contents', 'Remarks', 'trim|required|xss_clean');
				 
				 $this->session->set_userdata('editor_contents', trim($this->input->post('editor_contents')));		
				 if($this->form_validation->run() == TRUE){	 
					$editor_contents = $this->input->post('editor_contents');
					$saveRemarks = array(
					'remark'=>$editor_contents,
					'created_at'=>date('Y-m-d H:i:s'));
					$this->Remark_model->saveRemarks($saveRemarks);
					redirect(base_url('remark/index'));
				}else{ echo "bbb";die;
				  redirect(base_url('remark/add'));
			    }
			} else {
			 redirect(base_url());
		  }
		}	
		   
		    public function index(){
				  if (!empty($this->session->userdata('logged_in'))){
				    $start = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
					$limit = 20;
					$search_str = $this->input->get("search_str");
	                $this->middle = 'Admin/Remark/index'; 
	                $data['allRemarks'] = $this->Remark_model->getvalue_remark_master($limit,$start,$search_str);
	            
					$config['base_url'] = base_url()."remark/index";
					$config['total_rows'] = $this->Remark_model->count_getvalue_remark_master($search_str);
					$config['per_page'] = $limit;
					if(!empty($search_str))
					{
					  	$config['suffix'] = '&search_str=' . $search_str;						
					}
					
					$config["uri_segment"] = 3;
					$this->pagination->initialize($config);
					
					$data["config"] = $config;
					$this->layout($data);              	
			    } else {
					 redirect(base_url());
			   }
		    }
		   
		    public function remove($agent=NULL){
			  if(!empty($this->session->userdata('logged_in'))){
				   $id= decrypt_method($agent);
				   $data["agent"] = $this->Remark_model->removeRemarks($id);
			   } else {
				 redirect(base_url());
			   }
		  }
		  
		  public function edit($id=NULL){
			if(!empty($this->session->userdata('logged_in'))){
				  $id= decrypt_method($id);
				  $data["tRemark"] = $this->Remark_model->getSingleRemark($id);
				  $this->middle = 'Admin/Remark/edit';
				  $this->layout($data);
			   } else {
				 redirect(base_url());
			   }
		    }
		
		public function update(){
			if(!empty($this->session->userdata('logged_in'))){
				 $this->form_validation->set_rules('editor_contents', 'Remarks', 'trim|required|xss_clean');
				 
				 $this->session->set_userdata('name', trim($this->input->post('name')));		
				 if($this->form_validation->run() == TRUE){	   
					$remark_id = decrypt_method($this->input->post('remark_id'));
					$editor_contents = $this->input->post('editor_contents');
					$updateRemarks = array(
					'remark'=>$editor_contents,
					'modify_at'=>date('Y-m-d H:i:s'));
					$this->Remark_model->updateRemarks($updateRemarks,$remark_id);
					redirect(base_url('agent/listremarks'));
				}else{
				  $remark_id = $this->input->post('remark_id');
				  redirect(base_url('remark/edit/'.encrypt_method($remark_id)));
			    }
			 } else {
			   redirect(base_url());
		  }
		}
		   
		  public function unlockagent($agent=NULL){
			  if(!empty($this->session->userdata('logged_in'))){
				$id= decrypt_method($agent);
				$result = $this->Agent_model->unLockAgent($id);
			   }else {
				 redirect(base_url());
			   }
		  } 
		  
		  public function lockagent($agent=NULL){
			  if(!empty($this->session->userdata('logged_in'))){
				   $id= decrypt_method($agent);
				   $result = $this->Agent_model->LockAgent($id);
			   } else {
				 redirect(base_url());
			   }
		   }

     }