	<?php
		class Report extends MY_Controller {
			public function __construct(){
			parent::__construct();
			$this->load->database();
			$this->load->model('Agent_model');
			$this->load->model('Remark_model');
			$this->load->model('Campaign_model');
			$this->load->model('Report_model');
			date_default_timezone_set('Asia/Kolkata');
			$this->loggedInArr = $this->session->userdata('logged_in');
		 }
		 
		   
		    public function campaign(){
			  if(!empty($this->session->userdata('logged_in'))){
				$search_str = $this->input->get("search_str");
				if($search_str!=""){
					$data["AllCamps"] = $this->Report_model->exportToCampCsv($search_str);
					//echo "<pre>";print_r($data["AllCamps"]); die;
					    ob_clean();
						header("Content-type: application/csv");
						header("Content-Disposition: attachment; filename=\"campaign".".csv\"");
						header("Pragma: no-cache");
						header("Expires: 0");
					
					$handle = fopen('php://output', 'w');
					fputcsv($handle, array("Sr No", "Campaign Name", "Rcode", "CallBack", "Discussion", "Remark", "Agent Status", "LockBy","Retailer Name","Retailer Mobileno","State"));
					foreach($data["AllCamps"] as $i=>$camp){
					 $bsDetails = $this->Report_model->getBsDetails($camp["agentid"],$camp["rcode"]);
					 $state = (isset($bsDetails->state)) ? $bsDetails->state : '';
					 $rowArray=array($i+1,$camp["campName"],$camp["rcode"],$camp["next_callback_date"],$camp["discussion"],
					 $camp["remark"],$camp["agstatus"],$camp["username"].' ( '.$camp["mobileno"],$bsDetails->firmname,$bsDetails->phone,$state);	
					
					 fputcsv($handle, $rowArray);
					 }
					fclose($handle);
					exit;
				}else{
					$data["AllCamps"] = $this->Campaign_model->getAllCamps();
					$this->middle = 'Admin/Report/campaign'; 
					$this->layout($data);     
				}
				}
			   else {
				 redirect(base_url());
		     }
		   }
		   
		   public function agent(){
			  if(!empty($this->session->userdata('logged_in'))){
				$search_str = $this->input->get("search_str");
				if($search_str!=""){
					$data["agentReport"] = $this->Report_model->exportToCsv($search_str);
				    ob_clean();
					header("Content-type: application/csv");
					header("Content-Disposition: attachment; filename=\"agent".".csv\"");
					header("Pragma: no-cache");
					header("Expires: 0");
					$handle = fopen('php://output', 'w');
					fputcsv($handle, array('Sr No.', 'Campaign Name', 'Rcode', 'CallBack', 'Discussion', 'Remark', 'Agent Status', 'LockBy','Retailer Name','Retailer Mobileno','State','Distributor Name','Distributor Mobileno'));
					$i = 1;
					foreach ($data["agentReport"] as $data) {
					    $bsDetails = $this->Report_model->getBsDetails($data["agentid"],$data["rcode"]);
						$state = (isset($bsDetails->state)) ? $bsDetails->state : '';
						$distributor = (isset($bsDetails->distributor)) ? $bsDetails->distributor : '';
						$di_phone = (isset($bsDetails->di_phone)) ? $bsDetails->di_phone : '';
						fputcsv($handle, array($i, $data["campName"], $data["rcode"], $data["next_callback_date"], $data["discussion"], $data["remark"], $data["agstatus"], $data["username"]." (".$data["mobileno"]." ) ",$bsDetails->firmname,$bsDetails->phone,$state,$distributor,$di_phone));
						$i++;
					}
						fclose($handle);
					exit;
				}else{
					$data["agentReport"] = $this->Campaign_model->getAllCamps();
					$this->middle = 'Admin/Report/index'; 
					$this->layout($data);     
				}
				}
			   else {
				 redirect(base_url());
		     }
		   }
		   
		    public function remark(){
			  if(!empty($this->session->userdata('logged_in'))){
				$search_str = $this->input->get("search_str");
				if($search_str!=""){
					$data["agentReport"] = $this->Report_model->exportToRemarkCsv($search_str);
					ob_clean();
					header("Content-type: application/csv");
					header("Content-Disposition: attachment; filename=\"remark".".csv\"");
					header("Pragma: no-cache");
					header("Expires: 0");
					$handle = fopen('php://output', 'w');
					fputcsv($handle, array('Sr No.', 'Campaign Name', 'Rcode', 'CallBack', 'Discussion', 'Remark', 'Agent Status', 'LockBy'));
					$i = 1;
					foreach ($data["agentReport"] as $data) {
						fputcsv($handle, array($i, $data["campName"], $data["rcode"], $data["next_callback_date"], $data["discussion"], $data["remark"], $data["agstatus"], $data["username"]." (".$data["mobileno"].")"));
						$i++;
					}
						fclose($handle);
					exit;
				}else{
					$data["AllRemarks"] = $this->Remark_model->getAllRemarks();
					$this->middle = 'Admin/Report/remark'; 
					$this->layout($data);     
				}
				}
			   else {
				 redirect(base_url());
		     }
		   }
		   
		   public function agent_campaign(){
			    if(!empty($this->session->userdata('logged_in'))){
				$search_str = $this->input->get("search_str");
				if($search_str!=""){
					$data["AllCamps"] = $this->Report_model->exportToCampCsv($search_str);
					
					//echo "<pre>";print_r($data["AllCamps"]); die;
					    ob_clean();
						header("Content-type: application/csv");
						header("Content-Disposition: attachment; filename=\"agent_campaign".".csv\"");
						header("Pragma: no-cache");
						header("Expires: 0");
					
					$handle = fopen('php://output', 'w');
					fputcsv($handle, array("Sr No", "Campaign Name", "Rcode", "CallBack", "Discussion", "Remark", "Agent Status", "LockBy"));
					foreach($data["AllCamps"] as $i=>$camp){
					 $rowArray=array($i+1,$camp["campName"],$camp["rcode"],$camp["next_callback_date"],$camp["discussion"],
					 $camp["remark"],$camp["agstatus"],$camp["username"].' ( '.$camp["mobileno"]);	
					
					 fputcsv($handle, $rowArray);
					 }
					fclose($handle);
					exit;
				}else{
					$data["AllCamps"] = $this->Campaign_model->getAllCamps();
					$this->middle = 'Admin/Report/agent_campaign'; 
					$this->layout($data);     
				}
				}
			   else {
				 redirect(base_url());
		     }
		   }
		   
		   public function callingreport(){
				if(!empty($this->session->userdata('logged_in'))){
					  $search_str = $this->input->get("search_str"); 
				if($search_str!=""){
					$data["Daywise"] = $this->Report_model->exportToDaywiseCsv($search_str);
					//echo "<pre>";print_r($data["AllCamps"]); die;
					    ob_clean();
						header("Content-type: application/csv");
						header("Content-Disposition: attachment; filename=\"daywise_report".".csv\"");
						header("Pragma: no-cache");
						header("Expires: 0");
					
					$handle = fopen('php://output', 'w');
					fputcsv($handle, array("Sr No", "Campaign Name", "Rcode", "CallBack", "Discussion", "Remark", "Agent Status", "LockBy"));
					foreach($data["Daywise"] as $i=>$camp){
					 $rowArray=array($i+1,$camp["campName"],$camp["rcode"],$camp["next_callback_date"],$camp["discussion"],
					 $camp["remark"],$camp["agstatus"],$camp["username"].' ( '.$camp["mobileno"]);	
					
						fputcsv($handle, $rowArray);
					 }
						fclose($handle);
						exit;
					}else{
						$this->middle = 'Admin/Report/callingreport'; 
						$this->layout($data);     
					}
					}
					else {
						redirect(base_url());
		     }
		   }
		   
		
			
}