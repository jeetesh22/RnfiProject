	<?php
		class Agent extends MY_Controller {
			public function __construct(){
			parent::__construct();
			$this->load->database();
			$this->load->library("Verification");
			$this->load->model('Agent_model');
			$this->load->model('Remark_model');
			$this->load->model('Campaign_model');
			date_default_timezone_set('Asia/Kolkata');
			$this->loggedInArr = $this->session->userdata('logged_in');
		 }
		 
		   
		   public function add(){
			   if(!empty($this->session->userdata('logged_in'))){
				 $this->form_validation->set_rules('campaign', 'campaign', 'trim|required|xss_clean');
				 $this->session->set_userdata('campaign', trim($this->input->post('campaign')));
				 if($this->form_validation->run() == TRUE){	 
					$campaign = decrypt_method($this->input->post('campaign'));
                    $result = $this->Agent_model->saveRcodeCsv();
					if($result["success"]="success" && $result["crane_features"]==1){
					$this->session->set_flashdata("message","Agent is successfully added!");
					redirect(base_url('agent/index'));
				  }
				}else{ 
				   $data["AllCamps"] = $this->Campaign_model->getAllCamps();
				   $this->middle = 'Admin/Agent/addagent'; 
				   $this->layout($data);
			    }
				} else {
				 redirect(base_url());
			   }				
		     }
		   
		    public function index(){
			  if(!empty($this->session->userdata('logged_in'))){ 
				$assignUser = $this->Campaign_model->searchAssignUserInCamp($this->loggedInArr["id"]); 
				$data["allCampaign"] = $this->Campaign_model->getAllCamps(); 
				if(!empty($assignUser)){
				$start = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
				$limit = 20;
				$search_str = $this->input->get("search_str");
				$search_camp = decrypt_method($this->input->get("search_camp"));
				$this->middle = 'Admin/Agent/index'; 
				$data['agents'] = $this->Agent_model->getvalue_agent_master($limit,$start,$search_str,$search_camp);
			
				$config['base_url'] = base_url()."agent/index";
				$config['total_rows'] = $this->Agent_model->count_getvalue_agent_master($search_str,$search_camp);
				$config['per_page'] = $limit;
				$config['suffix'] = '?search_str=' . $search_str . '&search_camp=' . encrypt_method($search_camp);				
				$data["page_url"] = $start.$config["suffix"];
				$config["uri_segment"] = 3;
				$this->pagination->initialize($config);
				$data["config"] = $config;
				$this->layout($data);              	
			   }else{
				    $this->session->set_flashdata("message","Campaign is not assign! please assign campaign and after show the agents");
				   $this->middle = 'Admin/Agent/error_page'; 
				   $this->layout();  
			    } 
				}
			   else {
				 redirect(base_url());
		     }
		   }
		   
		    public function agentlist(){
			  if(!empty($this->session->userdata('logged_in'))){
				$start = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
				$limit = 20;
				$search_str = $this->input->get("search_str");
				$search_camp = $this->input->get("search_camp");
				$this->middle = 'Admin/Agent/agentlist'; 
				$data['agents'] = $this->Agent_model->getvalue_agent_master($limit,$start,$search_str,$search_camp);
			
				$config['base_url'] = base_url()."agent/agentlist";
				$config['total_rows'] = $this->Agent_model->count_getvalue_agent_master($search_str,$search_camp);
				$config['per_page'] = $limit;
				if(!empty($search_str))
				{
					$config['suffix'] = '&search_str=' . $search_str;						
				}
				$config["uri_segment"] = 3;
				$this->pagination->initialize($config);
				$data["config"] = $config;
				$this->layout($data);              	
				}
			   else {
				 redirect(base_url());
		     }
		   }
		   
		   
		   public function todaycallback(){
			    if(!empty($this->session->userdata('logged_in'))){
				$assignUser = $this->Campaign_model->searchAssignUserInCamp($this->loggedInArr["id"]); 
				$data["allCampaign"] = $this->Campaign_model->getAllCamps();
				if(!empty($assignUser)){
				$start = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
				$limit = 20;
				$search_str = $this->input->get("search_str");
				$search_camp = decrypt_method($this->input->get("search_camp"));
				$this->middle = 'Admin/Agent/todaycallback'; 
				$data['agents'] = $this->Agent_model->getvalue_agenttoday_master($limit,$start,$search_str,$search_camp);
			
				$config['base_url'] = base_url()."agent/todaycallback";
				$config['total_rows'] = $this->Agent_model->count_getvalue_agenttoday_master($search_str,$search_camp);
				$config['per_page'] = $limit;
				$config['suffix'] = '?search_str=' . $search_str . '&search_camp=' . $search_camp;	
				$config["uri_segment"] = 3;
				$this->pagination->initialize($config);
				$data["config"] = $config;
				$this->layout($data);
				}else{
				   $this->session->set_flashdata("message","Campaign is not assign! please assign campaign and after show the agents");
				   $this->middle = 'Admin/Agent/error_page'; 
				   $this->layout();  
			     } 
			   } else {
				 redirect(base_url());
		     }
		   }
		   
		  public function unlockagent($agent=NULL){
			  if(!empty($this->session->userdata('logged_in'))){
				 $id= decrypt_method($agent);
				 $result = $this->Agent_model->unLockAgent($id);
			   }else {
				 redirect(base_url());
			  }
		    } 
		  
		 /*  public function lockagent($agent=NULL){
			  if(!empty($this->session->userdata('logged_in'))){
				   $id= decrypt_method($agent);
				   $result = $this->Agent_model->LockAgent($id);
			   } else {
				 redirect(base_url());
			   }
		   } */

		 public function edit($agent=NULL){
			if(!empty($this->session->userdata('logged_in'))){
				   $id= decrypt_method($agent);
				   $data["AllCamps"] = $this->Campaign_model->getAllCamps();
				   $data["agent"] = $this->Agent_model->getSingleAgents($id);
				   $this->middle = 'Admin/Agent/edit'; 
				   $this->layout($data);    
			     } else {
				    redirect(base_url());
			   }
		    } 
		  
		  public function update(){ 
			  if(!empty($this->session->userdata('logged_in'))){
				   $id= decrypt_method($this->input->post("agent_id"));
				   $rcode = $this->input->post("rcode");
				   $campaign = $this->input->post("campaign");
				   $data["agent"] = $this->Agent_model->updateAgent($id,$rcode,$campaign); 
			   } else {
				 redirect(base_url());
			   }
		  }

		  public function delete($agent=NULL){
			  if(!empty($this->session->userdata('logged_in'))){
				   $id= decrypt_method($agent);
				   $data["agent"] = $this->Agent_model->removeAgent($id);
			   } else {
				 redirect(base_url());
			   }
		  }

		public function addagent(){
			if(!empty($this->session->userdata('logged_in'))){
				$data["AllCamps"] = $this->Campaign_model->getAllCamps();
				$this->middle = 'Admin/Agent/addagent'; 
				$this->layout($data);
			  } else {
			    redirect(base_url());
		    }
		 }
		 
		
		public function addagentbusiness($id=NULL){  
			if(!empty($this->session->userdata('logged_in'))){
				$id= decrypt_method($id);
				$lockResult = $this->Agent_model->LockAgent($id);
				if($lockResult){
				$data["agent"] = $this->Agent_model->getSingleAgentCamp($id);
				$data["remarks"] = $this->Remark_model->getAllRemarks();
				$rcode = $data["agent"];
				$agentBs = $this->Agent_model->getSingleAgentBs($id,$rcode);
				if(empty($agentBs)){
					$agentBusiness =  $this->verification->getBusiness($rcode);
					$agData = json_decode($agentBusiness);
					if($agData->code==200 && $agData->status==1 && $agData->message=="Success."){ 
						$saveAgBsArr = array(
						'agent_id'=>$data["agent"]["id"],
						'agent_code'=>$rcode["rcode"],
						'mobile_no'=>$agData->userdetails->phone,
						'email_id'=>$agData->userdetails->email,
						'name'=>$agData->userdetails->name,
						'firmname'=>$agData->userdetails->firmname,
						'vstscode'=>$agData->userdetails->vstscode,
						'addeddate'=>$agData->userdetails->addeddate,
						'userdetails'=>json_encode($agData->userdetails),
						'business'=>json_encode($agData->business),
						'created_at'=>date('Y-m-d H:i:s'));
					 $result = $this->Agent_model->saveAgentBsRecord($saveAgBsArr);
					 if($result){ 
					   $record = $this->Agent_model->getSingleAgentBsRecord($result);
					   $data["lastResult"] = $result;
					   $data["bsDetails"] = $record;
					   $this->middle = 'Admin/Agent/addagentbusiness'; 
    				   $this->layout($data); 
					  }
				     }else{
				        $data["code"] = $agData->code;
				        $data["status"] = $agData->status;
				        $data["message"] = $agData->message;
				        $this->middle = 'Admin/Agent/error_page'; 
    				    $this->layout($data);
				    }
					}else{  
						$data["lastResult"] = $agentBs["id"];
						$data["bsDetails"] = $agentBs;
						$this->middle = 'Admin/Agent/addagentbusiness'; 
    				    $this->layout($data); 
					}
			    }else{
					$this->session->set_flashdata("message","Please again click agent business!");
					redirect(base_url('agent/index'));
				}
			} else {
			 redirect(base_url());
		  }
		}
		
		public function saveagentbusiness(){
			if(!empty($this->session->userdata('logged_in'))){ 
				 //$this->form_validation->set_rules('business_detail', 'Business Detail', 'trim|required|xss_clean');
				 $this->form_validation->set_rules('remark', 'Remark', 'trim|required|xss_clean');
				 $this->form_validation->set_rules('description', 'Description', 'trim|required|xss_clean');
				 $this->form_validation->set_rules('status', 'Status', 'trim|required|xss_clean');
				 
				 //$this->session->set_userdata('business_detail', trim($this->input->post('business_detail')));
				 $this->session->set_userdata('remark', trim($this->input->post('remark')));
				 $this->session->set_userdata('description', trim($this->input->post('description')));
				 $this->session->set_userdata('status', trim($this->input->post('status')));
				 
				 if($this->form_validation->run() == TRUE){	 
					$agent_id = decrypt_method($this->input->post('agent_id')); 
					$business_id = decrypt_method($this->input->post('business_id'));
					
					$rcode = $this->input->post('rcode');
					$business_detail = $this->input->post('business_detail');
					$remark = $this->input->post('remark');
					$description = $this->input->post('description');
					$callback_date = $this->input->post('callback_date'); 
					$status = $this->input->post('status');
					$loginUser = $this->loggedInArr["id"];
					$campaign_id = decrypt_method($this->input->post('campaign_id'));
					$businessDetails = $this->Agent_model->getAgentBusiness($agent_id,$loginUser);
					$callbackDate = ($callback_date) ? date("Y-m-d",strtotime($callback_date)) : '';
					
					$saveAgentArr = array(
					'agent_id'=>$agent_id,
					'userid'=>$loginUser,
					'business_id'=>$business_id,
					'remark'=>$remark,
					'discussion'=>$description,
					'status'=>$status,
					'campaign_id'=>$campaign_id,
					'next_callback_date'=>$callbackDate
					);
					
					if(!empty($businessDetails)){
						 $saveAgentArr['modify_at'] = date('Y-m-d H:i:s');
						 $this->Agent_model->updateBusinessAgent($saveAgentArr,$businessDetails['id'],$recall=1);
					}else{ 
					     $saveAgentArr['created_at'] = date('Y-m-d H:i:s');
						 $this->Agent_model->saveBusinessAgent($saveAgentArr,$recall=1);
					}
					redirect(base_url('agent/indexbusiness'));
				}else{ 
				  $this->session->set_flashdata("message","Please select Remark");
				  redirect(base_url('agent/viewagentbusiness/'.$this->input->post('agent_id')));
			    }
				} else {
				 redirect(base_url());
			   }				
		    }
		
		public function indexbusiness(){
		  if(!empty($this->session->userdata('logged_in'))){
			$start = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
			$limit = 20;
			$search_str = $this->input->get("search_str");
			$this->middle = 'Admin/Agent/indexbusiness'; 
			$data['agentsBusiness'] = $this->Agent_model->getvalue_agentbusiness_master($limit,$start,$search_str);
			$config['base_url'] = base_url()."agent/indexbusiness";
			$config['total_rows'] = $this->Agent_model->count_getvalue_agentbusiness_master($search_str);
			$config['per_page'] = $limit;
			if(!empty($search_str))
			{
				$config['suffix'] = '&search_str=' . $search_str;						
			}
			$config["uri_segment"] = 3;
			$this->pagination->initialize($config);
			$data["config"] = $config;
			$this->layout($data);              	
			} else {
				 redirect(base_url());
		   }
		 }
		
		 public function removebusiness($agent=NULL){
			  if(!empty($this->session->userdata('logged_in'))){
				 $id= decrypt_method($agent);
				 $data["agent"] = $this->Agent_model->removeBusinessAgent($id);
			   } else {
				 redirect(base_url());
			   }
		  }
		  
		 public function viewagentbusiness($id=NULL){ 
			 if(!empty($this->session->userdata('logged_in'))){
		        $id= decrypt_method($id);
				$lockResult = $this->Agent_model->LockAgent($id);
				if($lockResult){
				$data["agent"] = $this->Agent_model->getSingleAgentCamp($id);
				$data["agentRemark"] = $this->Agent_model->getSingleAgentRemark($id);
				$data["remarks"] = $this->Remark_model->getAllRemarks();
			
				$rcode = $data["agent"];
				$data["agent_id"] = $id;
				$agentBs = $this->Agent_model->getSingleAgentBs($id,$rcode);
				if(!empty($agentBs)){ 
					$data["lastResult"] = $agentBs["id"];
					$data["bsDetails"] = $agentBs;
                    $data["agentCampRkBs"] = $this->Agent_model->getSingleBS($id);
	
					$this->middle = 'Admin/Agent/viewbusiness'; 
					$this->layout($data); 
				}
			    }else{
					$this->session->set_flashdata("message","Please again click agent business!");
					redirect(base_url('agent/index'));
				}
			} else {
			 redirect(base_url());
		  }
		 }

		 public function userlockagent(){
			 if(!empty($this->session->userdata('logged_in'))){ 
				$assignUser = $this->Campaign_model->searchAssignUserInCamp($this->loggedInArr["id"]);
				$data["allCampaign"] = $this->Campaign_model->getAllCamps(); 				
				if(!empty($assignUser)){
				$start = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
				$limit = 20;
				$search_str = $this->input->get("search_str");
				$search_camp = decrypt_method($this->input->get("search_camp"));
				$this->middle = 'Admin/Agent/lockagent'; 
				$data['agents'] = $this->Agent_model->getvalue_agentlock_master($limit,$start,$search_str,$search_camp);
			   
				$config['base_url'] = base_url()."agent/userlockagent";
				$config['total_rows'] = $this->Agent_model->count_getvalue_agentlock_master($search_str,$search_camp);
				$config['per_page'] = $limit;
				$config['suffix'] = '?search_str=' . $search_str . '&search_camp=' . $search_camp;	
				$config["uri_segment"] = 3;
				$this->pagination->initialize($config);
				$data["config"] = $config;
				$this->layout($data);              	
			   }else{
			     $this->session->set_flashdata("message","Campaign is not assign! please assign campaign and after show the agents");
			     $this->middle = 'Admin/Agent/error_page'; 
			     $this->layout();  
			    } 
				}
			   else {
				 redirect(base_url());
		     }
		 }

		public function savelockbusiness(){
			 if(!empty($this->session->userdata('logged_in'))){ 
				 //$this->form_validation->set_rules('business_detail', 'Business Detail', 'trim|required|xss_clean');
				 $this->form_validation->set_rules('remark', 'Remark', 'trim|required|xss_clean');
				 $this->form_validation->set_rules('description', 'Description', 'trim|required|xss_clean');
				 $this->form_validation->set_rules('status', 'Status', 'trim|required|xss_clean');
				 
				 //$this->session->set_userdata('business_detail', trim($this->input->post('business_detail')));
				 $this->session->set_userdata('remark', trim($this->input->post('remark')));
				 $this->session->set_userdata('description', trim($this->input->post('description')));
				 $this->session->set_userdata('status', trim($this->input->post('status')));
				 
				 if($this->form_validation->run() == TRUE){	 
					$agent_id = decrypt_method($this->input->post('agent_id')); 
					$business_id = decrypt_method($this->input->post('business_id'));
					
					$rcode = $this->input->post('rcode');
					$business_detail = $this->input->post('business_detail');
					$remark = $this->input->post('remark');
					$description = $this->input->post('description');
					$callback_date = $this->input->post('callback_date'); 
					$status = $this->input->post('status');
					$loginUser = $this->loggedInArr["id"];
					$campaign_id = decrypt_method($this->input->post('campaign_id'));
					$callbackDate = ($callback_date) ? date("Y-m-d",strtotime($callback_date)) : '';
					
					$saveAgentArr = array(
					'agent_id'=>$agent_id,
					'userid'=>$loginUser,
					'business_id'=>$business_id,
					'remark'=>$remark,
					'discussion'=>$description,
					'status'=>$status,
					'campaign_id'=>$campaign_id,
					'next_callback_date'=>$callbackDate
					);
				
					$saveAgentArr['created_at'] = date('Y-m-d H:i:s');
					$this->Agent_model->saveBusinessAgent($saveAgentArr,$recall=0);
					redirect(base_url('agent/userlockagent'));
				}else{  
				   $this->session->set_flashdata("message","Please select Remark");
				   redirect(base_url('agent/viewagentbusiness/'.$this->input->post('agent_id')));
			    }
				} else {
				 redirect(base_url());
			   }				
		}	
		
			
}