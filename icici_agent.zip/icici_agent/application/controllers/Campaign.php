	<?php
		class Campaign extends MY_Controller {
			public function __construct(){
			parent::__construct();
			$this->load->database();
			$this->load->model('Campaign_model');
			$this->load->model('User_model');
			date_default_timezone_set('Asia/Kolkata');
			$this->loggedInArr = $this->session->userdata('logged_in');
		 }
		 
		   
		   public function add(){
			   if(!empty($this->session->userdata('logged_in'))){
				 $this->middle = 'Admin/Campaign/add'; 
				 $this->layout();    
				 } else {
				  redirect(base_url());
				}
		     }
			 
			 public function save(){
				if(!empty($this->session->userdata('logged_in'))){
				 $this->form_validation->set_rules('name', 'Campaign Name', 'trim|required|xss_clean');
				 
				 $this->session->set_userdata('name', trim($this->input->post('name')));		
				 if($this->form_validation->run() == TRUE){	   
					$name = $this->input->post('name');

					$saveCamArr = array(
					'name'=>$name,
					'created_at'=>date('Y-m-d H:i:s'));
					$this->Campaign_model->saveCampaign($saveCamArr);
				}else{ 
				   $this->middle = 'Admin/Campaign/add'; 
				   $this->layout();
			    }
				} else {
				 redirect(base_url());
			   }				
			}
		   
		    public function index(){
			  if(!empty($this->session->userdata('logged_in'))){
				$start = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
				$limit = 20;
				$search_str = $this->input->get("search_str");
				$this->middle = 'Admin/Campaign/index'; 
				$data['allCampaign'] = $this->Campaign_model->getvalue_agent_master($limit,$start,$search_str);
				$config['base_url'] = base_url()."campaign/index";
				$config['total_rows'] = $this->Campaign_model->count_getvalue_agent_master($search_str);
				$config['per_page'] = $limit;
				if(!empty($search_str))
				{
					$config['suffix'] = '&search_str=' . $search_str;						
				}
				$config["uri_segment"] = 3;
				$this->pagination->initialize($config);
				$data["config"] = $config;
				$this->layout($data);              	
			   } else {
				 redirect(base_url());
		     }
		   }
		   
		   public function delete($id=NULL){
			  if(!empty($this->session->userdata('logged_in'))){
				   $id= decrypt_method($id);
				   $data["agent"] = $this->Campaign_model->removeCampaign($id);
			   } else {
				 redirect(base_url());
			   }
		    }
		  
		  public function deactive($id=NULL){
			  if(!empty($this->session->userdata('logged_in'))){
				 $id= decrypt_method($id);
				 $result = $this->Campaign_model->deactiveCamp($id);
			   }else {
				 redirect(base_url());
			  }
		    } 
		  
		  public function active($agent=NULL){
			  if(!empty($this->session->userdata('logged_in'))){
				   $id= decrypt_method($agent);
				   $result = $this->Campaign_model->activeCamp($id);
			   } else {
				 redirect(base_url());
			   }
		   }

		 public function edit($agent=NULL){
			if(!empty($this->session->userdata('logged_in'))){
				   $id= decrypt_method($agent);
				   $data["camp"] = $this->Campaign_model->getCampAgents($id);
				   $this->middle = 'Admin/Campaign/edit'; 
				   $this->layout($data);    
			     } else {
				    redirect(base_url());
			   }
		    } 
		  
		  public function update(){ 
			  if(!empty($this->session->userdata('logged_in'))){
				 $this->form_validation->set_rules('name', 'User Name', 'trim|required|xss_clean');
				 		
				 $this->session->set_userdata('name', trim($this->input->post('mobileno')));	
				 if($this->form_validation->run() == TRUE){	
					$camp_id = decrypt_method($this->input->post('camp_id'));				 
					$name = $this->input->post('name');	
					$updatecampArr = array(
					'name'=>$name,
					'modify_at'=>date('Y-m-d H:i:s'));
					$this->Campaign_model->updateCampData($updatecampArr,$camp_id);
					redirect(base_url('user/adduser'));
				}else{ 
				   $this->middle = 'Admin/User/adduser'; 
				  $this->layout();
			    }
				} else {
				 redirect(base_url());
			   }				
		    }
			
			public function assignuser($campid=NULL){
				if(!empty($this->session->userdata('logged_in'))){
				   $id= decrypt_method($campid);
				   $data["getcamp"] = $this->Campaign_model->getCampAgents($id);
				   $data["allUser"] = $this->User_model->getAllUsers();
				   $this->middle = 'Admin/Campaign/assignuser'; 
				   $this->layout($data);    
			     } else {
				    redirect(base_url());
			   }
			}
			
		public function saveassignuser(){
			if(!empty($this->session->userdata('logged_in'))){
				 $this->form_validation->set_rules('assign_team[]', 'Assign User', 'trim|required|xss_clean');
				 if($this->form_validation->run() == TRUE){	
				 $assign_team = $this->input->post('assign_team[]');
				 $assignUser  = implode(',', $assign_team);				 
				 $camp_id = $this->input->post('camp_id');
				 $saveCamArr = array(
					'assign_user'=>$assignUser,
					'modify_at'=>date('Y-m-d H:i:s'));
				 $this->Campaign_model->saveassignUser($saveCamArr,$camp_id);
				}else{
				   $id = $this->input->post('camp_id');
				   $data["getcamp"] = $this->Campaign_model->getCampAgents($id);
				   $data["allUser"] = $this->User_model->getAllUsers();	
				   $this->middle = 'Admin/Campaign/assignuser'; 
				   $this->layout($data);
			    }
				} else {
				 redirect(base_url());
			   }				
		    }	
			
}