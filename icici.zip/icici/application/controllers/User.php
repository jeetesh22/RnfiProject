	<?php
		class User extends MY_Controller {
			public function __construct(){
			parent::__construct();
			$this->load->database();
			$this->load->model('User_model');
			$this->load->model('Bank_model');
			//$this->load->helper('encrypt_helper');
			date_default_timezone_set('Asia/Kolkata');
		 }
		 public function dashboard()
		  {
		    if (!empty($this->session->userdata('logged_in'))){
				$crateSession =  $this->session->userdata('logged_in');
				$data['username'] = $crateSession['username'];
				$data['id'] = $crateSession['id'];
				$is_admin = $crateSession['is_admin']; 
				$uid = $crateSession['uid'];
				if($is_admin==0 && $uid!=""){ 
				  //user dashboard
				   $data["getAssignBank"] = $this->User_model->getAssignBanks($data['id']);
				   if(!empty($data["getAssignBank"])){
				   	$bankDetails = $this->Bank_model->getSingleBankDetails(array_column($data["getAssignBank"],'bankid'));
				   $out=array();
				   foreach($bankDetails as $x){
					  $out[$x['bank_id']]['details'][]=array('id'=>$x['id'],'username'=>$x['username'],
					  'corporate_id'=>$x['corporate_id'],'mobile_no'=>$x['mobile_no'],'bank_id'=>$x['bank_id']);
					}
				    $data["bankDetails"] = $out;
				   }
				   $this->middle = 'Admin/User/user_dashboard'; 
				}else{
					//admin dashboard
				  $this->middle = 'Admin/User/dashboard'; 
				}
				$this->layout($data);
				} else {
				 redirect(base_url());
			   }
		   }
		   
		   public function adduser(){
		   		//jwt::encode("shyam", "122dgfghgkjhkjk") ;
			   if(!empty($this->session->userdata('logged_in'))){
				  $this->middle = 'Admin/User/adduser'; 
				  $this->layout();
				} else {
				 redirect(base_url());
			   }
		    }
			
			 public function edit($id=NULL){
			   if(!empty($this->session->userdata('logged_in'))){
				  $data["getUser"] = $this->User_model->getUser(decrypt_method($id));
				  $this->middle = 'Admin/User/edit'; 
				  $this->layout($data);
				} else {
				 redirect(base_url());
			   }
		    }
			
			public function updateuser(){
				if(!empty($this->session->userdata('logged_in'))){
				 $this->form_validation->set_rules('username', 'User Name', 'trim|required|xss_clean');
				 $this->form_validation->set_rules('mobileno', 'Mobile No', 'trim|required|xss_clean|max_length[11]|min_length[10]');
				 
				 $this->session->set_userdata('username', trim($this->input->post('username')));		
				 $this->session->set_userdata('mobileno', trim($this->input->post('mobileno')));
				 $this->session->set_userdata('login_type', trim($this->input->post('login_type')));	
				 if($this->form_validation->run() == TRUE){	
					$userid 		= $this->input->post('userid');				 
					$username 		= $this->input->post('username');
					$emailid 		= $this->input->post('emailid');
					$mobileno 		= $this->input->post('mobileno');
					$login_type 	= $this->input->post('login_type');
					$updateuserArr 	= array(
					'username'		=> $username,
					'emailid'		=> $emailid,
					'mobileno'		=> $mobileno,
					'login_type'	=> $login_type,
					'modify'		=> date('Y-m-d H:i:s'));
					$this->User_model->updateUserData($updateuserArr,$userid);
					redirect(base_url('user/adduser'));
				}else{ 
				   $this->middle = 'Admin/User/adduser'; 
				  $this->layout();
			    }
				} else {
				 redirect(base_url());
			   }				
			} 
			
			public function saveuser(){
				if(!empty($this->session->userdata('logged_in'))){
				 $this->form_validation->set_rules('username', 'User Name', 'trim|required|xss_clean');
				 $this->form_validation->set_rules('mobileno', 'Mobile No', 'trim|required|xss_clean|max_length[11]|min_length[10]|is_unique[users.mobileno]');
				 $this->form_validation->set_rules('emailid', 'Email Id', 'trim|required|valid_email|xss_clean|is_unique[users.emailid]');
				 $this->form_validation->set_rules('login_type', 'Login Type', 'trim|required|xss_clean');
				 
				 $this->session->set_userdata('username', trim($this->input->post('username')));		
				 $this->session->set_userdata('mobileno', trim($this->input->post('mobileno')));
				 $this->session->set_userdata('emailid', trim($this->input->post('emailid')));
				 $this->session->set_userdata('login_type', trim($this->input->post('login_type')));	
				 if($this->form_validation->run() == TRUE){	   
					$username 		= $this->input->post('username');
					$emailid 		= $this->input->post('emailid');
					$mobileno 		= $this->input->post('mobileno');
					$login_type 	= $this->input->post('login_type');
					$saveuserArr 	= array(
					'username'		=> $username,
					'emailid'		=> $emailid,
					'mobileno'		=> $mobileno,
					'login_type'	=> $login_type,
					'created'		=> date('Y-m-d H:i:s'));
					$this->User_model->saveUserData($saveuserArr);
					redirect(base_url('user/adduser'));
				}else{ 
				   $this->middle = 'Admin/User/adduser'; 
				  $this->layout();
			    }
				} else {
				 redirect(base_url());
			   }				
			}
		   
		   public function listuser(){
			   if (!empty($this->session->userdata('logged_in'))){
				    $start = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
					$limit = 20;
					$search_str = $this->input->get("search_str");
					$from_date = $this->input->get("from_date");
					$to_date = $this->input->get("to_date");           	
	                $this->middle = 'Admin/User/listuser'; 
	                $data['allUsers'] = $this->User_model->getvalue_user_master($limit,$start,$search_str,$from_date,$to_date);
	            
					$config['base_url'] = base_url()."user/listuser";
					$config['total_rows'] = $this->User_model->count_getvalue_user_master($search_str,$from_date,$to_date);
					$config['per_page'] = $limit;
					if(!empty($from_date) && !empty($to_date) && !empty($search_str))
					{
					  	$config['suffix'] = '?from_date=' . $from_date . '&to_date=' . $to_date . '&search_str=' . $search_str;						
					}
					
					$config["uri_segment"] = 3;
					$this->pagination->initialize($config);
					$data["config"] = $config;
					$this->layout($data);              	
			    } else {
					 redirect(base_url());
			   }
		   }
		   
		   public function deActiveUser(){
			 if (!empty($this->session->userdata('logged_in'))){  
			 if($this->input->post()){
				 $id = $this->input->post('id');
				 $status = $this->input->post('status');
				 $result = $this->User_model->changeStatus($id,$status);
				 echo $result;
			 }
			 } else {
				 redirect(base_url());
			   }
		   }
		   
		    public function ActiveUser(){
			 if (!empty($this->session->userdata('logged_in'))){  
			 if($this->input->post()){
				 $id = $this->input->post('id');
				 $status = $this->input->post('status');
				 $result = $this->User_model->changeStatus($id,$status);
				 echo $result;
			 }
			 } else {
				 redirect(base_url());
			   }
		   }
		   
		  public function removeUser(){
			 if (!empty($this->session->userdata('logged_in'))){  
			 if($this->input->post()){
				 $id = $this->input->post('id');
				 $result = $this->User_model->deleteUser($id);
				 echo $result;
			 }
			 } else {
				 redirect(base_url());
			   }
		   }
		   
		  public function addpassword($id){
			 if (!empty($this->session->userdata('logged_in'))){  
			 if($id){
				$data['passvalue'] = $this->User_model->getPassword(decrypt_method($id));
				$data['userId'] =decrypt_method($id) ;
				$this->middle = 'Admin/User/addpassword'; 
				$this->layout($data);
			  }
			 } else {
				 redirect(base_url());
			   }
		   }
		   
		   public function savepassword(){
			  if(!empty($this->session->userdata('logged_in'))){
				  $this->form_validation->set_rules('password', 'Password', 'trim|required');
				  $this->form_validation->set_rules('cpassword', 'Confirm Password', 'trim|required|matches[password]');

				  $this->session->set_userdata('password', trim($this->input->post('password')));		
				  $this->session->set_userdata('cpassword', trim($this->input->post('cpassword')));	
				  if($this->form_validation->run() == TRUE){	   
					$userId = $this->input->post('userid');
					$cpassword = md5($this->input->post('cpassword'));
					$spasswordArr = array(
					'password'=>$cpassword,
					'modify'=>date('Y-m-d H:i:s'));
					$this->User_model->saveUserPassword($spasswordArr,$userId);
					redirect(base_url('user/adduser'));
				}else{ 
				   $data['userId'] =$this->input->post('userid');
				   $this->middle = 'Admin/User/addpassword'; 
				   $this->layout($data);
			    }
				} else {
				 redirect(base_url());
			   }				 
		   }
		   
		   public function sharelogin(){
			 if (!empty($this->session->userdata('logged_in'))){ 
				$data["allUsers"] 	= $this->User_model->getAllUsers();
				$data["banks"] 		= $this->Bank_model->getAllBank();
				//$data["assignBank"] = $this->Bank_model->assignUserBank();
				$this->middle = 'Admin/User/sharelogin'; 
				$this->layout($data);
			  } else {
				 redirect(base_url());
			 } 
		   }
		   
		   public function assignbankuser(){
			 if (!empty($this->session->userdata('logged_in'))){  
			 if($this->input->post()){
				 $assignUser = $this->input->post('assignUser');
				 $bankId = $this->input->post('bankId');
				 $result = $this->User_model->saveAssignBankUser($bankId,$assignUser);
				 echo $result;
			 }
			 } else {
				 redirect(base_url());
			 }
		   }
		   
		   public function unAssignbankuser(){
			 if (!empty($this->session->userdata('logged_in'))){  
			 if($this->input->post()){
				 $assignUser = $this->input->post('assignUser');
				 $bankId = $this->input->post('bankId');
				 $result = $this->User_model->unAssignbankuser($bankId,$assignUser);
				 echo $result;
			 }
			 } else {
				 redirect(base_url());
			 }
		   }
		   
		   public function adminprofile(){
			 if (!empty($this->session->userdata('logged_in'))){
				$data['adminData'] = $this->User_model->getAdminRecord();	
				$this->middle = 'Admin/User/adminprofile'; 
			    $this->layout($data);
			 } else {
				 redirect(base_url());
			 }
		   }
		   
		   public function updateprofile(){
			   if (!empty($this->session->userdata('logged_in'))){
				$this->form_validation->set_rules('username', 'username', 'trim|required');
				  $this->form_validation->set_rules('mobile_no', 'Mobile No', 'trim|required');

				  $this->session->set_userdata('username', trim($this->input->post('username')));		
				  $this->session->set_userdata('mobile_no', trim($this->input->post('mobile_no')));	
				  if($this->form_validation->run() == TRUE){	   
					$username = $this->input->post('username');
					$mobile_no = $this->input->post('mobile_no');
					$password = $this->input->post('password');
					$oldpassword = $this->input->post('oldpassword');
					$newPassword = ($password) ? md5($password) : $oldpassword;
					$newprofileArr = array(
					'username'=>$username,
					'mobile_no'=>$mobile_no,
					'password'=>$newPassword,
					'modify'=>date('Y-m-d H:i:s'));
					$this->User_model->updateProfile($newprofileArr);
					redirect(base_url('user/dashboard'));
				}else{ 
				   $data['userId'] =$this->input->post('userid');
				   $this->middle = 'Admin/User/addpassword'; 
				   $this->layout($data);
			    }
			   } else {
				 redirect(base_url());
			 }
		   }
		
	}