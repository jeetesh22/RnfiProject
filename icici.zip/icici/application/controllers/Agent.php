	<?php
		class Agent extends MY_Controller {
			public function __construct(){
			parent::__construct();
			$this->load->database();
			$this->load->model('Agent_model');
			date_default_timezone_set('Asia/Kolkata');
			$this->loggedInArr = $this->session->userdata('logged_in');
		 }
		 
		   
		   public function add(){
			   if(!empty($this->session->userdata('logged_in'))){
				   $result = $this->Agent_model->saveRcodeCsv();
				   if($result["success"]="success" && $result["crane_features"]==1){
					$this->session->set_flashdata("message","Agent is successfully added!");
					redirect(base_url('user/dashboard'));
			     }
			   } else {
				 redirect(base_url());
			   }
		   }
		   
		    public function index(){
				  if (!empty($this->session->userdata('logged_in'))){
				    $start = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
					$limit = 20;
					$search_str = $this->input->get("search_str");
	                $this->middle = 'Admin/Agent/index'; 
	                $data['agents'] = $this->Agent_model->getvalue_agent_master($limit,$start,$search_str);
	            
					$config['base_url'] = base_url()."agent/index";
					$config['total_rows'] = $this->Agent_model->count_getvalue_agent_master($search_str);
					$config['per_page'] = $limit;
					if(!empty($search_str))
					{
					  	$config['suffix'] = '&search_str=' . $search_str;						
					}
					
					$config["uri_segment"] = 3;
					$this->pagination->initialize($config);
					
					$data["config"] = $config;
					$this->layout($data);              	
			    } else {
					 redirect(base_url());
			   }
		   }
		   
		  public function unlockagent($agent=NULL){
			  if(!empty($this->session->userdata('logged_in'))){
				   $id= decrypt_method($agent);
				   $result = $this->Agent_model->unLockAgent($id);
			   } else {
				 redirect(base_url());
			   }
		  } 
		  
		  public function lockagent($agent=NULL){
			  if(!empty($this->session->userdata('logged_in'))){
				   $id= decrypt_method($agent);
				   $result = $this->Agent_model->LockAgent($id);
			   } else {
				 redirect(base_url());
			   }
		   }

		 public function edit($agent=NULL){
			  if(!empty($this->session->userdata('logged_in'))){
				   $id= decrypt_method($agent);
				   $data["agent"] = $this->Agent_model->getSingleAgents($id);
				   $this->middle = 'Admin/Agent/edit'; 
				   $this->layout($data);    
			   } else {
				 redirect(base_url());
			   }
		  } 
		  
		  public function update(){ 
			  if(!empty($this->session->userdata('logged_in'))){
				   $id= decrypt_method($this->input->post("agent_id"));
				   $rcode = $this->input->post("rcode");
				   $data["agent"] = $this->Agent_model->updateAgent($id,$rcode); 
			   } else {
				 redirect(base_url());
			   }
		  }

		  public function delete($agent=NULL){
			  if(!empty($this->session->userdata('logged_in'))){
				   $id= decrypt_method($agent);
				   $data["agent"] = $this->Agent_model->removeAgent($id);
			   } else {
				 redirect(base_url());
			   }
		  }

		public function addremarks(){
		  if(!empty($this->session->userdata('logged_in'))){
			   $data["allAgent"] = $this->Agent_model->getAllAgents();
			  // print_r($data["allAgent"]);die;
			   $this->middle = 'Admin/Agent/addremarks'; 
			   $this->layout($data);    
			} else {
			 redirect(base_url());
		  }
		}

		public function saveremarks(){
			if(!empty($this->session->userdata('logged_in'))){
				 $this->form_validation->set_rules('agent_id', 'Agent', 'required');
				 $this->form_validation->set_rules('editor_contents', 'Remarks', 'trim|required|xss_clean');
				 
				 $this->session->set_userdata('name', trim($this->input->post('name')));		
				 if($this->form_validation->run() == TRUE){	   
					$agent_id = $this->input->post('agent_id');
					$editor_contents = $this->input->post('editor_contents');
					$saveRemarks = array(
					'agent_id'=>$agent_id,
					'user_id'=>$this->loggedInArr["id"],
					'remark'=>$editor_contents,
					'created_at'=>date('Y-m-d H:i:s'));
					$this->Agent_model->saveRemarks($saveRemarks);
					redirect(base_url('bank/index'));
				}else{
				  $data["allAgent"] = $this->Agent_model->getAllAgents();					
				  $this->middle = 'Admin/Agent/addremarks';
				  $this->layout($data);
			    }
			} else {
			 redirect(base_url());
		  }
		}	
		
		public function listremarks(){
			if (!empty($this->session->userdata('logged_in'))){
				    $start = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
					$limit = 20;
					$search_str = $this->input->get("search_str");
	                $this->middle = 'Admin/Agent/listremarks'; 
	                $data['allRemarks'] = $this->Agent_model->getvalue_remark_master($limit,$start,$search_str);
	            
					$config['base_url'] = base_url()."agent/listremarks";
					$config['total_rows'] = $this->Agent_model->count_getvalue_remark_master($search_str);
					$config['per_page'] = $limit;
					if(!empty($search_str))
					{
					  	$config['suffix'] = '&search_str=' . $search_str;						
					}
					$config["uri_segment"] = 3;
					$this->pagination->initialize($config);
					
					$data["config"] = $config;
					$this->layout($data);              	
			    } else {
					 redirect(base_url());
			   }
		}
		
		public function removeremarks($id=NULL){
			if(!empty($this->session->userdata('logged_in'))){
				   $id= decrypt_method($id);
				   $data["agent"] = $this->Agent_model->removeRemarks($id);
			   } else {
				 redirect(base_url());
			   }
		}
		
		public function editremark($id=NULL){
			if(!empty($this->session->userdata('logged_in'))){
				  $id= decrypt_method($id);
				  $data["allAgent"] = $this->Agent_model->getAllAgents();
				  $data["tRemark"] = $this->Agent_model->getSingleRemark($id);
				  $this->middle = 'Admin/Agent/editremark';
				  $this->layout($data);
			   } else {
				 redirect(base_url());
			   }
		}
		
		public function updateremark(){
			if(!empty($this->session->userdata('logged_in'))){
				 $this->form_validation->set_rules('agent_id', 'Agent', 'required');
				 $this->form_validation->set_rules('editor_contents', 'Remarks', 'trim|required|xss_clean');
				 
				 $this->session->set_userdata('name', trim($this->input->post('name')));		
				 if($this->form_validation->run() == TRUE){	   
					$remark_id = decrypt_method($this->input->post('remark_id'));
					$agent_id = $this->input->post('agent_id');
					$editor_contents = $this->input->post('editor_contents');
					$updateRemarks = array(
					'agent_id'=>$agent_id,
					'user_id'=>$this->loggedInArr["id"],
					'remark'=>$editor_contents,
					'modify_at'=>date('Y-m-d H:i:s'));
					$this->Agent_model->updateRemarks($updateRemarks,$remark_id);
					redirect(base_url('agent/listremarks'));
				}else{
				  $remark_id = $this->input->post('remark_id');
				  redirect(base_url('agent/editremark/'.$remark_id));
			    }
			} else {
			 redirect(base_url());
		  }
		}
			
}