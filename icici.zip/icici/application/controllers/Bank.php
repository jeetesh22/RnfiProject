	<?php
		class Bank extends MY_Controller {
			public function __construct(){
			parent::__construct();
			$this->load->database();
			$this->load->model('Bank_model');
			$this->load->model('User_model');
			date_default_timezone_set('Asia/Kolkata');
			$this->load->library("Verification");
			$this->otp = rand(100000,999999);
		 }
		 
		   public function add(){
			   if(!empty($this->session->userdata('logged_in'))){
				  $this->middle = 'Admin/Bank/add'; 
				  $this->layout();
				} else {
				 redirect(base_url());
			   }
		    }
			
			public function save(){
				if(!empty($this->session->userdata('logged_in'))){
				 $this->form_validation->set_rules('name', 'Bank Name', 'trim|required|xss_clean|is_unique[banks.name]');
				 
				 $this->session->set_userdata('name', trim($this->input->post('name')));		
				 if($this->form_validation->run() == TRUE){	   
					$name = $this->input->post('name');
					$savebankArr = array(
					'name'=>$name,
					'created_at'=>date('Y-m-d H:i:s'));
					$this->Bank_model->saveBankData($savebankArr);
					redirect(base_url('bank/index'));
				}else{ 
				  $this->middle = 'Admin/Bank/add'; 
				  $this->layout();
			    }
				} else {
				 redirect(base_url());
			   }				
			}
		   
		   public function index(){
			   if (!empty($this->session->userdata('logged_in'))){
				    $start = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
					$limit = 15;
					$search_str = $this->input->get("search_str");
					$from_date = $this->input->get("from_date");
					$to_date = $this->input->get("to_date");           	
	           	
	                $this->middle = 'Admin/Bank/index'; 
	                $data['allBanks'] = $this->Bank_model->getvalue_bank_master($limit,$start,$search_str,$from_date,$to_date);
	            
					$config['base_url'] = base_url()."bank/index";
					$config['total_rows'] = $this->Bank_model->count_getvalue_bank_master($search_str,$from_date,$to_date);
					$config['per_page'] = $limit;
					if(!empty($from_date) && !empty($to_date) && !empty($search_str))
					{
					  	$config['suffix'] = '?from_date=' . $from_date . '&to_date=' . $to_date . '&search_str=' . $search_str;						
					}
					
					$config["uri_segment"] = 3;
					$this->pagination->initialize($config);
					
					$data["config"] = $config;
					$this->layout($data);              	
					} else {
					 redirect(base_url());
				   }
		    }
		   
		   public function deActivebank(){
			 if (!empty($this->session->userdata('logged_in'))){  
			 if($this->input->post()){
				 $id = $this->input->post('id');
				 $status = $this->input->post('status');
				 $result = $this->Bank_model->changeBankStatus($id,$status);
				 echo $result;
			 }
			 } else {
				 redirect(base_url());
			   }
		   }
		   
		    public function Activebank(){
			 if (!empty($this->session->userdata('logged_in'))){  
			 if($this->input->post()){
				 $id = $this->input->post('id');
				 $status = $this->input->post('status');
				 $result = $this->Bank_model->changeBankStatus($id,$status);
				 echo $result;
			 }
			 } else {
				 redirect(base_url());
			   }
		   }
		   
		  public function removeBank(){
			 if (!empty($this->session->userdata('logged_in'))){  
			 if($this->input->post()){
				 $id = $this->input->post('id');
				 $result = $this->Bank_model->deleteBank($id);
				 echo $result;
			 }
			 } else {
				 redirect(base_url());
			   }
		   }
		   
		  public function edit($id=NULL){
			 if (!empty($this->session->userdata('logged_in'))){  
			 if($id){
				$data['bankArr'] = $this->Bank_model->getBank(decrypt_method($id));
				$data['bankId'] =decrypt_method($id) ;
				$this->middle = 'Admin/Bank/edit'; 
				$this->layout($data);
			  }
			 } else {
				 redirect(base_url());
			   }
		   }
		   
		   public function update(){
			 if(!empty($this->session->userdata('logged_in'))){
				 $this->form_validation->set_rules('name', 'Bank Name', 'trim|required|xss_clean');
				 
				 $this->session->set_userdata('name', trim($this->input->post('name')));		
				 if($this->form_validation->run() == TRUE){	 
					$bank_id = $this->input->post('bank_id');
					$name = $this->input->post('name');
					
					$bankArr = array(
					'name'=>$name,
					'modify_at'=>date('Y-m-d H:i:s'));
					$this->Bank_model->updateBankData($bankArr,$bank_id);
					redirect(base_url('bank/index'));
				}else{ 
				  redirect(base_url('bank/edit/'.$this->input->post('bank_id')));
			    }
				} else {
				 redirect(base_url());
			   }				
		   }
		   
		 public function addbankdetail(){
			if(!empty($this->session->userdata('logged_in'))){
				  $data['allBank'] = $this->Bank_model->getAllBank();
				  $this->middle = 'Admin/Bank/adddetail'; 
				  $this->layout($data);
				} else {
				 redirect(base_url());
			   } 
		 }

		public function savedetails(){
			if(!empty($this->session->userdata('logged_in'))){
				 $this->form_validation->set_rules('bank_id', 'Select Bank', 'trim|required|xss_clean');
				 $this->form_validation->set_rules('username', 'User Name', 'trim|required|xss_clean');
				 $this->form_validation->set_rules('corporate_id', 'Corporate Id', 'trim|required|xss_clean|is_unique[bank_details.corporate_id]');
				 $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
				 $this->form_validation->set_rules('mobile_no', 'Mobile No', 'trim|required|xss_clean');
				 $this->form_validation->set_rules('transaction_password', 'Transaction Password', 'trim|required|xss_clean');
				 
				 $this->session->set_userdata('bank_id', trim($this->input->post('bank_id')));		
				 $this->session->set_userdata('username', trim($this->input->post('username')));
				 $this->session->set_userdata('corporate_id', trim($this->input->post('corporate_id')));
				 $this->session->set_userdata('password', trim($this->input->post('password')));
				 $this->session->set_userdata('mobile_no', trim($this->input->post('mobile_no')));	
				 $this->session->set_userdata('transaction_password', trim($this->input->post('transaction_password')));

				 if($this->form_validation->run() == TRUE){				 
					$bank_id = $this->input->post('bank_id');
					$username = $this->verification->encrypted_string($this->input->post('username'));
					$corporate_id = $this->verification->encrypted_string($this->input->post('corporate_id'));
					$password = $this->verification->encrypted_string($this->input->post('password'));
					$transaction_password = $this->verification->encrypted_string($this->input->post('transaction_password'));
					$mobile_no = $this->verification->encrypted_string($this->input->post('mobile_no'));
					
					$savebankDetalArr 		= array(
					'bank_id'				=> $bank_id,
					'username'				=> $username,
					'corporate_id'			=> $corporate_id,
					'password'				=> $password,
					'transaction_password'	=> $transaction_password,
					'mobile_no'				=> $mobile_no,
					'created_at'			=> date('Y-m-d H:i:s'));
					$this->Bank_model->saveBankDetailData($savebankDetalArr);
					redirect(base_url('bank/index'));
				}else{
				  redirect(base_url('bank/addbankdetail'));
			    }
				} else {
				 redirect(base_url());
			   }				
		}
		
		public function indexbankdetail(){
			if (!empty($this->session->userdata('logged_in'))){
				    $start = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
					$limit = 20;
					$search_str = $this->input->get("search_str");
					$from_date = $this->input->get("from_date");
					$to_date = $this->input->get("to_date");           	
	           	
	                $this->middle = 'Admin/Bank/indexbankdetail'; 
	                $data['allBankDetails'] = $this->Bank_model->getvalue_bankdetails_master($limit,$start,$search_str,$from_date,$to_date);
					$data['allBank'] = $this->Bank_model->getAllBank();
					$config['base_url'] = base_url()."bank/index";
					$config['total_rows'] = $this->Bank_model->count_getvalue_bankdetails_master($search_str,$from_date,$to_date);
					$config['per_page'] = $limit;
					if(!empty($from_date) && !empty($to_date) && !empty($search_str))
					{
					  	$config['suffix'] = '?from_date=' . $from_date . '&to_date=' . $to_date . '&search_str=' . $search_str;						
					}
					$config["uri_segment"] = 3;
					$this->pagination->initialize($config);
					
					$data["config"] = $config;
					$this->layout($data);              	
			   } else {
					 redirect(base_url());
			 }
		 }
		
		public function removeBankDetails(){
			if (!empty($this->session->userdata('logged_in'))){  
			if($this->input->post()){
				 $id = $this->input->post('id');
				 $result = $this->Bank_model->deleteBankDetails($id);
				 echo $result;
			 }
			 } else {
				 redirect(base_url());
			 }
		}
		
	   public function showBankDPassword(){
		   if (!empty($this->session->userdata('logged_in'))){  
		   if($this->input->post()){
			  $id = $this->input->post('id');
			  if($id){
				//$data["otp"] =  $this->verification->getotp();
				$data["otp"] = '445566' ;//rand(100000,999999);
				$otp_array = array(
				'mobile_no' =>'',
				'send_otp' =>$data["otp"] );
	            $this->session->set_userdata('otp_array', $otp_array);
			  }
			  $data["id"] = $id;
			  $data['pass'] = $this->Bank_model->getBankDPassword($id);
			  $data["error_messege"] = "";
			  $this->load->view('Admin/Bank/ajax_password',$data);
			}
			} else {
				 redirect(base_url());
			 }
	     }

		 public function checkOtpPassword(){
		   if (!empty($this->session->userdata('logged_in'))){  
		   if($this->input->post()){
			  $id = $this->input->post('id');
			  $inputOtp = $this->input->post('inputOtp');
			  $sendOtp = $this->session->userdata('otp_array');
			  if($sendOtp["send_otp"]==$inputOtp){
			    $data['pass']= $this->Bank_model->getBankDPassword($id);
				$this->load->view('Admin/Bank/ajax_password_show',$data);
			  }else{
			  $data["id"] = $id  ;
			  $data['error_messege'] = "Otp is not valid,please fill right otp!";
			  $this->load->view('Admin/Bank/ajax_password',$data);
			  }
			 }
			} else {
				 redirect(base_url());
			 }
	    }
		
		public function  assignbank(){
			if (!empty($this->session->userdata('logged_in'))){  
			$crateSession =  $this->session->userdata('logged_in');
			$data['id'] = $crateSession['id'];
		    $data["getAssignBank"] = $this->User_model->getAssignBanks($data['id']);
		    if(!empty($data["getAssignBank"])){
		    	$bankDetails = $this->Bank_model->getSingleBankDetails(array_column($data["getAssignBank"],'bankid'));
			    $out=array();
			    foreach($bankDetails as $x){
				  $out[$x['bank_id']]['details'][]=array('id'=>$x['id'],'username'=>$x['username'],
				  'corporate_id'=>$x['corporate_id'],'mobile_no'=>$x['mobile_no'],'bank_id'=>$x['bank_id']);
				}
			    $data["bankDetails"] = $out;
		    }
		    $this->middle = 'Admin/User/assignbank'; 
		    $this->layout($data);
		    } else {
			 redirect(base_url());
		   }
		}
		
}