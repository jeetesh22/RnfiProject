<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Bank extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->database();
        header('Content-Type: application/json');
        $this->load->model("api/login/Login_model");
        $this->load->model("api/bank/Bank_model");
		$this->load->library("Verification");
		$this->response  =   array();
		$this->key = $this->verification->secure_key_jwt();
    }
	
	public function index(){
		 $this->form_validation->set_rules('token', 'Token', 'trim|required|xss_clean');
		 if($this->form_validation->run() == TRUE){	  
		 	$token = $this->input->post('token');
		 	$validToken = $this->Login_model->checkvalidToken($token);
		 	if(!empty($validToken)){
		 		$getBanks = $this->Bank_model->getAssignBanks($validToken->id);
		 		if($getBanks){ 
		 		$this->response['status']       =  1; 
		        $this->response['statuscode']   =  200;
		        $this->response['message']      =  "Banks list"; 
		        $this->response['data']			=  $getBanks;
		 	}else{
		 		$this->response['status']      =  0; 
               $this->response['statuscode']   =  406; 
               $this->response['message']  	   =  "Banks is not assign."; 
		 	}
		 	}else{
		 	   $this->response['status']       =  0; 
               $this->response['statuscode']   =  406; 
               $this->response['message']  	   =  "Invalid user detail(token)."; 
		 	}
		}else{
			$this->form_validation->set_error_delimiters('', '');
            $this->response['status']       =   0;
            $this->response['statuscode'] 	=   400;
            $this->response['message']  	=   validation_errors();
		}
		 echo json_encode($this->response,JSON_UNESCAPED_SLASHES);
	}

	public function bankdetails(){
		 $this->form_validation->set_rules('token', 'Token', 'trim|required|xss_clean');
		 $this->form_validation->set_rules('bankid', 'Bank Id', 'trim|required|xss_clean');
		 if($this->form_validation->run() == TRUE){
		 	$token = $this->input->post('token');
		 	$validToken = $this->Login_model->checkvalidToken($token);
		 	if(!empty($validToken)){ 
		 		$bankid = $this->input->post("bankid");
		 		$getBanks = $this->Bank_model->getBankDetails($bankid);
		 		if($getBanks){ 
		 		$this->response['status']       	=  1; 
		        $this->response['statuscode']   	=  200;
		        $this->response['message']      	=  "Banks list"; 
				$this->response['data']				=  array("username" => $this->verification->decrypted_string($getBanks->username),
														 "corporate_id" => $this->verification->decrypted_string($getBanks->corporate_id),
														 "password" => $this->verification->decrypted_string($getBanks->password),
														 "transaction_password" => $this->verification->decrypted_string($getBanks->transaction_password),
														 "mobile_no" => $this->verification->decrypted_string($getBanks->mobile_no));
		 	}else{
		 	   $this->response['status']       =  0; 
               $this->response['statuscode']   =  406; 
               $this->response['message']  	   =  "Banks is not assign."; 
		 	}
		 	}else{
		 	   $this->response['status']       =  0; 
               $this->response['statuscode']   =  406; 
               $this->response['message']  	   =  "Invalid user detail(token)."; 
		 	}
		}else{
			$this->form_validation->set_error_delimiters('', '');
            $this->response['status']       =   0;
            $this->response['statuscode'] 	=   400;
            $this->response['message']  	=   validation_errors();
		}
		 echo json_encode($this->response,JSON_UNESCAPED_SLASHES);
	}
}