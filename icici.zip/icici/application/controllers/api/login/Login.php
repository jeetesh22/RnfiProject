<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->database();
        header('Content-Type: application/json');
       // $this->load->model('user_model');
        $this->load->model("api/login/Login_model");
		$this->load->library("Verification");
		$this->response  =   array();
		$this->key = $this->verification->secure_key_jwt();
    }
	
	public function index(){
		 $this->form_validation->set_rules('password', 'User Name', 'trim|required|xss_clean');
		 $this->form_validation->set_rules('emailid', 'Email Id', 'trim|required|valid_email|xss_clean');
		 $this->form_validation->set_rules('deviceid', 'Device Id', 'trim|required|xss_clean');
		  
		 if($this->form_validation->run() == TRUE){	  
		 	$deviceid = $this->input->post('deviceid');
		 	$password = md5($this->input->post('password'));
		 	$emailid = $this->input->post('emailid'); 
		 	$loginData = $this->Login_model->CheckUserDetail($emailid,$password);
		 	if(!empty($loginData)){
		 		$jwtToken = jwt::encode(array('id'=> $loginData->id,
						 					"username" 	=> $loginData->username,
						 					"myip" 		=> $this->input->ip_address()), 
						 					 $this->key);
		 	$userData = array("deviceid" =>$deviceid,"token"=>$jwtToken,"modify"=>date('Y-m-d H:i:s'));
		 	$result = $this->Login_model->updateUserData($userData,$loginData->id);
		 	if($result){ 
		 		$this->response['status']       	=  1; 
		        $this->response['statuscode']   	=  200;
		        $this->response['message']      	=  "successfully login"; 
		        $this->response['token']   			=  $jwtToken;
		        $this->response['data']				=  array("username" => $loginData->username,
		        											 "mobileno" => $loginData->mobileno);
		 	}else{
		 	   $this->response['status']       =  0; 
               $this->response['statuscode']   =  406; 
               $this->response['message']  	   =  "Invalid user db detail."; 
		 	}
		 	}else{
		 	   $this->response['status']       = 0; 
               $this->response['statuscode']   = 406; 
               $this->response['message']  	   = "Invalid user detail."; 
		 	}
		}else{
			$this->form_validation->set_error_delimiters('', '');
            $this->response['status']       =  0;
            $this->response['statuscode'] 	=  400;
            $this->response['message']  	=  validation_errors();
		}
		 echo json_encode($this->response,JSON_UNESCAPED_SLASHES);
	}

	public function sendotp(){
		 $this->form_validation->set_rules('token', 'Token', 'trim|required|xss_clean');
		 $this->form_validation->set_rules('deviceid', 'Token', 'trim|required|xss_clean');
		 if($this->form_validation->run() == TRUE){	  
		 	$token = $this->input->post('token');
		 	$deviceid = $this->input->post('deviceid');
		 	$validToken = $this->Login_model->checkvalidToken($token);
		 	if(!empty($validToken)){
		 		$validDevice = $this->Login_model->checkvalidDevice($deviceid);
		 		if(!empty($validDevice)){ 
		 			$getOtp = $this->verification->sendOtp($validToken->mobileno,$isAdmin=NULL);
		 			if($getOtp){  
		 				$saveOtp = $this->Login_model->saveOtp($getOtp,$validDevice->id);
		 				if($saveOtp){ 
				 		$this->response['status']       	=  1; 
				        $this->response['statuscode']   	=  200;
				        $this->response['message']      	=  "Send otp"; 
				        $this->response['data']				=   array("otp"=>"445566","mobileno"=>$validToken->mobileno);
				    }else{
				       $this->response['status']       =  0; 
		               $this->response['statuscode']   =  406; 
		               $this->response['message']  	   =  "Otp is not send! please send again otp."; 
				    }
				 	}else{
				 	   $this->response['status']       =  0; 
		               $this->response['statuscode']   =  406; 
		               $this->response['message']  	   =  "Otp is not send! please send again otp."; 
				 	}
		 		   }else{
			 		  $this->response['status']       =  0; 
			          $this->response['statuscode']   =  406; 
			          $this->response['message']  	  =  "Invalid device id.";
		 	}
		 	}else{
		 	   $this->response['status']       =  0; 
               $this->response['statuscode']   =  406; 
               $this->response['message']  	   =  "Invalid user detail(token)."; 
		 	}
		}else{
			$this->form_validation->set_error_delimiters('', '');
            $this->response['status']       =   0;
            $this->response['statuscode'] 	=   400;
            $this->response['message']  	=   validation_errors();
		}
		 echo json_encode($this->response,JSON_UNESCAPED_SLASHES);
    }

    public function checkvalidotp(){
		 $this->form_validation->set_rules('token', 'Token', 'trim|required|xss_clean');
		 $this->form_validation->set_rules('deviceid', 'Token', 'trim|required|xss_clean');
		 $this->form_validation->set_rules('mobileno', 'Mobile No', 'trim|required|xss_clean');
		 $this->form_validation->set_rules('otp', 'Otp', 'trim|required|xss_clean');
		 if($this->form_validation->run() == TRUE){	  
		 	$token = $this->input->post('token');
		 	$deviceid = $this->input->post('deviceid');
		 	$mobileno = $this->input->post('mobileno');
		 	$otp = $this->input->post('otp');
		 	$validToken = $this->Login_model->checkvalidToken($token);
		 	if(!empty($validToken)){
		 		$validDevice = $this->Login_model->checkvalidDevice($deviceid);
		 		if(!empty($validDevice)){ 
		 			$mobileno = $this->Login_model->checkvalidmobileno($mobileno);
		 			if($mobileno){
		 			 $getOtp = $this->Login_model->checkOtp($mobileno,$otp,$validDevice->id);
		 			if($getOtp){ 
				 		$this->response['status']       = 1; 
				        $this->response['statuscode']   = 200;
				        $this->response['message']      = "Send otp"; 
				        $this->response['data']			=  array("otp"=>"445566","mobileno"=>$validToken->mobileno);
				 	}else{
				 	   $this->response['status']       = 0; 
		               $this->response['statuscode']   = 406; 
		               $this->response['message']  	   = "Invalid otp! please fill right otp."; 
				 	}
				 }else{
			 	    $this->response['status']       = 0; 
	                $this->response['statuscode']   = 406; 
	                $this->response['message']  	= "Invalid mobileno! please send right mobileno."; 
				 }
		 		 }else{
		 		  $this->response['status']       = 0; 
		          $this->response['statuscode']   = 406; 
		          $this->response['message']  	  = "Invalid device id.";
		 	}
		 	}else{
		 	   $this->response['status']       = 0; 
               $this->response['statuscode']   = 406; 
               $this->response['message']  	   = "Invalid user detail(token)."; 
		 	}
		}else{
			$this->form_validation->set_error_delimiters('', '');
            $this->response['status']       =  0;
            $this->response['statuscode'] 	=  400;
            $this->response['message']  	=  validation_errors();
		}
		 echo json_encode($this->response,JSON_UNESCAPED_SLASHES);
    }
}