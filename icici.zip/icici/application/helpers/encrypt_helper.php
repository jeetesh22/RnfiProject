<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	$CI =& get_instance();
if ( ! function_exists('encrypt_method'))
{
    function encrypt_method($var = '')
    {		
			$CI =& get_instance();
            return $CI->encrypt->encode($var);
    }   
}