<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	$CI =& get_instance();
if ( ! function_exists('decrypt_method'))
{
    function decrypt_method($var = '')
    {		
			$CI =& get_instance();
            return $CI->encrypt->decode($var);
    }   
}