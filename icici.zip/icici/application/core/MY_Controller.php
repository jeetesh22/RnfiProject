<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class MY_Controller extends CI_Controller 
 { 
   var $template  = array();
   var $data = array();  
   public function layout($layout=false) 
   {
     $this->template['header']   = $this->load->view('Admin/Elements/header', $this->data, true);
     $this->template['left']   = $this->load->view('Admin/Elements/sidebar', $this->data, true);
     $this->template['middle'] = $this->load->view($this->middle, $layout, true);
     $this->template['footer'] = $this->load->view('Admin/Elements/footer', $this->data, true);
     $this->load->view('Admin/User/index', $this->template);
   }
 }