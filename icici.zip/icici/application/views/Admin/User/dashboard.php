		<div class="main-content">
			<div class="main-content-inner">
				<div class="breadcrumbs ace-save-state" id="breadcrumbs">
					<ul class="breadcrumb">
						<li>
							<i class="ace-icon fa fa-home home-icon"></i>
							<a href="<?php echo base_url();?>user/dashboard">Home</a>
						</li>
						<li class="active">Dashboard</li>
					</ul>
				</div>

				<div class="page-content">
				 <?php if($this->session->flashdata('message')) { ?>
					  <div class="alert alert-success alert-dismissible">
					  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					  <?php echo $this->session->flashdata('message') ?>; 
					  </div>
				<?php } ?>
					<div class="page-header">
						<h1>
							Dashboard
							<small>
								<i class="ace-icon fa fa-angle-double-right"></i>
								admin panel
							</small>
						</h1>
					</div><!-- /.page-header -->
				</div>
				
			</div>
		</div>