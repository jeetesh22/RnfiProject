<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="<?php echo base_url();?>user/dashboard">Home</a>
							</li>

							<li>
								<a href="#">Assign Bank Users</a>
							</li>
							<li class="active">Users</li>
						</ul><!-- /.breadcrumb -->
					</div>

					<div class="page-content">
					<?php if($this->session->flashdata('message')) { ?>
					  <div class="alert alert-success alert-dismissible">
					  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					   <?php echo $this->session->flashdata('message') ?>; 
					  </div>
					 <?php } ?>
					 <div id="usermessage"></div>
							<div class="row">
								<div class="col-xs-12">
									<!-- PAGE CONTENT BEGINS -->
									<div class="row">
										<div class="col-xs-12">
											<table id="simple-table" class="table  table-bordered table-hover">
											<thead>
												<tr>
													<th>S.No</th>
													<th>Bank Name</th>
													<th>Assign Users</th>
												</tr>
											</thead>
											<tbody>
											<?php if(!empty($banks)){
												foreach($banks as $i=>$bank){?>
												<tr>
												<td><?php echo $i+1;?></td>
												<td><?php echo $bank["name"];?></td>
												<td>
												<?php foreach($allUsers as $j=>$user){
												// if($j==5){
												// 	echo "<br>";
												// }													
												$assignUser = $this->Bank_model->assignUserBank($user["id"],$bank["id"]) ?>
												<label class="inline">
												<input type="checkbox" class="ace assign_user" name="assign_user" value="<?php echo $user["id"];?>" id="assign_user" attr-id="<?php echo $bank["id"];?>" <?php echo ($assignUser) ? 'checked="true"' : '' ;?>>
												<span class="lbl"></span>
												</label>
												<?php echo $user["username"]." ( <b>".$user["mobileno"]." </b>)";?><?php } ?>
												</td>
												</tr>
											<?php }}else{ ?>
											<tr><td colspan="4">Records Not Found!</td></tr>
											<?php } ?>		
											</tbody>
										</table>
									</div><!-- /.span -->
									     
								</div><!-- /.row -->
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div>