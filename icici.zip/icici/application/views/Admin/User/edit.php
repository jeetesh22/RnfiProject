	<div class="main-content">
		<div class="main-content-inner">
			<div class="breadcrumbs ace-save-state" id="breadcrumbs">
				<ul class="breadcrumb">
					<li>
						<i class="ace-icon fa fa-home home-icon"></i>
						<a href="<?php echo base_url();?>user/dashboard">Home</a>
					</li>

					<li>
						<a href="#">User</a>
					</li>
					<li class="active">Edit User</li>
				</ul><!-- /.breadcrumb -->
			</div>

			<div class="page-content">
				<div class="row">
					<div class="col-xs-12">
					<?php if(validation_errors()){?>
					  <div class="alert alert-danger alert-dismissible">
					  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					   <?php echo validation_errors(); ?>.
					  </div>
					<?php } ?>
						<!-- PAGE CONTENT BEGINS -->
						<form class="form-horizontal" action="<?php echo base_url();?>user/updateuser" method="post" enctype="multipart/form-data" id="adduser">
							<input type="hidden" name="userid" value="<?php echo $getUser['id']; ?>">
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">UserName</label>
								<div class="col-sm-9">
									<input type="text" name="username" id="username" placeholder="Username" class="col-xs-10 col-sm-8" value="<?php echo $getUser['username']; ?>" autocomplete="off">
								</div>
							</div>
							
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">EmailId</label>
								<div class="col-sm-9">
									<input type="text" name="emailid" id="emailid" placeholder="EmailId" class="col-xs-10 col-sm-8" value="<?php echo $getUser['emailid']; ?>" autocomplete="off">
								</div>
							</div>
							
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">MobileNo</label>
								<div class="col-sm-9">
									<input type="text" name="mobileno" id="mobileno" placeholder="MobileNo" class="col-xs-10 col-sm-8" value="<?php echo $getUser['mobileno']; ?>" autocomplete="off" >
								</div>
							</div>

							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Login Type</label>
								<div class="col-sm-9">
			                  <div class="radio">
			                    <label>
			                      <input type="radio" name="login_type" id="optionsRadios1" value="1" <?php if ($getUser['login_type'] == '1') echo 'checked="checked"'; ?> autocomplete="off">
			                      Bank Type
			                    </label>
			                  </div>

			                  <div class="radio">
			                    <label>
			                      <input type="radio" name="login_type" id="optionsRadios2" value="0" <?php if ($getUser['login_type'] == '0') echo 'checked="checked"'; ?> autocomplete="off">
			                     Transaction Type
			                    </label>
			                  </div>
			                  <label class="error" generated="true" for="login_type" style="display:none;"></label>
			                  </div>
			                </div>

							<div class="clearfix form-actions">
								<div class="col-md-offset-3 col-md-9">
									<button class="btn btn-info" type="submit">
										<i class="ace-icon fa fa-check bigger-110"></i>
										Submit
									</button>
									&nbsp; &nbsp; &nbsp;
									<button class="btn btn-danger" type="reset" onClick="window.location.href = '<?php echo base_url(); ?>user/listuser';return false;">
										<i class="ace-icon fa fa-remove bigger-110"></i>
										Cancel
									</button>
								</div>
							  </div>
							</form>
						</div><!-- /.page-content -->
					</div>
				</div>	
			</div>	
		</div>	