					<ul class="nav nav-list" style="top: 0px;">
					<li class="active">
						<a href="<?php echo base_url();?>user/dashboard">
							<i class="menu-icon fa fa-tachometer"></i>
							<span class="menu-text"> Dashboard </span>
						</a>
						<b class="arrow"></b>
					</li>

					
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-list"></i>
							<span class="menu-text"> User Module </span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>

						<ul class="submenu nav-hide" style="display: none;">
							<li class="">
								<a href="<?php echo base_url('user/adduser'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									Add User
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="<?php echo base_url('user/listuser'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									List User
								</a>

								<b class="arrow"></b>
							</li>
						</ul>
					</li>
					
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-list"></i>
							<span class="menu-text"> Bank Module </span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>

						<ul class="submenu nav-hide" style="display: none;">
							<li class="">
								<a href="<?php echo base_url('bank/add'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									Add Bank
								</a>
								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="<?php echo base_url('bank/index'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									List Bank
								</a>
								<b class="arrow"></b>
							</li>
						</ul>
					</li>
					
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-list"></i>
							<span class="menu-text"> Details Res Bank</span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>

						<ul class="submenu nav-hide" style="display: none;">
							<li class="">
								<a href="<?php echo base_url('bank/addbankdetail'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									Add Details
								</a>
								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="<?php echo base_url('bank/indexbankdetail'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									List Details
								</a>
								<b class="arrow"></b>
							</li>
						</ul>
					</li>
					
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-list"></i>
							<span class="menu-text"> Share Login</span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>

						<ul class="submenu nav-hide" style="display: none;">
							<li class="">
								<a href="<?php echo base_url('user/sharelogin'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									Share Login Users
								</a>
								<b class="arrow"></b>
							</li>

							<!--<li class="">
								<a href="<?php echo base_url('user/sharelogin'); ?>">
									<i class="menu-icon fa fa-caret-right"></i>
									List Details
								</a>
								<b class="arrow"></b>
							</li>-->
						</ul>
					</li>
				</ul>