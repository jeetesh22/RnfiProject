			<div class="footer">
				<div class="footer-inner">
					<div class="footer-content">
						<span class="bigger-120">
							<span class="blue bolder">RNFI</span>
							Services &copy; 2020-2021
						</span>

						&nbsp; &nbsp;
					</div>
				</div>
			</div>
		</div>
		<script type="text/javascript" src="<?php echo base_url();?>assests/js/jquery-2.1.4.min.js"></script>
		 <script type="text/javascript">
			if('ontouchstart' in document.documentElement) document.write("<script src='<?php echo base_url();?>assests/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
		</script>
		 <script type="text/javascript" src="<?php echo base_url();?>assests/js/bootstrap.min.js"></script>
		 <script type="text/javascript" src="<?php echo base_url();?>assests/js/jquery-ui.min.js"></script>
		 <script type="text/javascript" src="<?php echo base_url();?>assests/js/chosen.jquery.min.js"></script>
		 <script type="text/javascript" src="<?php echo base_url();?>assests/js/ace.min.js"></script>
		 <script type="text/javascript" src="<?php echo base_url();?>assests/js/ace-elements.min.js"></script>
		 <script type="text/javascript" src="<?php echo base_url();?>assests/js/ace-extra.min.js"></script>
		  <!--editor js-->
		 <script type="text/javascript" src="<?php echo base_url();?>assests/js/editor.js"></script>
		 <script>
			$(document).ready(function() {
				$("#txtEditor").Editor();
			});
			
			$(document).submit(function(){
            $("#txtEditor").val($("#txtEditor").Editor("getText"));
        });
		</script>
		  <script type="text/javascript" src="<?php echo base_url();?>assests/js/jquery.validate.min.js"></script>
	</body>	
 </html>

 <script>
 /// Share login assign the bank of users
 $(document).ready(function(){
    $(".assign_user").click(function(e){
		var bankId = $(this).attr("attr-id");
		var assignUser = this.value;
		if(this.checked==true){
			var urL  = "<?php echo site_url();?>user/assignbankuser";
			var asIndex =0;
		}else{
			var urL  = "<?php echo site_url();?>user/unAssignbankuser";
			var asIndex =1;
		}
		 $.ajax({
         type: "POST",
         url:urL,
         data: {assignUser: assignUser,bankId:bankId},
         dataType: "text",  
         cache:false,
         success:function(data){
          if(data==1 && asIndex==1){
			 $("#usermessage").html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Users is successfully Unassign!</div>',reloadPage());
		  }else{
			 $("#usermessage").html('<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Users is successfully Assign!</div>',reloadPage());  
		  }
          }
		});
    });
	
 function reloadPage() {
	  setTimeout(function() {
		  location.reload(); 
		}, 1000);
   }	
});

 </script>
 
 <script type="text/javascript">
	jQuery(function($) {
		if(!ace.vars['touch']) {
			$('.chosen-select').chosen({allow_single_deselect:true}); 
			$(window)
			.off('resize.chosen')
			.on('resize.chosen', function() {
				$('.chosen-select').each(function() {
					 var $this = $(this);
					 $this.next().css({'width':'42%'});
				})
			}).trigger('resize.chosen');
		}

		$('#myModal').modal({
			show:false,
			backdrop:false,
			keyboard:false
		})
	});
</script>  
 <script type="text/javascript">
    jQuery(function($){
		 $( "#startdate" ).datepicker({ dateFormat: 'dd-mm-yy' });
		 $( "#enddate" ).datepicker({ dateFormat: 'dd-mm-yy'});
    });  


  $(document).ready(function(){
// add user validations
		$("#adduser").validate({
			rules :{
			username: {
			  required: true
			},
			mobileno: {
			  required:true,
			  minlength:10,
			  maxlength:11,
			  number: true
			},
			emailid: {
			  required:true,
			 email: true
			},
			login_type: {
			  required: true
			},
		},
		messages :{
			"username" : {
				required : 'Please enter username'
			},
			"mobileno" : {
				required : 'Please enter mobileno'
			},
			"emailid" : {
				required : 'Please enter emailid'
			},
			"login_type" : {
				required : 'Please choose login type'
			}
		   }
		  });
		  
// add password validations		
		$("#addpassword").validate({
			rules :{
			password: {
			  required: true,
			  minlength: 6,
			  maxlength: 20
			},
			cpassword: {
			  required:true,
			  equalTo: "#password",
			  minlength:6,
			  maxlength:20
			 
			}
		},
		messages :{
			"password" : {
				required : 'Please enter password'
			},
			"cpassword" : {
				required : 'Please enter confirm password'
			}
		   }
		  });
		  
// add Bank form validations		
		$("#addbank").validate({
			rules :{
			name: {
			  required: true,
			},
		},
		messages :{
			"name" : {
				required : 'Please enter bank name'
			}
		   }
		  });  
		  
// add Bank details form validations		
		$("#addbankdetails").validate({
			rules :{
			bank_id: {
			  required: true,
			},
			username: {
			  required:true,
			},
			corporate_id: {
			  required:true,
			},
			transaction_password: {
			  required:true,
			  minlength: 6,
			  maxlength: 20
			},
			mobile_no:{
			  required:true,
			  minlength:4,
			  maxlength:11,
			  number: true
			},
			password: {
			  required: true,
			  minlength: 6,
			  maxlength: 20
			},
		},
		messages :{
			"bank_id" : {
				required : 'Please select bank'
			},
			"username" : {
				required : 'Please enter username'
			},
			"corporate_id" : {
				required : 'Please enter corporate id'
			},
			"transaction_password" : {
				required : 'Please enter transaction password'
			},
			"password" : {
				required : 'Please enter password'
			},
			"mobile_no" : {
				required : 'Please enter mobile no'
			},
		   }
		  });  	  
		
 });
// user deactive
	function deActiveUser(userid){ 
     if (userid)
     {
         $.ajax({
         type: "POST",
         url: "<?php echo site_url();?>user/deActiveUser",
         data: {id: userid,status:'D'},
         dataType: "text",  
         cache:false,
         success:function(data){
           if(data==1){
			   $("#usermessage").html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Users is successfully DeActive!</div>',reloadPage());
		  }
          }
       });   
     }
  }	
 // user active 
  function ActiveUser(userid){
	 if (userid)
     {
         $.ajax({
         type: "POST",
         url: "<?php echo site_url();?>user/ActiveUser",
         data: {id: userid,status:'A'},
         dataType: "text",  
         cache:false,
         success:function(data){
          if(data==1){
			  $("#usermessage").html('<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Users is successfully Active!</div>',reloadPage());
		  }
          }
       });   
     }
  }
  
  function reloadPage() {
	  setTimeout(function() {
		  location.reload(); 
		}, 1000);
   }
   
// delete user   
  function ConfirmDelete(userid)
	 {
	  var x = confirm("Are you sure you want to delete this user?");
	  if (x){
		  $.ajax({
         type: "POST",
         url: "<?php echo site_url();?>user/removeUser",
         data: {id: userid},
         dataType: "text",  
         cache:false,
         success:function(data){
          if(data==1){
			  $("#usermessage").html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Users is successfully Delete!</div>',reloadPage());
		  }
          }
       });    
	  }
	}
	
	function ConfirmBankDelete(bankid){
	  var x = confirm("Are you sure you want to delete this bank?");
	  if (x){
		  $.ajax({
         type: "POST",
         url: "<?php echo site_url();?>bank/removeBank",
         data: {id: bankid},
         dataType: "text",  
         cache:false,
         success:function(data){
          if(data==1){
			  $("#bankmessage").html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Bank is successfully Delete!</div>',reloadPage());
		  }
          }
       });    
	  }
	}
	
	// bank deactive
	function deActivebank(bankid){ 
     if (bankid)
     {
         $.ajax({
         type: "POST",
         url: "<?php echo site_url();?>bank/deActiveBank",
         data: {id: bankid,status:'D'},
         dataType: "text",  
         cache:false,
         success:function(data){
           if(data==1){
			   $("#bankmessage").html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Bank is successfully DeActive!</div>',reloadPage());
		  }
          }
       });   
     }
  }	
 // bank active 
  function Activebank(bankid){
	 if (bankid)
     {
         $.ajax({
         type: "POST",
         url: "<?php echo site_url();?>bank/ActiveBank",
         data: {id: bankid,status:'A'},
         dataType: "text",  
         cache:false,
         success:function(data){
          if(data==1){
			  $("#bankmessage").html('<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Bank is successfully Active!</div>',reloadPage());
		  }
          }
       });   
     }
  }
  
  function ConfirmBankDetailDelete(bankid){
	  var x = confirm("Are you sure you want to delete this bank details?");
	  if (x){
		  $.ajax({
         type: "POST",
         url: "<?php echo site_url();?>bank/removeBankDetails",
         data: {id: bankid},
         dataType: "text",  
         cache:false,
         success:function(data){
          if(data==1){
			  $("#bankmessage").html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Bank is successfully Delete!</div>',reloadPage());
		  }
          }
       });    
	  }
  }
  
  function showBankDPassword(bankid){
	  if (bankid){
		 $.ajax({
         type: "POST",
         url: "<?php echo site_url();?>bank/showBankDPassword",
         data: {id: bankid},
         dataType: "text",  
         cache:false,
         success:function(data){
			  $(".show_password").html(data);
          }
       });    
	  }
  }  
  
  function copyToClipboard(element) {
	  var $temp = $("<input>");
	  $("body").append($temp);
	  $temp.val($(element).val()).select();
	  document.execCommand("copy");
	  $temp.remove();
}

function copyToTPClipboard(element) {  
	  var $temp = $("<input>");
	  $("body").append($temp);
	  $temp.val($(element).val()).select();
	  document.execCommand("copy");
	  $temp.remove();
}
 /// Check OTp  
  function checkOtp(id){
	  var inputOtp =  $("#passwordOtp").val();
	  if(inputOtp!=""){
		 $.ajax({
         type: "POST",
         url: "<?php echo site_url();?>bank/checkOtpPassword",
         data: {id: id,inputOtp:inputOtp},
         dataType: "text",  
         cache:false,
         success:function(data){
			$(".show_password").html(data);
          }
       });    
	  }else{
		 $("#inputvalue").html("Please enter otp").css("color","red");; 
	  }
  }
  
		
</script>