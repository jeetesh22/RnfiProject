<div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Fill OTP HERE!</h4>
        </div>
		
        <div class="modal-body">
		<div>
		  <div class="form-group">
			<label for="exampleInputEmail1">OTP</label>
			<input type="text" class="form-control" name="passwordOtp" id="passwordOtp" aria-describedby="" placeholder="Please Enter OTP!" autocomplete="off">
			<p class="show_password" id="inputvalue" style="color:red"><?php if($error_messege!=""){ echo $error_messege;}?></p>
		  </div>
		  <button type="submit" class="checkotp btn btn-primary" onclick="checkOtp('<?php echo $id;?>;')">Submit</button>
		  </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
	
	