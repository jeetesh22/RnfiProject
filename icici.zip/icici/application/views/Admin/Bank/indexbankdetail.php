<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="<?php echo base_url();?>bank/dashboard">Home</a>
							</li>

							<li>
								<a href="#">Bank Details</a>
							</li>
							<li class="active">List</li>
						</ul><!-- /.breadcrumb -->
					</div>

					<div class="page-content">
					<?php if($this->session->flashdata('message')) { ?>
					 <div class="alert alert-success alert-dismissible">
							  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							   <?php echo $this->session->flashdata('message') ?>; 
							  </div>
							<?php } ?>
							<div id="bankmessage"></div>
									<hr>
									<div class="row">
										<div class="col-xs-12">
											<!-- PAGE CONTENT BEGINS -->
										<div class="row">
											<div class="col-xs-12">
												<table id="simple-table" class="table  table-bordered table-hover">
													<thead>
														<tr>
															<th>S.No</th>
															<th>BankName</th>
															<th>Corporate Id</th>
															<th>UserName</th>
															<th>Mobile No</th>
															<th>Action</th>
														</tr>
													</thead>
													<tbody>
													<?php if(!empty($allBankDetails)){?>
													<?php foreach($allBankDetails as $i=>$bank){
														$bankName ="";
														foreach($allBank as $j=>$bList){
															if(md5($bList["id"]) == $bank['bank_id']){
																$bankName=  $bList["name"];
															}
														}?>
														<tr>
															<td><?php echo $i+1;?></a></td>
															<td><?php echo ($bank['name']);?></td>
															<td><?php echo ($bank['corporate_id']);?></td>
															<td><?php echo ($bank['username']);?></td>
															<td><?php echo ($bank['mobile_no']);?></td>
															<td>
																<div class="hidden-sm hidden-xs btn-group">
																<a href="#"><button class="btn btn-xs btn-warning" data-toggle="modal" data-target="#myModal" title="Show Password" onclick="showBankDPassword('<?php echo $bank['id'];?>')">
																		<i class="ace-icon fa fa-key bigger-120"></i>
																	</button></a>
																	<!--<a href="<?php echo base_url();?>bank/edit/<?php echo $bank["id"];?>"><button class="btn btn-xs btn-info" title="Edit bank">
																		<i class="ace-icon fa fa-pencil bigger-120"></i>
																	</button></a>-->

																	<a href="#"><button class="btn btn-xs btn-danger" title="Remove bank" onclick="ConfirmBankDetailDelete('<?php echo $bank['id'];?>')">
																		<i class="ace-icon fa fa-trash-o bigger-120"></i>
																	</button></a>

																	<!--<button class="btn btn-xs btn-warning">
																		<i class="ace-icon fa fa-flag bigger-120"></i>
																	</button>-->
																</div>
															</td>
														</tr>
													  <?php } ?>
													  <?php }else{?>
													  <tr><td colspan="8" align="center">No Data Found</td></tr>
													  <?php } ?>
													</tbody>
												</table>
											</div>
									<?php
									 if (count($allBankDetails) > 0) {
									  ?>
									  <div class="">
										  <?php
										  $current = $this->uri->segment(3) + 1;
										  $to = $this->uri->segment(3) + $config['per_page'];
										  $to = ( $to < $config['total_rows'] ? $to : $config['total_rows']);
										  $current = (isset($current) ? $current : 0 );
										  $to = (isset($to) ? $to : 0 );
										  echo 'Showing ' . $current . ' to ' . $to . ' out of ' . $config['total_rows'] . ' Entries.';
										  ?>
									  </div>
									  <div class="row pag">
										  <div class=" col-lg-12 center pagination"><?php echo $this->pagination->create_links(); ?></div>
									  </div>
									  <?php
								  } 
								  else 
								  {
                                  ?>
								 <div class="row">No Record Found</div>                                		
								    		<?php
										}
									?>                                  
										</div><!-- /.row -->
										<!-- PAGE CONTENT ENDS -->
									</div><!-- /.col -->
								</div><!-- /.row -->
							</div><!-- /.page-content -->
						</div>
				</div>
	
	
	<div class="modal fade show_password" id="myModal" role="dialog"></div>
