<div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Bank Details Password</h4>
        </div>
        <div class="modal-body" >
          <p >
            <label>Bank Password</label>
		        <input id="p1" type="text" name="opt" value="<?php echo $this->verification->decrypted_string($pass["password"]);?>" class="form-control" readonly onclick="copyToClipboard('#p1')" autocomplete="off"></p>

       <p >
            <label>Transaction  Password</label>
            <input id="p2" type="text" name="opt" value="<?php echo $this->verification->decrypted_string($pass["transaction_password"]);?>" class="form-control" readonly onclick="copyToTPClipboard('#p2')" autocomplete="off"></p>


        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>