	<div class="main-content">
		<div class="main-content-inner">
			<div class="breadcrumbs ace-save-state" id="breadcrumbs">
				<ul class="breadcrumb">
					<li>
						<i class="ace-icon fa fa-home home-icon"></i>
						<a href="<?php echo base_url();?>user/dashboard">Home</a>
					</li>

					<li>
						<a href="#">Bank</a>
					</li>
					<li class="active">Edit Bank</li>
				</ul><!-- /.breadcrumb -->
			</div>

			<div class="page-content">
				<div class="row">
					<div class="col-xs-12">
					<?php if(validation_errors()){?>
					  <div class="alert alert-danger alert-dismissible">
					  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					   <?php echo validation_errors(); ?>.
					  </div>
					<?php } ?>
						<!-- PAGE CONTENT BEGINS -->
						<form class="form-horizontal" action="<?php echo base_url();?>bank/update" method="post" enctype="multipart/form-data" id="addbank">
							<input type="hidden" name="bank_id" value="<?php echo $bankId;?>">
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Bank Name</label>
								<div class="col-sm-9">
								<?php $name = set_value('name') == false ? $bankArr['name'] : set_value('name');?>
									<input type="text" name="name" id="name" placeholder="name" class="col-xs-10 col-sm-8" value="<?php echo $name; ?>" autocomplete="off">
								</div>
							</div>
							
							<div class="clearfix form-actions">
								<div class="col-md-offset-3 col-md-9">
									<button class="btn btn-info" type="submit">
										<i class="ace-icon fa fa-check bigger-110"></i>
										Submit
									</button>
									&nbsp; &nbsp; &nbsp;
									<button class="btn btn-danger" type="reset" onClick="window.location.href = '<?php echo base_url(); ?>bank/index';return false;">
										<i class="ace-icon fa fa-remove bigger-110"></i>
										Cancel
									</button>
								</div>
							  </div>
							</form>
						</div><!-- /.page-content -->
					</div>
				</div>	
			</div>	
		</div>	