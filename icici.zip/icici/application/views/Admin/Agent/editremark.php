	<div class="main-content">
		<div class="main-content-inner">
			<div class="breadcrumbs ace-save-state" id="breadcrumbs">
				<ul class="breadcrumb">
					<li>
						<i class="ace-icon fa fa-home home-icon"></i>
						<a href="<?php echo base_url();?>user/dashboard">Home</a>
					</li>

					<li>
						<a href="#">Remark</a>
					</li>
					<li class="active">Edit Remark</li>
				</ul><!-- /.breadcrumb -->
			</div>

			<div class="page-content">
				<div class="row">
					<div class="col-xs-12">
					<?php if(validation_errors()){?>
					  <div class="alert alert-danger alert-dismissible">
					  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					   <?php echo validation_errors(); ?>.
					  </div>
					<?php } ?>
						<form accept-charset="utf-8" class="form-horizontal" action="<?php echo base_url();?>agent/updateremark" method="post" enctype="multipart/form-data" id="demo-form2" onSubmit="document.your_form.editor_contents.value = $('#editor').html()">
							<input type="hidden" name="remark_id" value="<?php echo encrypt_method($tRemark['id']);?>">
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Select Agent <span class="star">*</span></label>
								<div class="col-sm-9">
									<select name="agent_id" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Choose a Agent...">
										<option value="">  </option>
										<?php foreach($allAgent as $i=>$agent){
											if ($tRemark["agent_id"]== $agent['id']) {
												$selected = 'selected="selected"';
											} else {
												$selected = '';
											}?>
										<option value="<?php echo $agent['id'];?>" value="<?php echo set_value('agent_id'); ?>" <?php echo $selected;?>><?php echo $agent['rcode'];?></option>
										<?php } ?>
									</select>
								</div>
							</div>
							
							<div class="form-group">
								<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Remarks <span class="star">*</span></label>
								<div class="col-sm-9" >
									 <textarea name="editor_contents" id="txtEditor" placeholder="Add Remarks"><?php echo $tRemark["remark"];?></textarea> 
								</div>
							</div>
							
							<div class="clearfix form-actions">
								<div class="col-md-offset-3 col-md-9">
									<button class="btn btn-info" type="submit">
										<i class="ace-icon fa fa-check bigger-110"></i>
										Submit
									</button>
									&nbsp; &nbsp; &nbsp;
									<button class="btn btn-danger" type="reset" onClick="window.location.href = '<?php echo base_url(); ?>agent/listremarks';return false;">
										<i class="ace-icon fa fa-remove bigger-110"></i>
										Cancel
									</button>
								</div>
							  </div>
							</form>
						</div><!-- /.page-content -->
					</div>
				</div>	
			</div>	
		</div>	