<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="<?php echo base_url();?>user/dashboard">Home</a>
							</li>

							<li>
								<a href="#">Agent</a>
							</li>
							<li class="active">List</li>
						</ul><!-- /.breadcrumb -->
					</div>

					<div class="page-content">
					<?php if($this->session->flashdata('message')) { ?>
					  <div class="alert alert-success alert-dismissible">
					  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					   <?php echo $this->session->flashdata('message') ?>; 
					  </div>
					 <?php } ?>
					 <div id="usermessage"></div>
					<div class="row">
                                        <div class="col-xs-12">
                                            <form style="border:1px solid #d5d5d5;padding:10px 0 25px 20px" action="<?php echo base_url(); ?>agent/index">
                                                <div class="row">
                                                    <div class="col-md-11">
                                                        <div class="row">
                                                            <div class="col-sm-12">
                                                                <label class="control-label no-padding-right" for="form-field-1"> Search&nbsp;&nbsp;&nbsp; </label>
                                                                <input type="search" name="search_str" class="form-control" value="<?php
                                                                   if ($this->input->get('search_str')) {
                                                                    echo $this->input->get('search_str');
                                                                     }
                                                                    ?>" class="form-control input-sm" placeholder="Search Agent" aria-controls="dynamic-table" autocomplete="off">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-11">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                              <input type="submit" style="background: rgb(67, 142, 185) none repeat scroll 0% 0%; color: rgb(255, 255, 255); border-radius: 3px; padding: 3px 32px; font-size: 15px; font-family: open sans; font-weight: normal; border: medium none; margin-top: 15px;float:right; position: relative" value="Search">  
                                                              <span style="position:absolute;right:25px;top:20px"><i class="fa fa-arrow-circle-right" aria-hidden="true" style="color:white"></i></span>  
                                                              <a href="<?php echo base_url(); ?>agent/index" style="background: rgb(67, 142, 185) none repeat scroll 0% 0%; color: rgb(255, 255, 255); border-radius: 3px; padding: 3px 32px; font-size: 15px; font-family: open sans; font-weight: normal; border: medium none; margin: 15px;float:right;text-decoration:none;">Reset <i class="fa fa-times-circle" aria-hidden="true"></i></a>  
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                            <br>
                                        </div>
                                    </div>
							<hr>
							<div class="row">
								<div class="col-xs-12">
									<!-- PAGE CONTENT BEGINS -->
									<div class="row">
										<div class="col-xs-12">
											<table id="simple-table" class="table  table-bordered table-hover">
											<thead>
												<tr>
													<th>S.No</th>
													<th>Agent</th>
													<th>Status</th>
													<th>Action</th>
												</tr>
											</thead>
											<tbody>
											<?php if(!empty($agents)){?>
											<?php foreach($agents as $i=>$agent){?>
												<tr>
													<td><?php echo $i+1;?></a></td>
													<td><?php echo $agent['rcode'];?></td>
													<?php if($agent['status']=="lock"){?>
													<td><a href="<?php echo base_url();?>agent/unlockagent/<?php echo encrypt_method($agent["id"]);?>"><span class="active-user label label-sm label-success">Lock</span></a></td>
													<?php } else{ ?>
													<td><a href="<?php echo base_url();?>agent/lockagent/<?php echo encrypt_method($agent["id"]);?>"><span class="deactive-user label label-sm label-warning" >UnLock</span></a></td>
													<?php } ?>	
													<td>
														<div class="hidden-sm hidden-xs btn-group">
														 <a href="<?php echo base_url();?>agent/edit/<?php echo encrypt_method($agent['id']);?>"><button class="btn btn-xs btn-info" title="Edit Agent">
														<i class="ace-icon fa fa-pencil bigger-120"></i>
														 </button></a>

														<a href="<?php echo base_url();?>agent/delete/<?php echo encrypt_method($agent['id']);?>" onclick="return confirm('Are you sure you want to delete this item?');"><button class="btn btn-xs btn-danger" title="Remove Agent">
															<i class="ace-icon fa fa-trash-o bigger-120"></i>
														</button></a>
														</div>
													</td>
												</tr>
											<?php }   ?>
										    <?php }else{?>
										      <tr><td colspan="8" align="center">No Data Found</td></tr>
										    <?php } ?>
											</tbody>
										</table>
									</div><!-- /.span -->
									<?php
									 if (count($agents) > 0) {
									  ?>
									  <div class="">
										  <?php
										  $current = $this->uri->segment(3) + 1;
										  $to = $this->uri->segment(3) + $config['per_page'];
										  $to = ( $to < $config['total_rows'] ? $to : $config['total_rows']);
										  $current = (isset($current) ? $current : 0 );
										  $to = (isset($to) ? $to : 0 );
										  echo 'Showing ' . $current . ' to ' . $to . ' out of ' . $config['total_rows'] . ' Entries.';
										  ?>
									  </div>
									  <div class="row pag">
										  <div class=" col-lg-12 center pagination"><?php echo $this->pagination->create_links(); ?></div>
									  </div>
									  <?php
								  } 
								  else 
								  {
                                  ?>
								 <div class="row">No Record Found</div>                                		
								    		<?php
										}
									?>                                  
								</div><!-- /.row -->
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div>