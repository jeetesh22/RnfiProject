<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta charset="utf-8" />
        <title>ICICI Bank</title>
        <meta name="description" content="User login page" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
        <!-- bootstrap & fontawesome -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assests/css/bootstrap.min.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assests/css/font-awesome.min.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assests/css/fonts.googleapis.com.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assests/css/ace.min.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assests/css/ace-skins.min.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assests/css/ace-rtl.min.css" type="text/css" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<style>
		.error{
			color :red;
		}
		</style>
    </head>

    <body class="login-layout">
        <div class="main-container">
            <div class="main-content">
                <div class="row">
                    <div class="col-sm-10 col-sm-offset-1">
                        <div class="login-container">
                            <div class="center">
                                <h1>
                                    <span class="red"></span>
                                    <span class="white" id="id-text2">ICICI Bank</span>
                                </h1>
                                <h4 class="blue" id="id-company-text"></h4>
                            </div>
                            <div class="space-6"></div>
                            <div class="position-relative">
                                <div id="login-box" class="login-box visible widget-box no-border">
                                    <div class="widget-body">
                                        <div class="widget-main">
                                            <h4 class="header blue lighter bigger">
                                                <i class="ace-icon fa fa-coffee green"></i>
                                                Please Enter Your OTP
                                            </h4>
                                            <div class="space-6"></div>
                                            <?php echo validation_errors(); ?>
                                            <?php
												if($this->session->flashdata("invalid_credential"))
												{?>
											<div class="alert alert-danger alert-dismissible">
											     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
											     <?php echo $this->session->flashdata('invalid_credential')  ?>.
											 </div>
												<?php }
                                            ?>
                                            <form action="<?php echo base_url();?>login/checkadmin_otp" method="post" enctype="multipart/form-data" id="login">
                                                <fieldset>
                                                    <label class="block clearfix">
                                                        <span class="block input-icon input-icon-right">
                                                            <input type="text" name="loginusername" class="form-control" value="" autocomplete="off" placeholder="Fill OTP" />
                                                            <i class="ace-icon fa fa-user"></i>
                                                        </span>
                                                    </label>

                                                    <div class="space"></div>
                                                    <div class="clearfix">                               
                                                        <?php echo form_submit(array('id' => 'submit', 'value' => 'Submit', 'class' => 'width-35 pull-right btn btn-sm btn-primary')); ?>
                                                    </div>

                                                    <div class="space-4"></div>
                                                </fieldset>
                                            </form>
                                        </div><!-- /.widget-main -->
                                    </div><!-- /.widget-body -->
                                </div><!-- /.login-box -->
                            </div><!-- /.position-relative -->
                        </div>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.main-content -->
        </div><!-- /.main-container -->

        <script type="text/javascript" src="<?php echo base_url(); ?>assests/js/jquery-2.1.4.min.js"></script>
		<script type="text/javascript" src="<?php echo base_url();?>assests/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?php echo base_url();?>assests/js/jquery.validate.min.js"></script>
		<script type="text/javascript">
			$(document).ready(function(){
				$("#login").validate({
					rules :{
					loginusername: {
					  required: true,
					}
				},
				messages :{
					"loginusername" : {
						required : 'Please enter otp'
					},
				   }
				  });
			    });
			</script>
    </body>
</html>
