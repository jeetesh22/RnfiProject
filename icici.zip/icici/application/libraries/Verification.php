<?php
    class Verification{
        function __construct(){
            date_default_timezone_set('Asia/Kolkata');
            $this->date_time    =   date("Y-m-d H:i:s");
            $this->date         =   date("Y-m-d");
			$this->password = 'A#$44DDTT&&**(^FFghj2200';
			$this->method = 'aes-256-cbc';
			$this->key = substr(hash('sha256', $this->password, true), 0, 32);
			$this->iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);
			//$this->Otp = rand(100000,999999);
			$this->Otp = '445566';
		}

        public function getotp(){
           return  rand(100000,999999);
        }
		
		function sendOtp($mobile_no,$isAdmin){
			return  $this->Otp;
		}
		
		function encrypted_string($plaintext){
			return $encrypted = base64_encode(openssl_encrypt($plaintext, $this->method, $this->key, OPENSSL_RAW_DATA, $this->iv));
		}
		
		function decrypted_string($plaintext){
			return $decrypted = openssl_decrypt(base64_decode($plaintext), $this->method, $this->key, OPENSSL_RAW_DATA, $this->iv);
		}

		function secure_key_jwt(){
			$key = "weccbchmcmnmglmDzfdxgxd4exvxc0-09vcxvx86vxg[4xfgfx2243w5cxcbcmg23456xccvcxgfdgxcszcszsd";
			return $key;
		}

    }        
?>


