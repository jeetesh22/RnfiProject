<?php
  class Bank_model extends CI_Model
   {
   
	public function saveBankData($savebankArr){
		$this->db->set($savebankArr);
	    $this->db->insert('banks');
	    $result = $this->db->insert_id();
		if($result){
		  $this->session->set_flashdata("message","Bank is successfully saved!");
		  redirect(base_url('bank/index'));
		}else{
		  $this->session->set_flashdata("message","Something db occuress!");
		  redirect(base_url('bank/add'));
		}
	}
	
	public function getvalue_bank_master($limit,$start,$search_str,$from_date,$to_date){
			$this->db->select('*');
			$this->db->from('banks');
			$this->db->order_by("id", "desc");
			if($from_date!="")
			{
				$this->db->where("created_at >=", date("Y-m-d",strtotime($from_date)));
			}
			if($to_date!="")
			{
				$this->db->where("created_at <=", date("Y-m-d",strtotime($to_date)));
			}
			if($search_str!=false)
			{
				$this->db->where("name LIKE", "%".$search_str."%");
			}
			$this->db->limit($limit,$start);
			$query = $this->db->get();
			
			//echo $this->db->last_query();;die;
			return  $query->result_array();
        }   
     
		public function count_getvalue_bank_master($search_str,$from_date,$to_date){
			$this->db->select('*');
			$this->db->from('banks');
			$this->db->order_by("id", "desc");
			if($from_date!="")
			{
				$this->db->where("created_at >=", date("Y-m-d",strtotime($from_date)));
			}
			if($to_date!="")
			{
				$this->db->where("created_at <=", date("Y-m-d",strtotime($to_date)));
			}
			if($search_str!=false)
			{
				$this->db->where("name LIKE", "%".$search_str."%");
			}         
			$query = $this->db->get();
			return  $query->num_rows();  		
        } 
	
	public function changeBankStatus($id,$status){
		$this->db->set('status',$status);
		$this->db->where('id', $id);
		$result = $this->db->update('banks');
		return $result;
	}
	
	public function deleteBank($id){
		$this->db->where('id', $id);
		$result = $this->db->delete('banks');
		return $result;
	}
	
	public function updateBankData($bankArr,$bank_id){
		$this->db->where('id', $bank_id);
		$result = $this->db->update('banks',$bankArr);
		if($result){
		  $this->session->set_flashdata("message","Bank is successfully update!");
		  redirect(base_url('bank/index'));
		}else{
		  $this->session->set_flashdata("message","Something db occuress!");
		  redirect(base_url('bank/edit/'.$bank_id));
		}
	}
	
	public function getBank($id){
		$query = $this->db->select('name')->where('id', $id)->limit(1)->get('banks')->row_array();
		return $query;
	}
	
	public function getAllBank(){
		$query = $this->db->select('id,name')->where('status','A')->get('banks')->result_array();
		return $query;	
	}
	
	public function saveBankDetailData($savebankDetalArr){
		$this->db->set($savebankDetalArr);
	    $this->db->insert('bank_details');
	    $result = $this->db->insert_id();
		if($result){
		  $this->session->set_flashdata("message","Bank Details is successfully saved!");
		  redirect(base_url('bank/indexbankdetail'));
		}else{
		  $this->session->set_flashdata("message","Something db occuress!");
		  redirect(base_url('bank/addbankdetail'));
		}
	}
	
	public function getvalue_bankdetails_master($limit,$start,$search_str,$from_date,$to_date){
			$this->db->select('a.*,b.name');
			$this->db->from('bank_details a');
			$this->db->join('banks b', 'b.id = a.bank_id');
			$this->db->order_by("a.id", "desc");
			if($from_date!="")
			{
				$this->db->where("a.created_at >=", date("Y-m-d",strtotime($from_date)));
			}
			if($to_date!="")
			{
				$this->db->where("a.created_at <=", date("Y-m-d",strtotime($to_date)));
			}
			if($search_str!=false)
			{
				$this->db->where("a.username LIKE", "%".$search_str."%");
				// $this->db->or_where("corporate_id LIKE", "%".$search_str."%");
				// $this->db->or_where("mobile_no LIKE", "%".$search_str."%");
			}
			$this->db->limit($limit,$start);
			$query = $this->db->get();
			
			//echo $this->db->last_query();;die;
			return  $query->result_array();
        }   
     
		public function count_getvalue_bankdetails_master($search_str,$from_date,$to_date){ 
			$this->db->select('a.*,b.name as name');
			$this->db->from('bank_details a');
			$this->db->join('banks b', 'b.id = a.bank_id');
			$this->db->order_by("a.id", "desc");
			if($from_date!="")
			{
				$this->db->where("a.created_at >=", date("Y-m-d",strtotime($from_date)));
			}
			if($to_date!="")
			{
				$this->db->where("a.created_at <=", date("Y-m-d",strtotime($to_date)));
			}
			if($search_str!=false)
			{
				$this->db->where("a.username LIKE", "%".$search_str."%");
				// $this->db->or_where("corporate_id LIKE", "%".$search_str."%");
				// $this->db->or_where("mobile_no LIKE", "%".$search_str."%");
			}         
			$query = $this->db->get();
			return  $query->num_rows();  		
        } 
		
		public function deleteBankDetails($id){
			$this->db->where('id', $id);
			$result = $this->db->delete('bank_details');
			return $result;
		}
		
		public function getBankDPassword($id){
			$query = $this->db->select('id,password,transaction_password')->where('id', $id)->limit(1)->get('bank_details')->row_array();
		    return $query;
		}
		
		public function assignUserBank($userid,$bankid){
			$query = $this->db->select('id,bankid,userid')->where('status','A')->where('userid',$userid)->where('bankid',$bankid)->get('bank_users')->row_array();
		    return $query;
		}
		
		public function getSingleBankDetails($bankid){
			$bankArr = array();
			foreach($bankid as $bank){
				 $bankA = md5($bank);
				 array_push($bankArr,$bankA);
			}
		   $query = $this->db->select('id,bank_id,username,corporate_id,mobile_no')->where('status','A')->where_in('bank_id',$bankArr)->get('bank_details')->result_array();
		   return $query;
		}
	
	
  }