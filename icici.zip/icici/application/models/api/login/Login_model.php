<?php
  class Login_model extends CI_Model
   {
   
	public function CheckUserDetail($username,$password){
		$this->db->select('id,username,emailid,mobileno,login_type,status');
		$this->db->from('users');
		$this->db->where('emailid', $username);
		$this->db->where('password', $password);
		$query = $this->db->get();
		if ($query->num_rows() > 0 )
		{ 
		  $data = $query->row();
		}else{
			$data = [];
		}
		return $data;
	}
	
	
	  public function updateUserData($updateuserArr,$userid){
		$this->db->where('id', $userid);
		$result = $this->db->update('users',$updateuserArr);
		return $result;
	}

	public function checkvalidToken($token){
		$this->db->select('id,token,mobileno');
		$this->db->from('users');
		$this->db->where('token', $token);
		$query = $this->db->get();
		if ($query->num_rows() > 0 )
		{ 
		  $data = $query->row();
		}else{
			$data = [];
		}
		return $data;
	}

	public function checkvalidDevice($device){
		$this->db->select('id,deviceid');
		$this->db->from('users');
		$this->db->where('deviceid', $device);
		$query = $this->db->get();
		if ($query->num_rows() > 0 )
		{ 
		  $data = $query->row();
		}else{
			$data = [];
		}
		return $data;
	}

	public function checkvalidmobileno($mobile){
		$this->db->select('id,deviceid');
		$this->db->from('users');
		$this->db->where('mobileno', $mobile);
		$query = $this->db->get();
		if ($query->num_rows() > 0 )
		{ 
		  $data = $query->row();
		}else{
			$data = [];
		}
		return $data;
	}

	public function saveOtp($getOtp,$id){
		$data = array("userid"=>$id,"otp"=>$getOtp,"is_valid"=>0);
		$result = $this->db->insert("userotp",$data);
		return $result;
	}

	public function checkOtp($mobileno,$otp,$id){
		$this->db->select('id,otp');
		$this->db->from('userotp');
		$this->db->where('userid', $id);
		$this->db->where('otp', $otp);
		$this->db->where('is_valid',0);
		$query = $this->db->get();
		if ($query->num_rows() > 0 )
		{ 
		  $data = $query->row();	
		  $this->db->where('id', $data->id);
		  $result = $this->db->update('userotp',array("is_valid"=>1));
		  return $data;
		}else{
			$data = [];
		}
		return $data;
	}
}