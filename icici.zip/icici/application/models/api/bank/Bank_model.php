<?php
  class Bank_model extends CI_Model
   {

   	public function getAssignBanks($id){ 
   	  $this->db->select("b.id,b.name");
	  $this->db->from('bank_users a');
	  $this->db->join('banks b', 'b.id = a.bankid');
	  $this->db->where("a.userid",$id);
	  $this->db->where("b.status","A");
	  $query = $this->db->get();
	  return $query->result();
   	}

   	public function getBankDetails($id){
   	  $this->db->select("username,corporate_id,mobile_no,transaction_password,password");
	  $this->db->from('bank_details');
	  $this->db->where("bank_id",$id);
	  $query = $this->db->get();
	  return $query->row();
   	}
}