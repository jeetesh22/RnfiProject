<?php
  class Agent_model extends CI_Model
   {
	   public function __construct(){
			parent::__construct();
			$this->load->database();
			date_default_timezone_set('Asia/Kolkata');
			$this->loggedInArr = $this->session->userdata('logged_in');
		 }
   
	public function saveRcodeCsv(){
		$loggedInArr = $this->session->userdata('logged_in');
		$count=0;
		$fileType = $this->file_check($_FILES);
		if($fileType == 1){ 
        $fp = fopen($_FILES['rcode_csv']['tmp_name'],'r') or die("can't open file");
        while($csv_line = fgetcsv($fp,4096))
        {
            $count++;
            for($i = 0, $j = count($csv_line); $i < $j; $i++)
            {
                $insert_csv = array();
                $insert_csv['rocde'] = $csv_line[0];
            }
            $i++;
            $data = array(
                'rcode' => $insert_csv['rocde'],
                'lockby' =>$loggedInArr["id"],
				'created_at'=>date('Y-m-d H:i:s')
               );
            $data['crane_features']=$this->db->insert('agent', $data);
        }
        fclose($fp) or die("can't close file");
        $data['success']="success";
        return $data;
      }else{ 
		
	 }
	}
	
	public function file_check($str){ 
        $allowed_mime_types = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
        if(isset($_FILES['rcode_csv']['name']) && $_FILES['rcode_csv']['name'] != ""){
            $mime = get_mime_by_extension($_FILES['rcode_csv']['name']);
            $fileAr = explode('.', $_FILES['rcode_csv']['name']);
            $ext = end($fileAr);
            if(($ext == 'csv') && in_array($mime, $allowed_mime_types)){ 
                return true;
            }else{ 
                $this->session->set_flashdata('message', 'Please select only CSV file to upload.');
                redirect(base_url('user/dashboard'));
            }
        }else{
            $this->session->set_flashdata('message', 'Please select a CSV file to upload.');
            redirect(base_url('user/dashboard'));
        }
      }
	
		public function getAllAgents(){
			$query = $this->db->select('id,rcode,status')->where('lockby',$this->loggedInArr["id"])->where('status',"lock")->get('agent')->result_array();
			return $query;
		}
		
		public function getSingleAgents($id){
			$query = $this->db->select('id,rcode')->where('id',$id)->get('agent')->row_array();
			return $query;
		}
	
		public function getvalue_agent_master($limit,$start,$search_str){
			$this->db->select('*');
			$this->db->from('agent');
			$this->db->where('lockby',$this->loggedInArr["id"]);
			$this->db->order_by("id", "desc");
			if($search_str!=false)
			{
				$this->db->where("rcode LIKE", "%".$search_str."%");
			}
			$this->db->limit($limit,$start);
			$query = $this->db->get();
			//echo $this->db->last_query(); die;
			return  $query->result_array();
        }   
     
		public function count_getvalue_agent_master($search_str){
			$this->db->select('*');
			$this->db->from('agent');
			$this->db->where('lockby',$this->loggedInArr["id"]);
			$this->db->order_by("id", "desc");
			if($search_str!=false)
			{
				$this->db->where("rcode LIKE", "%".$search_str."%");
			}         
			$query = $this->db->get();
			return  $query->num_rows();  		
        } 
		
		public function unLockAgent($id){
			$data = array('status'=>'unlock','modify_at'=>date('Y-m-d H:i:s'));
			$this->db->where('id', $id);
            $result = $this->db->update('agent', $data);
			if($result){
			  $this->session->set_flashdata("message","Agent is successfully unlock!");
			  redirect(base_url('agent/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('agent/index'));
			}
		}
		
		public function LockAgent($id){
			$data = array('status'=>'lock','modify_at'=>date('Y-m-d H:i:s'));
			$this->db->where('id', $id);
            $result = $this->db->update('agent', $data);
			if($result){
			  $this->session->set_flashdata("message","Agent is successfully lock!");
			  redirect(base_url('agent/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('agent/index'));
			}
		}
		
		public function updateAgent($id,$rcode){ 
			$data = array('rcode'=>$rcode,'modify_at'=>date('Y-m-d H:i:s'));
			$this->db->where('id', $id);
            $result = $this->db->update('agent', $data);
			if($result){
			  $this->session->set_flashdata("message","Agent is successfully update!");
			  redirect(base_url('agent/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('agent/edit/'.$id));
			}
		}
		
		public function removeAgent($id){ 
			$this->db->where('id', $id);
            $result = $this->db->delete('agent');
			if($result){
			  $this->session->set_flashdata("message","Agent is successfully remove!");
			  redirect(base_url('agent/index'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('agent/index'));
			}
		}
		
		public function saveRemarks($saveRemarks){
			$this->db->set($saveRemarks);
            $result = $this->db->insert('remarks');
			if($result){
			  $this->session->set_flashdata("message","Remarks is successfully save!");
			  redirect(base_url('agent/listremarks'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('agent/addremarks'));
			}
		}
		
		public function getvalue_remark_master($limit,$start,$search_str){
			$this->db->select('a.id,a.remark,b.rcode');
			$this->db->from('remarks a');
			$this->db->join('agent b', 'b.id = a.agent_id');
			$this->db->where('a.user_id',$this->loggedInArr["id"]);
			$this->db->order_by("a.id", "desc");
			if($search_str!=false)
			{
				$this->db->where("a.remark LIKE", "%".$search_str."%");
				$this->db->or_where("b.rcode LIKE", "%".$search_str."%");
			}
			$this->db->limit($limit,$start);
			$query = $this->db->get();
			//echo $this->db->last_query(); die;
			return  $query->result_array();
        }   
     
		public function count_getvalue_remark_master($search_str){
			$this->db->select('a.id,a.remark,b.rcode');
			$this->db->from('remarks a');
			$this->db->join('agent b', 'b.id = a.agent_id');
			$this->db->where('a.user_id',$this->loggedInArr["id"]);
			$this->db->order_by("a.id", "desc");
			if($search_str!=false)
			{
				$this->db->where("a.remark LIKE", "%".$search_str."%");
				$this->db->or_where("b.rcode LIKE", "%".$search_str."%");
			}
			$query = $this->db->get();
			return  $query->num_rows();  		
        }

		public function removeRemarks($id){
			$this->db->where('id', $id);
            $result = $this->db->delete('remarks');
			if($result){
			  $this->session->set_flashdata("message","Remarks is successfully remove!");
			  redirect(base_url('agent/listremarks'));
			}else{
			  $this->session->set_flashdata("message","Something db occuress!");
			  redirect(base_url('agent/listremarks'));
			}
		}

		public function getSingleRemark($id){
			$query = $this->db->select('id,agent_id,remark')->where('id',$id)->where('user_id',$this->loggedInArr["id"])->get('remarks')->row_array();
			return $query;
		}

		public function updateRemarks($updateRemarks,$remark_id){
			$this->db->where('id', $remark_id);
            $result = $this->db->update('remarks', $updateRemarks);
			if($result){
			  $this->session->set_flashdata("message","Remarks is successfully update!");
			  redirect(base_url('agent/listremarks'));
			}else{
			  $this->session->listremarks("message","Something db occuress!");
			  redirect(base_url('agent/editremark/'.$remark_id));
			}
		}	
	
	
  }