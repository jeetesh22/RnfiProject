<?php
  class User_model extends CI_Model
   {
   
	public function CheckAdminDetail($username, $password){
		$this->db->select('*');
		$this->db->from('admin');
		$this->db->where('username', $username);
		$this->db->where('password', $password);
		$query = $this->db->get();
		if ($query->num_rows() > 0 )
		{ 
		  $data = $query->row();
		}else{
			$data =  [];
		}
		return $data;
	}
	
	public function saveUserData($saveuserArr){
		$this->db->set($saveuserArr);
	    $this->db->insert('users');
	    $result = $this->db->insert_id();
		if($result){
		  $this->session->set_flashdata("message","User is successfully saved!");
		  redirect(base_url('user/listuser'));
		}else{
		  $this->session->set_flashdata("message","Something db occuress!");
		  redirect(base_url('user/adduser'));
		}
	}
	
	public function getvalue_user_master($limit,$start,$search_str,$from_date,$to_date){
			$this->db->select('*');
			$this->db->from('users');
			$this->db->order_by("id", "desc");
			if($from_date!="")
			{
				$this->db->where("created >=", date("Y-m-d",strtotime($from_date)));
			}
			if($to_date!="")
			{
				$this->db->where("created <=", date("Y-m-d",strtotime($to_date)));
			}
			if($search_str!=false)
			{
				$this->db->where("username LIKE", "%".$search_str."%");
				$this->db->or_where("mobileno LIKE", "%".$search_str."%");
				$this->db->or_where("emailid LIKE", "%".$search_str."%");
			}
			$this->db->limit($limit,$start);
			$query = $this->db->get();
			
			//echo $this->db->last_query();;die;
			return  $query->result_array();
        }   
     
		public function count_getvalue_user_master($search_str,$from_date,$to_date){
			$this->db->select('*');
			$this->db->from('users');
			$this->db->order_by("id", "desc");
			if($from_date!="")
			{
				$this->db->where("created >=", date("Y-m-d",strtotime($from_date)));
			}
			if($to_date!="")
			{
				$this->db->where("created <=", date("Y-m-d",strtotime($to_date)));
			}
			if($search_str!=false)
			{
				$this->db->where("username LIKE", "%".$search_str."%");
				$this->db->or_where("mobileno LIKE", "%".$search_str."%");
				$this->db->or_where("emailid LIKE", "%".$search_str."%");
			}         
			$query = $this->db->get();
			return  $query->num_rows();  		
        } 
	
	public function changeStatus($id,$status){
		$this->db->set('status',$status);
		$this->db->where('id', $id);
		$result = $this->db->update('users');
		return $result;
	}
	
	public function deleteUser($id){
		$this->db->where('id', $id);
		$result = $this->db->delete('users');
		return $result;
	}
	
	public function saveUserPassword($spasswordArr,$userId){
		$this->db->where('id', $userId);
		$result = $this->db->update('users',$spasswordArr);
		if($result){
		  $this->session->set_flashdata("message","Password is successfully saved!");
		  redirect(base_url('user/listuser'));
		}else{
		  $this->session->set_flashdata("message","Something db occuress!");
		  redirect(base_url('user/addpassword/'.$userId));
		}
	}
	
	public function getPassword($id){
		$query = $this->db->select('password')->where('id', $id)->limit(1)->get('users')->row_array();
		return $query;
	}
	
	public function CheckUserDetail($username,$password){
		$this->db->select('id,username,emailid,mobileno,login_type,status');
		$this->db->from('users');
		$this->db->where('emailid', $username);
		$this->db->where('password', $password);
		$query = $this->db->get();
		if ($query->num_rows() > 0 )
		{ 
		  $data = $query->row();
		}else{
			$data =  [];
		}
		return $data;
	}
	
	public function CheckUserActiveaccount($username, $password,$uid){
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('username', $username);
		$this->db->where('password', $password);
		$this->db->where('id', $uid);
		$this->db->where('status','D');
		$query = $this->db->get();
		if ($query->num_rows() > 0 )
		{ 
		  $data = $query->row();
		}else{
			$data =  [];
		}
		return $data;
	}
	
	public function getAllUsers(){
		$query = $this->db->select('id,username,mobileno,emailid')->where('status', 'A')->get('users')->result_array();
		return $query;
	}
	
	public function saveAssignBankUser($bankId,$assignUser){
		$assignArr = array('bankid'=>$bankId,'userid'=>$assignUser,'created_at'=>date('Y-m-d H:i:s'));
		$this->db->set($assignArr);
	    $this->db->insert('bank_users');
	    $result = $this->db->insert_id();
		if($result){
			return 1;
		}
	}
	
	public function unAssignbankuser($bankId,$assignUser){
		$this->db->where('bankid', $bankId);
		$this->db->where('userid', $assignUser);
		$result = $this->db->delete('bank_users');
		return $result;
	}
	
	public function getUser($id){
		$query = $this->db->select('id,username,mobileno,emailid,login_type')->where('id', $id)->get('users')->row_array();
		return $query;
	}
   
    public function updateUserData($updateuserArr,$userid){
		$this->db->where('id', $userid);
		$result = $this->db->update('users',$updateuserArr);
		if($result){
		  $this->session->set_flashdata("message","User is successfully update!");
		  redirect(base_url('user/listuser'));
		}else{
		  $this->session->set_flashdata("message","Something db occuress!");
		  redirect(base_url('user/addpassword/'.$userId));
		}
	}
	
	public function getAssignBanks($userid){ 
	  $this->db->select("a.id as buId,b.name as bankName,a.userid as userID,a.bankid,b.id as bank");
	  $this->db->from('bank_users a');
	  $this->db->join('banks b', 'b.id = a.bankid');
	  $this->db->where('a.userid', $userid);
	  $query = $this->db->get();
	  if($query->num_rows() != 0)
	  {
		return $query->result_array();
	  }
	  else
	  { 
			return false;
	  }
	 }
	 
	 public function getAdminRecord(){
		 $query = $this ->db->select('id,username,mobile_no,modify,password')->limit(1)->get('admin');
		 return $query->row_array();
	 }
	 
	 public function updateProfile($newprofileArr){
		$this->db->where('id', 1);
		$result = $this->db->update('admin',$newprofileArr);
		if($result){
		  $this->session->set_flashdata("message","Profile is successfully update!");
		  redirect(base_url('user/dashboard'));
		}else{
		  $this->session->set_flashdata("message","Something db occuress!");
		  redirect(base_url('user/adminprofile'));
		}
	 }
   
	
	
  }