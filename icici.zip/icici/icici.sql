-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2020 at 09:50 AM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.3.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `icici`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `created` datetime NOT NULL,
  `modify` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `username`, `password`, `created`, `modify`) VALUES
(1, 'admin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2020-12-10 15:55:47', '2020-12-10 13:26:15');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_agent`
--

CREATE TABLE `tbl_agent` (
  `id` int(11) NOT NULL,
  `rcode` varchar(100) DEFAULT NULL,
  `lockby` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `modify_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('A','D') NOT NULL DEFAULT 'A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_banks`
--

CREATE TABLE `tbl_banks` (
  `id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `modify_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('A','D') NOT NULL DEFAULT 'A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_banks`
--

INSERT INTO `tbl_banks` (`id`, `name`, `created_at`, `modify_at`, `status`) VALUES
(1, 'Micro ATM Data', '2020-12-10 18:59:31', '2020-12-10 13:31:06', 'A'),
(2, 'ICICI BANK 1616', '2020-12-10 19:15:29', '2020-12-10 13:45:29', 'A'),
(3, 'a', '2020-12-10 23:36:45', '2020-12-14 07:27:49', 'D');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bank_details`
--

CREATE TABLE `tbl_bank_details` (
  `id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `username` varchar(200) DEFAULT NULL,
  `corporate_id` varchar(100) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL COMMENT 'Bank\r\n',
  `transaction_password` varchar(250) DEFAULT NULL,
  `mobile_no` varchar(30) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modify_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('A','D') DEFAULT 'A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_bank_details`
--

INSERT INTO `tbl_bank_details` (`id`, `bank_id`, `username`, `corporate_id`, `password`, `transaction_password`, `mobile_no`, `created_at`, `modify_at`, `status`) VALUES
(1, 1, 'fHauWLRP0CAYQRlT9BHWlg==', 'fHauWLRP0CAYQRlT9BHWlg==', 'hjo+wGCPoDUmupt3/+16gA==', 'Z7nQvJ8VZktMcN1Bpe/J+A==', 'GePi/RKL59rElT5vjgA1qQ==', '2020-12-10 19:03:41', '2020-12-11 12:46:11', 'A'),
(2, 0, '6ar02WJHB7PyJX+ylKbCtw==', 'NC+2rGnYtVPZBf0cBkE2vg==', 'hjo+wGCPoDUmupt3/+16gA==', NULL, 'iuMdBUYM7g4cug95BDhUyA==', '2020-12-10 19:16:06', '2020-12-10 13:46:06', 'A'),
(3, 0, 'NDwfd19FmTg2OvqbfUVwFg==', 'fHauWLRP0CAYQRlT9BHWlg==', 'Z7nQvJ8VZktMcN1Bpe/J+A==', 'Z7nQvJ8VZktMcN1Bpe/J+A==', 'Q4+Bwm/90Nnp1IemEby0Ww==', '2020-12-11 12:47:32', '2020-12-11 07:17:32', 'A'),
(4, 0, 'fHauWLRP0CAYQRlT9BHWlg==', 'fHauWLRP0CAYQRlT9BHWlg==', 'hjo+wGCPoDUmupt3/+16gA==', 'hjo+wGCPoDUmupt3/+16gA==', 'W69jwGZAFYZCHEgkLU/0Ag==', '2020-12-11 12:53:12', '2020-12-11 07:23:12', 'A'),
(5, 2, 'fHauWLRP0CAYQRlT9BHWlg==', 'fHauWLRP0CAYQRlT9BHWlg==', 'hjo+wGCPoDUmupt3/+16gA==', 'hjo+wGCPoDUmupt3/+16gA==', 'W69jwGZAFYZCHEgkLU/0Ag==', '2020-12-11 12:55:43', '2020-12-11 07:25:43', 'A'),
(6, 3, 'X0rueZ/hp6yTdgw1q1Y1BA==', 'fHauWLRP0CAYQRlT9BHWlg==', 'F3BqmLgJpzv2cyZZB13Orw==', '+aR/CZffKB4DnPUXxd0IQA==', 'W69jwGZAFYZCHEgkLU/0Ag==', '2020-12-11 13:00:36', '2020-12-11 07:30:36', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bank_users`
--

CREATE TABLE `tbl_bank_users` (
  `id` int(11) NOT NULL,
  `bankid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `modify_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('A','D') NOT NULL DEFAULT 'A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_bank_users`
--

INSERT INTO `tbl_bank_users` (`id`, `bankid`, `userid`, `created_at`, `modify_at`, `status`) VALUES
(1, 1, 9, '2020-12-11 13:47:31', '2020-12-11 08:17:31', 'A'),
(2, 3, 11, '2020-12-11 13:49:12', '2020-12-11 08:19:12', 'A'),
(3, 3, 12, '2020-12-11 13:49:14', '2020-12-11 08:19:14', 'A'),
(4, 3, 13, '2020-12-11 13:56:48', '2020-12-11 08:26:48', 'A'),
(5, 2, 4, '2020-12-11 13:56:55', '2020-12-11 08:26:55', 'A'),
(6, 1, 1, '2020-12-11 17:50:09', '2020-12-11 12:20:09', 'A'),
(7, 1, 13, '2020-12-11 17:50:12', '2020-12-11 12:20:12', 'A'),
(8, 2, 10, '2020-12-14 11:27:47', '2020-12-14 05:57:47', 'A'),
(9, 3, 4, '2020-12-14 11:27:59', '2020-12-14 05:57:59', 'A'),
(10, 3, 5, '2020-12-14 11:28:02', '2020-12-14 05:58:02', 'A'),
(11, 2, 1, '2020-12-14 12:56:28', '2020-12-14 07:26:28', 'A'),
(12, 3, 1, '2020-12-14 12:56:31', '2020-12-14 07:26:31', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_remarks`
--

CREATE TABLE `tbl_remarks` (
  `id` int(11) NOT NULL,
  `agent_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `remark` varchar(250) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `modify_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('A','D') NOT NULL DEFAULT 'A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_userotp`
--

CREATE TABLE `tbl_userotp` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `otp` varchar(20) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_valid` int(11) NOT NULL COMMENT '0->valid,1->notvalid'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_userotp`
--

INSERT INTO `tbl_userotp` (`id`, `userid`, `otp`, `created`, `is_valid`) VALUES
(1, 1, '445566', '2020-12-14 07:18:42', 1),
(2, 1, '445566', '2020-12-14 07:18:59', 1),
(3, 1, '445566', '2020-12-14 07:19:04', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `username` varchar(200) DEFAULT NULL,
  `emailid` varchar(200) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL,
  `mobileno` varchar(50) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modify` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('A','D') NOT NULL DEFAULT 'A',
  `login_type` enum('0','1') DEFAULT NULL COMMENT '1->Bank type,0->Transaction',
  `deviceid` text DEFAULT NULL,
  `token` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `username`, `emailid`, `password`, `mobileno`, `created`, `modify`, `status`, `login_type`, `deviceid`, `token`) VALUES
(1, 'jeetesh pandey', 'jeetesh.sharma@rnfi.in', 'e10adc3949ba59abbe56e057f20f883e', '9799910416', '2020-12-10 18:57:19', '2020-12-11 11:32:19', 'A', '1', 'wwwwwwwwwwwwwwsfafa', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6IjEiLCJ1c2VybmFtZSI6ImplZXRlc2ggcGFuZGV5IiwibXlpcCI6Ijo6MSJ9.OsMhguiffPQBm9ooi8gk3ySkn3rWfd2zPrU09w74kUs'),
(3, 'pankaj', 'pankaj@gmail.com', NULL, '4455667788', '2020-12-10 23:37:08', '2020-12-14 06:06:18', 'A', '0', NULL, NULL),
(4, 'R003035', 'mohit@gmail.com', NULL, '6677889900', '2020-12-11 11:53:41', '2020-12-11 06:23:41', 'A', '', NULL, NULL),
(5, 'R003035', 'pankraj@gmail.com', NULL, '4455667780', '2020-12-11 11:54:33', '2020-12-11 06:43:32', 'A', '1', NULL, NULL),
(6, 'R003035', 'pamnkaj@gmail.com', NULL, '2233445567', '2020-12-11 11:55:00', '2020-12-11 06:25:00', 'A', '1', NULL, NULL),
(7, 'R003035', 'paankaj@gmail.com', NULL, '4455667784', '2020-12-11 13:07:35', '2020-12-14 06:13:42', 'A', '1', NULL, NULL),
(8, 'jeetesh ', 'jeetesh.sharma@rnfi.in', 'e10adc3949ba59abbe56e057f20f883e', '9799910416', '2020-12-10 18:57:19', '2020-12-14 07:26:21', 'A', '1', NULL, NULL),
(9, 'pankaj', 'pankaj@gmail.com', NULL, '4455667788', '2020-12-10 23:37:08', '2020-12-14 06:13:32', 'D', '1', NULL, NULL),
(10, 'R003035', 'mohit@gmail.com', NULL, '6677889900', '2020-12-11 11:53:41', '2020-12-11 06:23:41', 'A', '', NULL, NULL),
(11, 'R003035', 'pankraj@gmail.com', NULL, '4455667780', '2020-12-11 11:54:33', '2020-12-11 06:43:32', 'A', '1', NULL, NULL),
(12, 'R003035', 'pamnkaj@gmail.com', NULL, '2233445567', '2020-12-11 11:55:00', '2020-12-11 06:25:00', 'A', '1', NULL, NULL),
(13, 'R003048', 'paankaj@gmail.com', NULL, '4455667784', '2020-12-11 13:07:35', '2020-12-14 06:01:51', 'A', '1', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_agent`
--
ALTER TABLE `tbl_agent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_banks`
--
ALTER TABLE `tbl_banks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_bank_details`
--
ALTER TABLE `tbl_bank_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_bank_users`
--
ALTER TABLE `tbl_bank_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_remarks`
--
ALTER TABLE `tbl_remarks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_userotp`
--
ALTER TABLE `tbl_userotp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_agent`
--
ALTER TABLE `tbl_agent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_banks`
--
ALTER TABLE `tbl_banks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_bank_details`
--
ALTER TABLE `tbl_bank_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_bank_users`
--
ALTER TABLE `tbl_bank_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_remarks`
--
ALTER TABLE `tbl_remarks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_userotp`
--
ALTER TABLE `tbl_userotp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
